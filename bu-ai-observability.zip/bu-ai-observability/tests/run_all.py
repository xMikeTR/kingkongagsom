#!/usr/bin/env python3
"""Run every offline check. No network, no secrets needed.
  python tests/run_all.py
"""
import io
import json
import os
import subprocess
import sys
import tempfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)
os.chdir(tempfile.mkdtemp(prefix="obs_tests_"))

from obs.aliases import AliasTable, normalise  # noqa: E402
from obs.events import ContractError, make_event, to_newrelic, validate  # noqa: E402
from obs.ids import WI_UNASSIGNED, is_work_item_id, new_work_item_id, ulid  # noqa: E402

ok = []

# ids
a, b = ulid(1_700_000_000_000), ulid(1_700_000_000_001)
assert len(a) == 26 and a < b, "ULIDs must be fixed-length and time-sortable"
assert is_work_item_id(new_work_item_id()) and is_work_item_id(WI_UNASSIGNED) and not is_work_item_id("RE-1")
ok.append("work-item IDs")

# aliases
assert normalise("RE-1234") == "jira:RE-1234"
assert normalise("git:feature/RE-1234-fix-pricing") == "jira:RE-1234"
assert normalise("AB#5678") == "ado:AB#5678"
assert normalise("git:main") is None
t = AliasTable(os.path.join(os.getcwd(), "aliases.csv"))
wi = t.ensure("jira:RE-1234")
assert t.ensure("RE-1234") == wi and t.resolve("RE-1234-some-branch") == wi
assert t.resolve("main") == WI_UNASSIGNED
assert t.link("ado:AB#5678", "jira:RE-1234") == wi and t.resolve("AB#5678") == wi
t.save()
assert AliasTable(t.path).resolve("ado:AB#5678") == wi
ok.append("alias table: resolve, mint, migrate, persist")

# events
ev = make_event("AIUsage", "/test", wi, {"harness": "copilot", "gen_ai.request.model": "m",
                                         "billing_source": "github", "ai_credits_used": 3})
validate(ev)
flat = to_newrelic(ev)
assert flat["eventType"] == "AIUsage" and flat["work_item.id"] == wi and flat["org.bu"] == "hiscox-re"
for bad in ({"harness": "copilot", "gen_ai.request.model": "m", "billing_source": "github", "prompt": "x"},
            {"harness": "nope", "gen_ai.request.model": "m", "billing_source": "github"},
            {"harness": "copilot"}):
    try:
        make_event("AIUsage", "/test", wi, bad)
        raise AssertionError(f"should have rejected {bad}")
    except ContractError:
        pass
try:
    make_event("PRMerged", "/test", "RE-1234", {"repo": "r", "pr_number": 1})
    raise AssertionError("raw Jira key as subject must be rejected")
except ContractError:
    pass
ok.append("event contract: validation, content ban, raw keys rejected")


def run(*args, env=None):
    r = subprocess.run([sys.executable, *args], capture_output=True, text=True,
                       env={**os.environ, **(env or {})})
    if r.returncode != 0:
        raise AssertionError(f"{args}: {r.stderr or r.stdout}")
    return r.stdout


# Jira adapter (fixture, dry run), twice: second run must not re-emit
env = {"JIRA_TEAM_FIELD": "customfield_10001", "JIRA_POINTS_FIELD": "customfield_10016"}
fx = os.path.join(ROOT, "adapters", "jira", "fixture.json")
run(os.path.join(ROOT, "adapters", "jira", "sync_work_items.py"), "--fixture", fx, "--dry-run", env=env)
first = [json.loads(l) for l in open("events.ndjson")]
run(os.path.join(ROOT, "adapters", "jira", "sync_work_items.py"), "--fixture", fx, "--dry-run", env=env)
second = [json.loads(l) for l in open("events.ndjson")][len(first):]
types = sorted(e["eventType"] for e in first)
assert types.count("WorkItemCreated") == 3 and types.count("WorkItemDone") == 1, types
assert not second, "second sync with no changes must emit nothing"
created = {e["alias"]: e for e in first if e["eventType"] == "WorkItemCreated"}
assert created["jira:RE-1203"]["work_stream"] == "platform" and created["jira:RE-1202"]["task_class"] == "data"
ok.append("Jira adapter: mints IDs, emits once, classifies")

# GitHub emitter resolves through the alias table when it has one
os.remove("events.ndjson")
run(os.path.join(ROOT, "adapters", "github", "emit_event.py"), "CIRunCompleted", "--branch", "RE-1201-tidy",
    "--aliases", "data/aliases.csv", "--set", "repo=x/y", "run_id=1", "conclusion=success", "attempt=2", "--dry-run")
e = json.loads(open("events.ndjson").read().splitlines()[-1])
assert e["work_item.id"].startswith("wi_") and e["work_item.id"] != WI_UNASSIGNED and e["attempt"] == 2
ok.append("GitHub emitter: branch -> work item")

# Copilot usage parser
with open("copilot.ndjson", "w") as f:
    f.write(json.dumps({"user_login": "Dev1", "date": "2026-11-17", "ai_credits_used": 14,
                        "token_usage": {"prompt_tokens_sum": 1000, "output_tokens_sum": 200}}) + "\n")
    f.write("not json\n")
    f.write(json.dumps({"something": "else"}) + "\n")
out = run(os.path.join(ROOT, "adapters", "github", "copilot_usage.py"), "--ndjson", "copilot.ndjson", "--dry-run")
assert "3 records -> 1 AIUsage" in out or "2 records -> 1 AIUsage" in out, out
ok.append("Copilot usage: defensive parsing")

# Claude Code hook (python variant): body shape
sys.path.insert(0, os.path.join(ROOT, "clients", "claude-code", "hooks"))
import session_start  # noqa: E402
assert session_start.alias_from_branch("RE-77-x") == "jira:RE-77"
body = session_start.build_body("sess-1", "startup", "RE-77-x", "repo", "jira:RE-77", {"enduser.id": "a@b.c"})
attrs = {a["key"]: a["value"]["stringValue"] for a in body["resourceLogs"][0]["scopeLogs"][0]["logRecords"][0]["attributes"]}
assert attrs["session.id"] == "sess-1" and attrs["work_item.alias"] == "jira:RE-77"
ok.append("SessionStart hook payload")

# value view self-test
print(run(os.path.join(ROOT, "valueview", "value_view.py"), "--selftest"))
ok.append("value view self-test")

for o in ok:
    print("ok:", o)
print(f"\nall {len(ok)} checks passed")
