# Measuring the Return on Agentic Engineering Spend

**A proposal for a three-tier measurement model**

Author: Mike — Software Engineering, Hiscox RE
Status: Draft for review

---

## 1. The ask

We are spending on agentic coding tooling and the platform that governs it. We currently have no agreed definition of what that spend is buying, which means the programme is defended on anecdote and defunded on intuition.

This proposal asks leadership to:

1. **Endorse a fixed set of five leadership metrics** (Section 4) and an explicit list of metrics we will *not* report (Section 6).
2. **Authorise a one-quarter measurement window** with the instrumentation described in Section 8.
3. **Pre-commit to the decision the data will inform** — scale, hold, or redirect — and to what "good" looks like *before* the first numbers arrive (Section 9).

Point 3 is the one that matters. A dashboard without a pre-agreed decision rule becomes a monthly argument about which chart is fair.

---

## 2. Why current measurement does not answer the leadership question

Engineering already has, or can shortly have, detailed telemetry: agent session traces, acceptance rates, escalation rates, PR cycle time, token spend. That instrumentation is well-suited to the squad and to the Scrum Master.

It does not answer the leadership question, for three reasons:

- **It measures the tool, not the outcome.** Escalation rate is an engineering diagnostic. It tells leadership nothing about whether the business is better off.
- **It is vulnerable to activity inflation.** Agentic tooling reliably increases commits, PRs and lines changed. Reporting those upward manufactures the appearance of return while saying nothing about qualified, durable output.
- **It has no denominator leadership recognises.** Token cost is a rounding error against engineer cost. A return story denominated in tokens is not a return story.

The fix is not more metrics. It is a smaller set, at a different altitude, with an explicit method for converting engineering signal into money and risk.

---

## 3. Three tiers, one data model

All three tiers are computed from the same underlying tables — agent sessions, pull requests, work items, deployments. The difference is aggregation and cadence, not collection.

| Tier | Audience | Question answered | Cadence |
|---|---|---|---|
| 1 — Squad | PO / Scrum Master | Is the flow healthy this week? | Weekly |
| 2 — Engineering | Engineering Manager | Where do agents work, where do they not? | Monthly |
| 3 — Leadership | BU / CTO level | What is the spend buying, and should we scale it? | Quarterly |

This matters operationally: **we instrument once**. Tier 3 is a view, not a second collection effort. That keeps the cost of measurement low and keeps the numbers reconcilable when someone challenges them.

---

## 4. The leadership metric set

Five metrics. The recommendation is to hold this list fixed for at least two quarters, because a metric set that changes every reporting cycle cannot show a trend, and a trend is the entire point.

### 4.1 Cost per production-qualified change (fully loaded)

**Definition:** total attributable delivery cost ÷ changes that reach production and survive 30 days.

Cost includes model and gateway spend, CI compute, and — critically — reviewer and rework time valued at fully loaded engineer cost.

**Why it is the headline:** it is the only metric that puts spend and output in the same fraction. It is also self-correcting: a tool that generates more but is trusted less will raise reviewer time and the metric will get worse, not better.

**Read the trend, not the level.** The absolute figure depends on cost assumptions nobody will fully agree on. The direction over four quarters is robust to those assumptions.

### 4.2 Engineer capacity redeployed

**Definition:** engineer hours released, expressed as FTE-equivalents, *plus a named statement of what that capacity moved to*.

**Why both halves are required:** released capacity is not value until it is redeployed. If the answer to "what did the freed capacity do" is "we don't know", the honest finding is that the saving has not yet been realised. Reporting the second half is what keeps this metric from becoming a fiction.

### 4.3 Quality differential

**Definition:** change failure rate and 30-day defect escape rate for agent-attributed changes, against the non-agent comparison cohort.

**Why it is non-negotiable:** it is the metric that proves we are not buying speed with future incidents. A report containing only favourable metrics will be discounted by any leader who has seen a technology programme before. Including the metric most likely to embarrass us is what makes the other four credible.

### 4.4 Governed path coverage

**Definition:** proportion of agent-originated changes that pass through the governed pipeline with a complete audit trail — construction-time constraints, CI policy gates, runtime guardrails, decision record.

**Why it belongs in a leadership pack at a reinsurer:** this is the metric that converts to regulatory and audit position rather than delivery speed. The question "can you demonstrate what the automated system did, under what constraints, and who approved it" has a cost attached to answering it badly. Coverage is the leading indicator of our ability to answer it well.

This metric is also the one that distinguishes our position from ungoverned adoption elsewhere in the market, and it is currently absent from every off-the-shelf measurement framework.

### 4.5 Adoption share

**Definition:** proportion of delivered work items with agent involvement.

**Why leadership needs it:** it is the multiplier on everything above, and it distinguishes two very different situations that otherwise look identical. Strong metrics at 15% adoption is an investment case. Strong metrics at 80% adoption is a mature capability. Weak metrics at low adoption is a pilot that has not been given a fair trial.

---

## 5. The value bridge: converting engineering signal to money

Three methods are available. The recommendation is to use the first as primary and the others as supporting colour, because only the first survives contact with Finance.

**Capacity method (recommended).** Hours released × fully loaded cost. Conservative, auditable, uses figures Finance already owns.
*Limitation, stated up front:* it counts input saved, not value created, and overstates return if capacity is not visibly redeployed.

**Throughput method.** Additional items delivered × value per item. Theoretically superior. Requires the PO to assign monetary value to work items, which in practice is rarely available and rarely defensible. Use only where a work item has a directly attributable revenue or cost line.

**Avoided-cost method.** Defects caught before production × average cost of a production defect; audit-preparation effort avoided. Useful for Section 4.4, but the counterfactual is weak — we are estimating incidents that did not happen. Present it as supporting evidence, never as the headline number.

---

## 6. What we will explicitly not report

Naming these up front is a deliberate move. It prevents a vanity metric being requested later, and it signals that the numbers we do report were not selected for flattery.

- **Percentage of code written by AI.** Measures volume of generated text. Rises when quality falls, because poor output is regenerated. It is the single most misleading metric in this space.
- **Token spend as a standalone figure.** Meaningless without a denominator; small enough against engineer cost to be a distraction either way.
- **Commit, PR or line counts.** Reliably inflated by agentic tooling. Reporting them upward is measurement theatre.
- **Per-engineer agent usage.** Creates an incentive to use agents where they do not help, and converts a capability question into a surveillance one.
- **Time saved, self-reported.** Survey-based estimates of hours saved are systematically optimistic and cannot be reconciled against any system of record.

---

## 7. Method, baselines, and where this could be wrong

Including this section is what makes the rest defensible under challenge.

**The counterfactual.** Comparison is against a concurrent non-agent cohort, drawn from the same data model via agent-involvement flagging on work items. Historical pre-adoption cycle time is available as a secondary check.

**The principal threat to validity — selection bias.** Engineers choose agents for tasks agents are good at. Well-specified, well-bounded, low-ambiguity work flows to the agent path; gnarly, under-specified work does not. This biases every agent-versus-human comparison in the agent's favour, and it is not a small effect.

*Mitigation:* segment all comparisons by work item type and size band, and treat any unsegmented headline comparison as inadmissible. Where segmentation leaves cells too small to be meaningful, say so rather than aggregating past it.

**Attribution decay.** Agent involvement is recorded at change level. A feature touched by twelve changes, three of them agent-assisted, is not cleanly attributable. Reported at the aggregate level this washes out; reported per-feature it does not. Leadership metrics are therefore aggregate only.

**Work stream separation.** Platform and harness construction must be reported separately from team delivery. Building the measurement and governance capability consumes engineering capacity and produces no delivered work items — folded into delivery metrics it makes the programme look worse the more we invest in it. It should be presented as capability investment, on its own line.

**Maturity effects.** Early numbers reflect a capability being learned, not a capability at steady state. Four quarters of trend is the minimum honest basis for a scaling decision. A single quarter should not be used to kill or scale the programme, and agreeing that now protects the decision from the first noisy data point.

---

## 8. Phasing and cost of measurement

**Phase 1 — weeks 1–4. Instrument and validate.**
Tier 1 collection into the existing reporting stack. Output: squad-level flow and agent-effectiveness metrics. Success condition is that the numbers reconcile against the systems of record, not that they look good.

**Phase 2 — weeks 5–8. Baseline.**
Establish the non-agent comparison cohort and historical baseline. Agree cost assumptions with Finance in writing. No leadership reporting during this phase — reporting before the baseline exists produces a number with nothing to compare it to, and first impressions of a metric are difficult to correct later.

**Phase 3 — weeks 9–12. First leadership pack.**
Five metrics, trend where available, method and limitations attached.

**Cost of the measurement itself** should be stated explicitly in the pack: engineering effort to build and maintain collection, plus the tooling line. A measurement programme that consumes a material share of the capacity it is measuring is not worth running, and leadership is entitled to see that trade.

---

## 9. The decision this informs

Proposed decision gate at the end of Q[X], with thresholds agreed *now*:

- **Scale** — cost per qualified change trending down, quality differential neutral or better, governed path coverage above the agreed floor.
- **Hold and improve** — mixed signal, with a named hypothesis about the constraint and a defined next measurement window.
- **Redirect** — quality differential materially worse, or cost per qualified change flat with adoption above the threshold at which we would expect leverage.

Agreeing the thresholds before the data arrives is the difference between measurement and justification.

---

## Appendix A — Metric lineage

| Leadership metric | Source tier-1 signals | System of record |
|---|---|---|
| Cost per production-qualified change | Session token cost; PR merge and survival; reviewer time | Observability platform, source control |
| Engineer capacity redeployed | Cycle time delta by cohort; work item throughput | Work tracking |
| Quality differential | Change failure rate; 30-day revert/defect rate | Pipeline, incident records |
| Governed path coverage | Policy gate outcomes; audit trail completeness | Governance platform |
| Adoption share | Agent involvement flag on delivered items | Work tracking, observability platform |

## Appendix B — Open items for review

- Fully loaded engineer cost figure, and whether it may be used in a pack at this distribution level — requires Finance.
- Depth of usable historical baseline in the work tracking system prior to adoption.
- Audience and distribution: engineering leadership only, or wider BU.
- Whether governed path coverage has a defensible floor already defined, or needs one setting.
- Whether the quality differential should be reported against an agreed tolerance band rather than as a raw comparison.
