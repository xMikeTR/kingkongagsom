# Dropping LiteLLM: what we lose, and the options

## Why it was dropped

In March 2026, two LiteLLM releases (1.82.7 and 1.82.8) were published to
**PyPI** with a credential stealer. They were live for under an hour before
quarantine. The entry point was upstream: the TeamPCP campaign compromised the
Trivy scanner used in LiteLLM's CI, took publishing credentials, and pushed
the malicious versions directly. The same campaign also hit npm, GitHub
Actions, Docker Hub and OpenVSX.

The lesson isn't really "LiteLLM is unsafe". Any gateway is a prime target:
it holds every provider credential and sees every prompt. So whatever sits
in that position needs the tightest supply-chain controls we have. That
applies to Claude Code too, which ships through npm.

## What we lose

| LiteLLM gave us | Status without it | Mitigation |
|---|---|---|
| **GenAI OTel spans per model call** (Langfuse trace trees for every call) | Lost. APIM emits logs and metrics, not spans. | Langfuse gets traces from instrumented agents (OpenInference/OpenLLMetry, MCP gateway, own harness). Gateway-level calls are visible in New Relic only. |
| **One OpenAI-compatible API over every provider** | Lost. Clients speak each provider's native API. | Vertex has an OpenAI-compatible endpoint for some models. Claude on Vertex stays Anthropic-format. Agent frameworks (MAF, Pydantic AI) already abstract providers. |
| **Per-user virtual keys with USD budgets** | Partly replaced. APIM `llm-token-limit` gives per-user **token** quotas keyed on Entra identity. | Convert £750/month into a token quota per model mix. Alert on spend in New Relic before the hard limit. |
| **Cost per call** (built-in model price map) | Lost at the gateway. | Tokens × `model-prices.csv` lookup in New Relic, using contract rates rather than list prices. |
| **Fallbacks, retries, load balancing** | Covered. | APIM backend pools with circuit breakers. |
| **Caching** | Covered, with limits. | APIM semantic cache policies. Check they support your backends. |
| **Guardrail hooks** | Partly covered. | APIM content safety policy. mlang/ACS remains the semantic layer. |
| **Admin UI for keys and spend** | Lost. | APIM portal plus New Relic dashboards. Less convenient for self-service. |

**Net:** cost, quotas, routing and health are recoverable in APIM + New
Relic. The real losses are **per-call spans** and **format translation**.

## Options

### A. APIM only (current)
Everything in `clients/apim/ai-gateway-policy.xml`.
- **For:** no third-party code in the request path. Microsoft-supported,
  already owned, Entra-native, managed identity to backends.
- **Against:** no GenAI spans, token-based budgets, no format translation.
  Verify the `llm-*` policies parse usage from the Vertex backend.
- **Fits when:** visibility and spend control matter more than a unified API.

### B. Compiled gateway behind APIM
APIM stays the perimeter; a small, single-binary gateway sits behind it for
translation and spans. Candidates worth evaluating:
- **agentgateway** (Rust, Linux Foundation, Apache-2.0): LLM, MCP and A2A
  in one proxy with OTel. Closest fit to your MCP gateway and agent-traffic
  direction.
- **Envoy AI Gateway** (Apache-2.0): reached v1.0 in June 2026. Strong
  lineage, but Kubernetes-first, so a poor fit for Container Apps.
- **Bifrost** (Go, Apache-2.0): OTel GenAI traces, virtual keys, budgets.
  Vendor-backed (Maxim), and most comparison articles ranking it first are
  Maxim's own. Judge it on a spike, not on those.
- **For:** get spans and translation back. A compiled binary has a much
  smaller runtime dependency surface than a Python package tree.
- **Against:** another component to patch and own. Same supply-chain risk
  class, just smaller.

### C. Build a thin one
A small .NET proxy (e.g. YARP) or an extension of your MCP gateway that
forwards to APIM and emits GenAI OTel spans.
- **For:** C# fits the org, and the dependency tree is yours. It's the
  "buy the perimeter, build the semantics" pattern.
- **Against:** you own maintenance, and provider format translation is more
  work than it looks. Scope it to spans only, not translation.

## Controls that apply to any option

- Pin container images **by digest**, not tag. Verify signatures where published.
- Pull packages through an internal mirror (Azure Artifacts upstreams) with a
  minimum-age delay, so a poisoned release has time to be caught before you pull it.
- No provider keys in the gateway's environment. Use APIM managed identity to
  backends so a compromised process has nothing to steal.
- Lock gateway egress to known model endpoints plus the collector.
- Keep the gateway image off the build hosts that hold publishing credentials.
