# Implementation plan (PoV, one squad)

Replaces `agentic-ops-implementation.md` (Oct 2026). Same phases in spirit;
the join key is now our own work-item ID with Jira as an alias, and Copilot is
in scope. The design rationale lives in the PoV doc ("BU AI Observability
Layer — PoV Plan"). Each phase has a "done when".

## Phase 0: Contract and foundations

- [ ] Agree `contracts/events.md` v0 with whoever will consume it.
- [ ] Pick the branch convention: ticket key in the name (`RE-1234-short-desc`).
      Set `AI_OBS_TICKET_REGEX` if keys look different.
- [ ] Run `python adapters/jira/sync_work_items.py --jql "project = RE"` once to
      mint IDs for existing issues (`data/aliases.csv`, `data/work_items.csv`).
- [ ] Upload `data/aliases.csv`, `newrelic/org-lookup.csv`, `newrelic/model-prices.csv`
      as New Relic lookup tables (`aliases`, `org`, `prices`).
- [ ] Deploy the collector (`deploy/deploy.sh`). Check `/` on port 13133 is healthy.

Done when: a test OTLP log posted to the collector shows up in New Relic with
`org.bu=hiscox-re` and `telemetry.pipeline=agentic-ops`.

## Phase 1: Capture

- [ ] **Claude Code.** IT pushes `clients/claude-code/managed-settings.json` and
      copies `hooks/session-start.ps1` to `C:\ProgramData\ai-obs\`. Identity via
      `set-identity.ps1` (Intune, user context).
- [ ] **Copilot.** Enterprise admin sets the managed OTel destination
      (`clients/copilot/README.md`). Schedule `adapters/github/copilot_usage.py` daily.
- [ ] **APIM.** Apply `clients/apim/ai-gateway-policy.xml` to a test API against
      the Vertex backend; confirm token metrics populate. Diagnostic setting to
      Event Hub with message logging OFF.
- [ ] **GitHub.** Add `adapters/github/delivery-events.yml` to the squad repos;
      the QA gate calls `emit_event.py QAGatePassed` / `QABouncedBack`.
- [ ] **Jira.** Schedule the sync daily; optionally add the Automation rule
      (`adapters/jira/automation-rule.md`) for real-time status.
- [ ] **Devs.** Each runs `tools/dev-setup.ps1` once.

Done when: for one ticket you can see, in New Relic, its session(s), cost,
CI runs, PR and QA gate result, all carrying the same alias.

## Phase 2: Consume

- [ ] Agentic Ops dashboard from `newrelic/dashboard-queries.nrql`. Per-user
      widgets go on a restricted page; team-level on the shared one.
- [ ] Export with `newrelic/value-view-exports.nrql` into `data/`, run
      `valueview/value_view.py`, load `out/value_view.csv` + `metric_catalogue.csv`
      into Power BI (star schema: metric table as fact; date, org, task class,
      model and catalogue as dimensions; filter `org_level` per page).
- [ ] Optional: Langfuse overlay on your own machine only.

Done when: one Power BI page shows cost per delivered work item next to
first-pass QA rate, with suppression visible (blank, not zero).

## Phase 3: Prove

- [ ] Run two to three weeks with the squad.
- [ ] Check the success criteria: coverage ≥ 90%, attribution ≥ 80%, value page live.
- [ ] Swap test: replace the Jira sync with the fixture (`--fixture`) and confirm
      nothing downstream changes.
- [ ] Review with the Engineering Manager and Head of Platform.

## Phase 7: Model effectiveness ("would another model do as well?")

Leadership question: which model gives the best task success per unit cost,
per kind of task?

### 7.0 The confound (read first)
Model choice is correlated with task difficulty — people pick bigger models
for harder work. **Never report raw pass rate by model from production
data.** Always compare within the same `task_class` × `task_size` bucket, and
treat the replay benchmark (7.2) as the authoritative answer.

### 7.1 Observational layer (from production telemetry)
- `task_class` from Jira issue type + labels (Jira adapter); `task_size` from story points.
- `outcome` per ticket: `pass` = reached Ready for QA via the QA gate on first
  gate run; `reworked` = gate failed then later passed, or ticket reopened;
  `fail` / `abandoned` = never passed / closed without merge.
- `attempt_n` = count of gate runs for the ticket.
- Emit a `TaskOutcome` event (model = dominant model by tokens on the ticket,
  task_class, task_size, outcome, attempt_n, cost_usd, wallclock_hours) when a
  ticket reaches a terminal state.

### 7.2 Replay benchmark (authoritative)
An internal SWE-bench-style suite on our own codebase. See `bench/README.md`.

### 7.3 Metrics
- **Headline:** cost per passed task = `sum(cost_usd) / count(outcome = pass)`, by model × task class.
- **Effectiveness:** pass@1, pass@k, human-intervention rate, rework/reopen rate, defect escape, review rejection rate.
- **Efficiency:** tokens/turns/tool calls per task, wall-clock, cache hit rate, stall/stuck-loop rate.
- **Output quality:** mutation score, CRAP/complexity delta, lint/security findings on AI changes.
- **Reliability:** tool-call error rate, retries, abandoned sessions.
- Always show **confidence intervals** (Wilson for pass rates) and n. Don't rank
  models whose intervals overlap — call them equivalent.

### 7.4 Dashboard
- **Model frontier:** cost per task (x) vs pass@1 (y), one point per model,
  faceted by task class. Models on the Pareto frontier are the recommendation.
- Table: model × task class with pass@1 (CI), cost per passed task, n.
- Production vs bench side by side, so drift between "lab" and "real" is visible.

### 7.5 Later: randomised routing
Once 7.2 shows equivalence for a low-risk task class, propose (to APIM owners)
routing a small random share of that class to the cheaper model and comparing
`TaskOutcome`. Requires sign-off; do not implement unilaterally.

## Open questions

1. Copilot session attribution: is there a session ID / hook to record the branch?
2. Does the SessionStart hook's session_id match Claude Code's OTel `session.id`?
3. Which user attribute does Copilot's OTel carry, and does it map to the Entra oid?
4. Can Claude Code on Vertex route through APIM without breaking auth or streaming?
5. Claude Code client-side cost vs the Vertex bill: agree a tolerance.
6. Group's LiteLLM: spend logs (Postgres), OTLP, or both? Which identity key?
7. Which models are available to benchmark via Vertex/APIM, and the bench budget.
8. Mapping from Jira issue types/labels to `task_class` (defaults in the Jira adapter).
9. New Relic AI Evaluation preview access.
