#!/usr/bin/env python3
"""Pull GitHub Copilot per-user daily usage and emit AIUsage events
(billing_source=github). This is the billing truth for Copilot: its traffic
never touches APIM.

API: REST "Copilot usage metrics" (enterprise/org reports, API version
2026-03-10). Reports are returned as download links to NDJSON files.
VERIFY the exact response shape against your enterprise before relying on
it; the parser below is defensive and skips records it does not recognise.

Usage:
  python adapters/github/copilot_usage.py --enterprise hiscox --day 2026-11-17
  python adapters/github/copilot_usage.py --ndjson sample.ndjson --dry-run   # offline

Env: GH_TOKEN (enterprise admin / org owner token with Copilot metrics read)
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.request

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from obs.events import make_event  # noqa: E402
from obs.ids import WI_UNASSIGNED  # noqa: E402
from obs.nr import NewRelicSender  # noqa: E402

API = "https://api.github.com"
API_VERSION = "2026-03-10"


def _get(url: str, token: str | None):
    headers = {"Accept": "application/vnd.github+json", "X-GitHub-Api-Version": API_VERSION}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=60) as r:
        return r.read().decode()


def fetch_records(enterprise: str, day: str, token: str) -> list[dict]:
    meta = json.loads(_get(f"{API}/enterprises/{enterprise}/copilot/metrics/reports/users-1-day?day={day}", token))
    links = meta.get("download_links") or meta.get("links") or []
    records = []
    for link in links:
        url = link if isinstance(link, str) else link.get("url")
        if url:
            records += parse_ndjson(_get(url, None))
    return records


def parse_ndjson(text: str) -> list[dict]:
    out = []
    for line in text.splitlines():
        line = line.strip()
        if line:
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return out


def to_events(records: list[dict], day: str) -> list[dict]:
    events = []
    for r in records:
        user = r.get("user_login") or r.get("user") or r.get("login")
        credits = r.get("ai_credits_used")
        if not user or credits is None:
            continue
        tokens = r.get("token_usage") or {}
        events.append(make_event("AIUsage", "/bu-ai-obs/adapters/copilot-usage", WI_UNASSIGNED, {
            "harness": "copilot",
            "gen_ai.request.model": r.get("model") or "copilot-mixed",
            "billing_source": "github",
            "enduser.id": str(user).lower(),
            "ai_credits_used": credits,
            "gen_ai.usage.input_tokens": tokens.get("prompt_tokens_sum"),
            "gen_ai.usage.output_tokens": tokens.get("output_tokens_sum"),
            "usage_date": r.get("date") or r.get("day") or day,
        }))
    return events


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--enterprise")
    ap.add_argument("--day", help="YYYY-MM-DD (defaults to the report's own date field)")
    ap.add_argument("--ndjson", help="parse a local NDJSON report instead of calling the API")
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args(argv)
    if a.ndjson:
        with open(a.ndjson, encoding="utf-8") as fh:
            records = parse_ndjson(fh.read())
    else:
        if not (a.enterprise and a.day):
            raise SystemExit("--enterprise and --day are required unless --ndjson is given")
        records = fetch_records(a.enterprise, a.day, os.environ["GH_TOKEN"])
    events = to_events(records, a.day or "")
    n = NewRelicSender(dry_run_path="events.ndjson" if a.dry_run else None).send(events)
    print(f"{len(records)} records -> {n} AIUsage events")
    return 0


if __name__ == "__main__":
    sys.exit(main())
