#!/usr/bin/env python3
"""Emit one canonical delivery event from a GitHub Actions job.

The branch is turned into a tracker alias here; the work-item ID is resolved
downstream (CI has no alias table), so events go out with
subject=wi_unassigned and the alias in the `workitemalias` extension.
If --aliases points at a checked-out alias table, it resolves in place.

Examples (in a workflow step):
  python adapters/github/emit_event.py CIRunCompleted \
      --branch "$GITHUB_HEAD_REF" --set repo="$GITHUB_REPOSITORY" run_id="$GITHUB_RUN_ID" \
      conclusion=success attempt="$GITHUB_RUN_ATTEMPT"
  python adapters/github/emit_event.py QAGatePassed --branch "$GITHUB_HEAD_REF" --set attempt_n=1

Env: NEW_RELIC_ACCOUNT_ID, NEW_RELIC_LICENSE_KEY (repo secrets), NEW_RELIC_REGION=eu
"""
from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from obs.aliases import AliasTable, normalise  # noqa: E402
from obs.events import CONTRACT, make_event  # noqa: E402
from obs.ids import WI_UNASSIGNED  # noqa: E402
from obs.nr import NewRelicSender  # noqa: E402

NUMERIC = {"attempt", "attempt_n", "duration_s", "pr_number", "mutation_score", "task_size"}


def parse_sets(pairs: list[str]) -> dict:
    data = {}
    for p in pairs:
        k, _, v = p.partition("=")
        if not _:
            raise SystemExit(f"--set expects key=value, got {p!r}")
        if k in NUMERIC and v:
            try:
                v = float(v) if "." in v else int(v)
            except ValueError:
                raise SystemExit(f"{k} must be numeric, got {v!r}")
        data[k] = v
    return data


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("type", choices=sorted(CONTRACT))
    ap.add_argument("--branch", default=os.environ.get("GITHUB_HEAD_REF") or os.environ.get("GITHUB_REF_NAME", ""))
    ap.add_argument("--aliases", help="alias table CSV, if available in the job")
    ap.add_argument("--set", nargs="*", default=[], metavar="key=value")
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args(argv)

    data = parse_sets(a.set)
    if a.branch and "branch" in CONTRACT[a.type][1] and "branch" not in data:
        data["branch"] = a.branch
    alias = normalise(a.branch)
    subject = AliasTable(a.aliases).resolve(alias) if (a.aliases and alias) else WI_UNASSIGNED
    ev = make_event(a.type, "/bu-ai-obs/adapters/github", subject, data, alias=alias)
    n = NewRelicSender(dry_run_path="events.ndjson" if a.dry_run else None).send([ev])
    print(f"emitted {n} {a.type} alias={alias or '-'} subject={subject}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
