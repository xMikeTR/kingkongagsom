#!/usr/bin/env python3
"""Jira adapter: the only component that knows Jira exists.

Polls Jira for issues changed since the last run, mints our work-item IDs for
new keys (alias table), and emits canonical work events. Also writes the
work_items.csv snapshot the value view reads.

Moving to Azure DevOps = write adapters/ado/ that emits the same events and
calls AliasTable.link('ado:AB#...', 'jira:RE-...') for migrated items.

Usage:
  python -m adapters.jira.sync_work_items --jql "project = RE" \
      --aliases data/aliases.csv --out data/work_items.csv
  # offline / test:
  python -m adapters.jira.sync_work_items --fixture adapters/jira/fixture.json --dry-run

Env: JIRA_BASE_URL, JIRA_EMAIL, JIRA_API_TOKEN,
     JIRA_TEAM_FIELD (e.g. customfield_10001), JIRA_POINTS_FIELD (e.g. customfield_10016)
"""
from __future__ import annotations

import argparse
import base64
import csv
import json
import os
import sys
import urllib.request
from datetime import datetime, timezone

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from obs.aliases import AliasTable  # noqa: E402
from obs.events import make_event  # noqa: E402
from obs.nr import NewRelicSender  # noqa: E402

SOURCE = "/bu-ai-obs/adapters/jira"
SNAPSHOT_FIELDS = ["work_item_id", "alias", "task_class", "task_size", "team", "work_stream",
                   "status", "created_at", "done_at"]
DEFAULT_CLASS_MAP = {
    "issuetype": {"Bug": "bug", "Story": "feature", "Task": "feature", "Spike": "feature", "Sub-task": "feature"},
    "labels": {"refactor": "refactor", "tests": "test", "test": "test", "migration": "migration", "data": "data"},
    "work_stream_labels": {"platform": "platform", "rnd": "rnd", "r-and-d": "rnd"},
}


def fetch_issues(jql: str, fields: list[str]) -> list[dict]:
    """Jira Cloud enhanced search (POST /rest/api/3/search/jql, token paging).
    VERIFY against your Jira instance; Server/DC uses /rest/api/2/search."""
    base = os.environ["JIRA_BASE_URL"].rstrip("/")
    auth = base64.b64encode(f"{os.environ['JIRA_EMAIL']}:{os.environ['JIRA_API_TOKEN']}".encode()).decode()
    issues, token = [], None
    while True:
        body = {"jql": jql, "fields": fields, "maxResults": 100}
        if token:
            body["nextPageToken"] = token
        req = urllib.request.Request(f"{base}/rest/api/3/search/jql", data=json.dumps(body).encode(),
                                     method="POST", headers={"Authorization": f"Basic {auth}",
                                                             "Content-Type": "application/json",
                                                             "Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=60) as resp:
            page = json.load(resp)
        issues.extend(page.get("issues", []))
        token = page.get("nextPageToken")
        if page.get("isLast", True) or not token:
            return issues


def classify(fields: dict, class_map: dict) -> tuple[str, str]:
    labels = [str(l).lower() for l in (fields.get("labels") or [])]
    work_stream = next((v for k, v in class_map["work_stream_labels"].items() if k in labels), "team_delivery")
    for label, cls in class_map["labels"].items():
        if label in labels:
            return cls, work_stream
    itype = (fields.get("issuetype") or {}).get("name", "")
    return class_map["issuetype"].get(itype, "other"), work_stream


def team_value(raw) -> str:
    if isinstance(raw, dict):
        return str(raw.get("name") or raw.get("value") or raw.get("title") or "")
    return str(raw or "")


def run(issues: list[dict], aliases: AliasTable, state: dict, class_map: dict,
        team_field: str, points_field: str) -> tuple[list[dict], list[dict]]:
    events, snapshot = [], []
    for issue in issues:
        f = issue.get("fields", {})
        alias = f"jira:{issue['key']}"
        is_new = aliases.resolve(alias) == "wi_unassigned"
        wi = aliases.ensure(alias)
        task_class, work_stream = classify(f, class_map)
        status = (f.get("status") or {}).get("name", "")
        category = ((f.get("status") or {}).get("statusCategory") or {}).get("key", "")
        points = f.get(points_field) if points_field else None
        team = team_value(f.get(team_field)) if team_field else ""
        done_at = f.get("resolutiondate") if category == "done" else None
        prev = state.get(alias, {})

        if is_new:
            events.append(make_event("WorkItemCreated", SOURCE, wi, {
                "alias": alias, "task_class": task_class, "task_size": points, "team": team,
                "work_stream": work_stream, "created_at": f.get("created")}))
        if prev.get("status") != status:
            events.append(make_event("WorkItemStatusChanged", SOURCE, wi, {
                "alias": alias, "from_status": prev.get("status"), "to_status": status,
                "status_category": category, "changed_at": f.get("updated")}))
        if done_at and not prev.get("done_at"):
            events.append(make_event("WorkItemDone", SOURCE, wi, {"alias": alias, "done_at": done_at}))

        state[alias] = {"status": status, "done_at": done_at}
        snapshot.append({"work_item_id": wi, "alias": alias, "task_class": task_class,
                         "task_size": points if points is not None else "", "team": team,
                         "work_stream": work_stream, "status": status,
                         "created_at": f.get("created", ""), "done_at": done_at or ""})
    return events, snapshot


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--jql", default="updated >= -7d ORDER BY updated ASC")
    ap.add_argument("--fixture", help="read issues from a JSON file instead of Jira")
    ap.add_argument("--aliases", default="data/aliases.csv")
    ap.add_argument("--state", default="data/jira-state.json")
    ap.add_argument("--out", default="data/work_items.csv")
    ap.add_argument("--class-map", help="JSON file overriding the task-class mapping")
    ap.add_argument("--dry-run", action="store_true", help="write events to events.ndjson instead of New Relic")
    a = ap.parse_args(argv)

    for p in (a.aliases, a.state, a.out):
        os.makedirs(os.path.dirname(os.path.abspath(p)), exist_ok=True)
    class_map = DEFAULT_CLASS_MAP
    if a.class_map:
        with open(a.class_map, encoding="utf-8") as fh:
            class_map = {**DEFAULT_CLASS_MAP, **json.load(fh)}
    team_field = os.environ.get("JIRA_TEAM_FIELD", "")
    points_field = os.environ.get("JIRA_POINTS_FIELD", "")

    if a.fixture:
        with open(a.fixture, encoding="utf-8") as fh:
            issues = json.load(fh)["issues"]
    else:
        fields = ["issuetype", "status", "labels", "created", "updated", "resolutiondate"]
        fields += [x for x in (team_field, points_field) if x]
        issues = fetch_issues(a.jql, fields)

    aliases = AliasTable(a.aliases)
    state = {}
    if os.path.exists(a.state):
        with open(a.state, encoding="utf-8") as fh:
            state = json.load(fh)

    events, snapshot = run(issues, aliases, state, class_map, team_field, points_field)

    sender = NewRelicSender(dry_run_path="events.ndjson" if a.dry_run else None)
    sent = sender.send(events)
    aliases.save()
    with open(a.state, "w", encoding="utf-8") as fh:
        json.dump(state, fh, indent=1)
    # merge snapshot into existing work_items.csv (latest wins)
    rows = {}
    if os.path.exists(a.out):
        with open(a.out, newline="", encoding="utf-8") as fh:
            rows = {r["work_item_id"]: r for r in csv.DictReader(fh)}
    rows.update({r["work_item_id"]: r for r in snapshot})
    with open(a.out, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=SNAPSHOT_FIELDS)
        w.writeheader()
        w.writerows(rows.values())
    print(f"{len(issues)} issues, {sent} events, {len(aliases)} aliases, "
          f"{len(rows)} work items -> {a.out}  ({datetime.now(timezone.utc):%Y-%m-%dT%H:%MZ})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
