# Jira Automation rule (real-time alternative to polling)

`sync_work_items.py` polls and owns ID minting. For near-real-time status
changes without hosting anything, add a Jira Automation rule that posts
straight to New Relic. It sends the Jira key as an alias; the work-item ID is
resolved at query time through the `aliases` lookup table in New Relic, and by
the value view.

Run the poller at least daily anyway: it is what mints IDs for new issues.

## Rule

- **Trigger:** Issue transitioned (and optionally Issue created)
- **Condition:** Project = RE (and any squad filter)
- **Action:** Send web request
  - URL: `https://insights-collector.eu01.nr-data.net/v1/accounts/<ACCOUNT_ID>/events`
  - Method: `POST`
  - Headers: `Api-Key: <ingest licence key>` (store it as a secret/hidden header),
    `Content-Type: application/json`
  - Body (custom data):

```json
[{
  "eventType": "WorkItemStatusChanged",
  "work_item.id": "wi_unassigned",
  "work_item.alias": "jira:{{issue.key}}",
  "alias": "jira:{{issue.key}}",
  "from_status": "{{fieldChange.fromString}}",
  "to_status": "{{issue.status.name}}",
  "status_category": "{{issue.status.statusCategory.key}}",
  "changed_at": "{{now.jiraDateTime}}",
  "ce.source": "/bu-ai-obs/adapters/jira-automation",
  "org.bu": "hiscox-re",
  "telemetry.pipeline": "agentic-ops"
}]
```

VERIFY the smart-value names in your Jira instance's rule editor before
enabling. This mirrors the canonical `WorkItemStatusChanged` event in its flat
New Relic form (see `contracts/events.md`).
