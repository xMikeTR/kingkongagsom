# One-time dev setup. Run once per machine:
#   powershell -ExecutionPolicy Bypass -File tools\dev-setup.ps1 -Team pricing-platform
# It sets your identity attributes, checks that IT's managed settings are in
# place, and sends one test event so you can see you're covered.
param(
  [Parameter(Mandatory)] [string] $Team,
  [string] $Bu = 'hiscox-re',
  [string] $Collector = $env:OTEL_EXPORTER_OTLP_ENDPOINT,
  [string] $Token
)
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Split-Path -Parent $here

Write-Output '1/4 Identity attributes'
& (Join-Path $root 'clients\claude-code\set-identity.ps1') -Team $Team -Bu $Bu

Write-Output '2/4 Managed settings and hook'
# VERIFY the managed-settings path for your Claude Code version.
$managed = 'C:\Program Files\ClaudeCode\managed-settings.json'
$hook = 'C:\ProgramData\ai-obs\session-start.ps1'
foreach ($p in @($managed, $hook)) {
  if (Test-Path $p) { Write-Output "  ok  $p" } else { Write-Output "  MISSING  $p  (ask IT to push it, or copy it for a local test)" }
}

Write-Output '3/4 Branch convention'
$branch = (git branch --show-current 2>$null | Out-String).Trim()
$pattern = if ($env:AI_OBS_TICKET_REGEX) { $env:AI_OBS_TICKET_REGEX } else { '([A-Z][A-Z0-9]+-[0-9]+|AB#[0-9]+)' }
if (-not $branch) { Write-Output '  (not in a git repo; skipped)' }
elseif ($branch -match $pattern) { Write-Output "  ok  '$branch' -> $($Matches[1])" }
else { Write-Output "  WARN  '$branch' has no ticket key: sessions here count as unassigned" }

Write-Output '4/4 Test event'
if (-not $Collector) { Write-Output '  skipped: pass -Collector https://<fqdn> (or set OTEL_EXPORTER_OTLP_ENDPOINT)'; exit 0 }
if (-not $Token -and $env:OTEL_EXPORTER_OTLP_HEADERS -match 'Bearer\s+([^,]+)') { $Token = $Matches[1] }
$user = (whoami /upn).Trim().ToLower()
$payload = @{ session_id = "setup-test-$([guid]::NewGuid().ToString('N').Substring(0,8))"; cwd = (Get-Location).Path; source = 'dev-setup' } | ConvertTo-Json -Compress
$env:OTEL_EXPORTER_OTLP_ENDPOINT = $Collector
if ($Token) { $env:OTEL_EXPORTER_OTLP_HEADERS = "Authorization=Bearer $Token" }
$payload | powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'clients\claude-code\hooks\session-start.ps1')
Write-Output "  sent. In New Relic: FROM Log SELECT * WHERE event.name = 'ai_session_started' AND enduser.id = '$user' SINCE 10 minutes ago"
