#!/usr/bin/env python3
"""Turn the repo into PowerShell paste blocks, for machines where zip files
and GitHub can't reach (the work VM). Each part writes its files under
$HOME\\bu-ai-observability and prints 'wrote <path>' per file.

  python tools/make_paste_blocks.py > paste-blocks.md
"""
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SKIP_DIRS = {".git", "__pycache__", "data", "out", "dist"}
SKIP_FILES = {"events.ndjson", "paste-blocks.md"}
MAX_CHARS = 7000

HEADER = ("$root = Join-Path $HOME 'bu-ai-observability'\n"
          "$utf8 = New-Object System.Text.UTF8Encoding($false)\n"
          "function W($rel, $txt) { $p = Join-Path $root $rel; New-Item -ItemType Directory -Force "
          "(Split-Path $p) | Out-Null; [IO.File]::WriteAllText($p, ($txt -replace \"`r`n\", \"`n\") + \"`n\", $utf8); "
          "Write-Output \"wrote $rel\" }")


def files():
    out = []
    for d, dirs, fs in os.walk(ROOT):
        dirs[:] = sorted(x for x in dirs if x not in SKIP_DIRS)
        for f in sorted(fs):
            if f in SKIP_FILES or f.endswith(".pyc"):
                continue
            p = os.path.join(d, f)
            text = open(p, encoding="utf-8").read()
            if "\n'@" in text or text.startswith("'@"):
                sys.exit(f"{p} contains a here-string terminator; cannot embed safely")
            out.append((os.path.relpath(p, ROOT).replace("/", "\\"), text.rstrip("\n")))
    return out


def chunks(items):
    parts, cur, size = [], [], 0
    for rel, text in items:
        if cur and size + len(text) > MAX_CHARS:
            parts.append(cur)
            cur, size = [], 0
        cur.append((rel, text))
        size += len(text)
    if cur:
        parts.append(cur)
    return parts


def main():
    parts = chunks(files())
    print("Paste each part into PowerShell, in order. Each prints a 'wrote ...' line per file.\n")
    for i, part in enumerate(parts, 1):
        body = [f"# Part {i} of {len(parts)}", HEADER]
        body += [f"W '{rel}' @'\n{text}\n'@" for rel, text in part]
        print(f"**Part {i} of {len(parts)}**\n\n~~~~powershell\n" + "\n".join(body) + "\n~~~~\n")


if __name__ == "__main__":
    main()
