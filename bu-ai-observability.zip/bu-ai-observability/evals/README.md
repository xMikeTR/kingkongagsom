# Evals

Decision (Sep 2026): own the formats, rent the engines.

- Eval cases live as YAML in git (`evals/cases/*.yaml`), written from
  **observed failures** (e.g. stalled sessions, QA bounce-backs), not imagined ones.
- Any runner (Langfuse locally, GCP Agent Platform offline, a script) can
  execute them. Results go to New Relic as `EvalResult` events:

```bash
python adapters/github/emit_event.py EvalResult \
  --set suite=pricing-agent case_id=stall-001 passed=true gen_ai.request.model=claude-sonnet
```

- Keep work traces that contain prompts or code on the personal Langfuse
  instance until security has agreed data residency for eval datasets.
