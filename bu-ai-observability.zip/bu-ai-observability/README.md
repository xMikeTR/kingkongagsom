# BU AI observability layer (Hiscox RE)

Spend next to what it bought. Every AI session, CI run and QA result is tied
to one work item, so we can say "we spent X, and here is what it delivered".

Rebuilt Nov 2026 from the September Agentic Ops repo, the value view and the
October implementation brief, aligned to the PoV plan. Two changes from
before: everything joins on **our own work-item ID** (Jira keys are aliases),
and **Copilot** is captured alongside Claude Code.

```
Claude Code ─(OTel + SessionStart hook)─┐
Copilot ─────(managed OTel)─────────────┤
Own agents ──(OTel SDK)─────────────────┼─► BU OTel Collector ─► New Relic (system of record)
APIM v2 ─────(token metrics, Event Hub)─┘    (Container App)        │
Jira ────────(adapter: mints wi_ IDs)──────────────────────────────►├─► Power BI (value view)
GitHub ──────(CI, PR, QA gate events)──────────────────────────────►└─► Group LiteLLM (later: one exporter)
Langfuse: personal workbench only (local overlay)
```

## Decisions carried forward

- APIM is the only permitted route to model endpoints.
- New Relic is the operational system of record; Power BI is the leadership view.
- Langfuse stays a personal learning and eval workbench, not a production consumer.
- Evals are YAML cases in git; results go to New Relic as `EvalResult` events.
- No new hosted services until value is proven: New Relic custom events are
  the PoV's event stream.
- Own the formats (OTel, the event contract, eval cases); rent the engines.
- Per-person views are for that person; leadership sees team-level aggregates
  with suppression (hashed IDs, ≥ 3 distinct users per cell, complementary suppression).

## Layout

| Path | What |
|---|---|
| `contracts/events.md` | **The contract**: CloudEvents envelope, work-item IDs, aliases, event types |
| `obs/` | Shared core: ID minting, alias table, contract validation, New Relic sender |
| `collector/` | Collector config + APIM overlay + Langfuse (local) overlay + Dockerfile |
| `clients/claude-code/` | Managed settings, SessionStart hook (ps1 + py), identity scripts |
| `clients/copilot/` | How to capture Copilot (managed OTel, per-dev fallback, SDK) |
| `clients/apim/` | Gateway policy: Entra identity, per-user token quota (oid), token metrics, trace context |
| `adapters/jira/` | The only code that knows Jira: sync + mint IDs, Automation rule alternative |
| `adapters/github/` | CI / PR / QA gate events, Copilot usage (billing truth) |
| `newrelic/` | Dashboard NRQL, value-view export NRQL, org and price lookups |
| `valueview/value_view.py` | Power BI feed: leadership + eng + dev metrics with privacy by construction |
| `bench/` | Replay benchmark spec (Phase 7.2) and task template |
| `evals/` | Eval case format |
| `docs/` | Implementation plan, the leadership proposal, LiteLLM losses and alternatives |
| `deploy/`, `local/` | Container Apps deploy; local compose |
| `tools/` | Dev setup script; paste-block generator for the work VM |
| `tests/run_all.py` | All offline checks |

## Quick start

```bash
python tests/run_all.py                       # everything offline, no secrets
python valueview/value_view.py --selftest     # privacy properties on synthetic data
python tools/make_paste_blocks.py > paste-blocks.md   # for the work VM
```

Then follow `docs/IMPLEMENTATION.md`.

## Not verified here (do these first)

- `otelcol-contrib validate --config collector/otel-collector.yaml --config collector/otel-collector.apim.yaml`
  (the September config was validated against 0.135.0; `transform/harness`
  and the redaction patterns are new).
- Lines marked **VERIFY**: Copilot managed-settings keys, Jira search endpoint
  on your instance, Copilot usage API response shape, Claude Code
  managed-settings path on Windows, Jira Automation smart values.
- APIM `llm-*` policies against the Vertex backend.

## Cost source of truth

- Claude Code `cost.usage` is an estimate from list prices.
- APIM tokens × `model-prices.csv` (contract rates) is what finance will believe.
- Copilot: GitHub's AI credits per user (usage metrics API).
- Each `AIUsage` row carries `billing_source` so it reconciles against the right bill.
