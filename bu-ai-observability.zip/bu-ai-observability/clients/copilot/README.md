# GitHub Copilot capture

Copilot traffic goes to GitHub, not through APIM. We can **see** it (OTel and
the usage metrics API) but only **limit** it with GitHub's own budgets and
policies. Lines marked VERIFY were not tested against our tenant.

## 1. Telemetry (all surfaces): enterprise-managed settings

GitHub lets enterprise admins mandate where Copilot sends OpenTelemetry, for
the VS Code Copilot Chat extension, the agent host behind Copilot CLI, and the
Copilot app. Devs then need no OTEL_* setup.

- Endpoint: our collector, `https://<collector-fqdn>` (OTLP/HTTP)
- Header: `Authorization: Bearer <ingest-token>`
- Content capture: **off**
- Service name: `github-copilot` (the collector maps anything containing
  "copilot" to `harness=copilot`)

VERIFY: the exact keys of the `telemetry` block in `managed-settings.json`.
Reference: https://docs.github.com/en/copilot/reference/enterprise-administrators/opentelemetry-reference

## 2. Per-dev fallback (before the enterprise setting is live)

VS Code `settings.json`:

```json
{
  "github.copilot.chat.otel.enabled": true,
  "github.copilot.chat.otel.exporterType": "otlp-http",
  "github.copilot.chat.otel.otlpEndpoint": "https://<collector-fqdn>"
}
```

VERIFY: the setting name for the auth header and for content capture.

Copilot CLI (PowerShell profile):

```powershell
$env:COPILOT_OTEL_ENABLED = "true"
$env:COPILOT_OTEL_EXPORTER_TYPE = "otlp-http"
$env:OTEL_EXPORTER_OTLP_ENDPOINT = "https://<collector-fqdn>"
$env:OTEL_EXPORTER_OTLP_HEADERS = "Authorization=Bearer <ingest-token>"
$env:OTEL_SERVICE_NAME = "github-copilot"
```

## 3. Copilot SDK (agents people build on Copilot)

Telemetry is set in code: pass a `TelemetryConfig` when constructing the
`CopilotClient`, OTLP/HTTP to the collector, `captureContent: false`. Put this
in the "how to build an agent" template; it cannot be forced centrally.

## 4. Billing truth: usage metrics API

`adapters/github/copilot_usage.py` pulls per-user daily usage, including
`ai_credits_used`, and turns it into `AIUsage` events with
`billing_source=github`. Run it daily (GitHub Action on a schedule, or by hand).

## Known gaps

- **Attribution.** Copilot has no SessionStart hook we can use (VERIFY), so its
  sessions are attributed by repo and time window, not by branch at start.
- **Claude inside Copilot.** Claude sessions run through VS Code Copilot are
  billed by GitHub. They show up as `gen_ai.agent.name = claude` in Copilot's
  telemetry. Count them under `billing_source=github`, not APIM.
- **Cloud coding agent.** No documented OTel path found; covered by the usage
  metrics API only.
