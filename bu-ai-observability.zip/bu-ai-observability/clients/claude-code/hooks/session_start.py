#!/usr/bin/env python3
"""Claude Code SessionStart hook (macOS / Linux / WSL). Same contract as
session-start.ps1: emit one OTLP log record (event.name = ai_session_started)
with session.id + git branch, never block, never fail the session.

Reference it from settings as:
  "command": "python3 /opt/ai-obs/session_start.py"
"""
import json
import os
import re
import subprocess
import sys
import time
import urllib.request

DEFAULT_PATTERN = r"([A-Z][A-Z0-9]+-[0-9]+|AB#[0-9]+)"


def git(cwd, *args):
    try:
        return subprocess.run(["git", "-C", cwd, *args], capture_output=True,
                              text=True, timeout=2).stdout.strip()
    except Exception:
        return ""


def alias_from_branch(branch, pattern=None):
    m = re.search(pattern or DEFAULT_PATTERN, branch or "")
    if not m:
        return ""
    key = m.group(1)
    return f"ado:{key}" if key.startswith("AB#") else f"jira:{key}"


def parse_kv(s):
    out = {}
    for pair in (s or "").split(","):
        if "=" in pair:
            k, v = pair.split("=", 1)
            out[k.strip()] = urllib.request.unquote(v.strip())
    return out


def build_body(session_id, source, branch, repo, alias, resource):
    def a(k, v):
        return {"key": k, "value": {"stringValue": str(v)}}
    res = [a("service.name", "claude-code")] + [a(k, v) for k, v in resource.items()]
    return {"resourceLogs": [{
        "resource": {"attributes": res},
        "scopeLogs": [{
            "scope": {"name": "ai-obs.session-start", "version": "1"},
            "logRecords": [{
                "timeUnixNano": str(time.time_ns()),
                "body": {"stringValue": "ai_session_started"},
                "attributes": [
                    a("event.name", "ai_session_started"), a("session.id", session_id),
                    a("session.source", source), a("harness", "claude-code"),
                    a("git.branch", branch), a("git.repo", repo), a("work_item.alias", alias),
                ],
            }],
        }],
    }]}


def main():
    try:
        evt = json.loads(sys.stdin.read() or "{}")
        session_id = evt.get("session_id")
        endpoint = os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT")
        if not session_id or not endpoint:
            return
        cwd = evt.get("cwd") or os.getcwd()
        branch = git(cwd, "branch", "--show-current")
        remote = git(cwd, "remote", "get-url", "origin")
        repo = re.sub(r"^.*[/:]", "", re.sub(r"\.git$", "", remote)) if remote else ""
        alias = alias_from_branch(branch, os.environ.get("AI_OBS_TICKET_REGEX"))
        body = build_body(session_id, evt.get("source", ""), branch, repo, alias,
                          parse_kv(os.environ.get("OTEL_RESOURCE_ATTRIBUTES")))
        headers = {"Content-Type": "application/json",
                   **parse_kv(os.environ.get("OTEL_EXPORTER_OTLP_HEADERS"))}
        req = urllib.request.Request(endpoint.rstrip("/") + "/v1/logs",
                                     data=json.dumps(body).encode(), headers=headers)
        urllib.request.urlopen(req, timeout=3)
    except Exception:
        pass


if __name__ == "__main__":
    main()
    sys.exit(0)
