# Claude Code SessionStart hook (Windows).
# Emits one OTLP log record, event.name = ai_session_started, carrying the
# session id and the git branch. Attribution happens downstream: usage joins
# to this record on session.id, and the branch resolves to a work item via the
# alias table. Nothing in the running Claude Code process has to change.
#
# Contract: never block, never fail the session. Any error -> exit 0 silently.
# Install to C:\ProgramData\ai-obs\session-start.ps1 (Intune), referenced by
# managed-settings.json.
$ErrorActionPreference = 'SilentlyContinue'
try {
  $raw = [Console]::In.ReadToEnd()
  $evt = $raw | ConvertFrom-Json
  $sessionId = [string]$evt.session_id
  $cwd = [string]$evt.cwd
  $source = [string]$evt.source
  if (-not $sessionId) { exit 0 }

  $branch = ''
  $repo = ''
  if ($cwd -and (Get-Command git -ErrorAction SilentlyContinue)) {
    $branch = (git -C $cwd branch --show-current 2>$null | Out-String).Trim()
    $remote = (git -C $cwd remote get-url origin 2>$null | Out-String).Trim()
    if ($remote) { $repo = ($remote -replace '\.git$', '') -replace '^.*[/:]', '' }
  }

  $pattern = $env:AI_OBS_TICKET_REGEX
  if (-not $pattern) { $pattern = '([A-Z][A-Z0-9]+-[0-9]+|AB#[0-9]+)' }
  $alias = ''
  if ($branch -match $pattern) {
    $key = $Matches[1]
    if ($key -like 'AB#*') { $alias = "ado:$key" } else { $alias = "jira:$key" }
  }

  $endpoint = $env:OTEL_EXPORTER_OTLP_ENDPOINT
  if (-not $endpoint) { exit 0 }
  $headers = @{}
  if ($env:OTEL_EXPORTER_OTLP_HEADERS) {
    foreach ($pair in $env:OTEL_EXPORTER_OTLP_HEADERS.Split(',')) {
      $kv = $pair.Split('=', 2)
      if ($kv.Count -eq 2) { $headers[$kv[0].Trim()] = [Uri]::UnescapeDataString($kv[1].Trim()) }
    }
  }

  function A($k, $v) { @{ key = $k; value = @{ stringValue = [string]$v } } }

  $resAttrs = @((A 'service.name' 'claude-code'))
  if ($env:OTEL_RESOURCE_ATTRIBUTES) {
    foreach ($pair in $env:OTEL_RESOURCE_ATTRIBUTES.Split(',')) {
      $kv = $pair.Split('=', 2)
      if ($kv.Count -eq 2) { $resAttrs += (A $kv[0].Trim() $kv[1].Trim()) }
    }
  }

  $now = [string]([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() * 1000000)
  $body = @{
    resourceLogs = @(@{
      resource = @{ attributes = $resAttrs }
      scopeLogs = @(@{
        scope = @{ name = 'ai-obs.session-start'; version = '1' }
        logRecords = @(@{
          timeUnixNano = $now
          body = @{ stringValue = 'ai_session_started' }
          attributes = @(
            (A 'event.name' 'ai_session_started'),
            (A 'session.id' $sessionId),
            (A 'session.source' $source),
            (A 'harness' 'claude-code'),
            (A 'git.branch' $branch),
            (A 'git.repo' $repo),
            (A 'work_item.alias' $alias)
          )
        })
      })
    })
  } | ConvertTo-Json -Depth 12 -Compress

  Invoke-RestMethod -Method Post -Uri ($endpoint.TrimEnd('/') + '/v1/logs') `
    -Headers $headers -ContentType 'application/json' -Body $body -TimeoutSec 3 | Out-Null
} catch { }
exit 0
