# Sets the per-user join keys that managed settings can't (they're global).
# Push via Intune as a user-context script. Values must be W3C baggage-safe:
# no spaces, comma-separated key=value.
param(
  [Parameter(Mandatory)] [string] $Team,     # e.g. pricing-platform
  [Parameter(Mandatory)] [string] $Bu        # e.g. hiscox-re
)
$upn = (whoami /upn).Trim().ToLower()
$attrs = "enduser.id=$upn,team=$Team,bu=$Bu,client=claude-code"
[Environment]::SetEnvironmentVariable("OTEL_RESOURCE_ATTRIBUTES", $attrs, "User")
Write-Output "OTEL_RESOURCE_ATTRIBUTES=$attrs"
