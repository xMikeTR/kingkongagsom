#!/usr/bin/env bash
# macOS/Linux/WSL equivalent. Usage: ./set-identity.sh <team> <bu> <email>
set -euo pipefail
TEAM="$1"; BU="$2"; EMAIL="$(echo "$3" | tr '[:upper:]' '[:lower:]')"
LINE="export OTEL_RESOURCE_ATTRIBUTES=\"enduser.id=${EMAIL},team=${TEAM},bu=${BU},client=claude-code\""
for rc in ~/.zshrc ~/.bashrc; do
  [ -f "$rc" ] || continue
  grep -v '^export OTEL_RESOURCE_ATTRIBUTES=' "$rc" > "$rc.tmp" && mv "$rc.tmp" "$rc"
  echo "$LINE" >> "$rc"
done
echo "$LINE"
