#!/usr/bin/env python3
"""
value_view.py — spend next to what it bought, for devs and leadership.

Rebuilt (Nov 2026) from the September value view + leadership rollup, now
reading the canonical events (exported from New Relic) instead of the old
tier-1 CSVs. One script, one long-format output; Power BI pages filter on
audience and org level, so nobody runs a second collection.

Inputs (CSV, in --indir; see newrelic/value-view-exports.nrql):
  sessions.csv      session_id, harness, user_id, started_at, work_item_alias
  usage.csv         usage_date, harness, model, billing_source, user_id, session_id,
                    input_tokens, output_tokens, cost_usd, ai_credits_used
  work_items.csv    work_item_id, alias, task_class, task_size, team, work_stream,
                    status, created_at, done_at        (written by the Jira adapter)
  outcomes.csv      work_item_id, outcome, attempt_n, bounced_back, reverted_30d
  aliases.csv       work_item_id, alias               (the alias table)
  model-prices.csv  optional  model, input_usd_per_mtok, output_usd_per_mtok
  org_units.csv     optional  squad, team, bu, jira_team          (no people)
  org_members.csv   optional  RESTRICTED. user_hash, squad, valid_from, valid_to
  seats.csv         optional  user_id, harness                    (licensed seats)
  bench_runs.csv    optional  model, task_class, outcome, cost_usd (replay benchmark)

Output (--outdir):
  value_view.csv        period, org_level, org_unit, metric, cohort, segment_key,
                        segment_value, value, unit, n, ci_low, ci_high, suppressed, method_note
  metric_catalogue.csv  metric, audience, unit, how_to_read

Rules enforced in code, not left to the reporting layer:
  1. Individuals never reach the output. User IDs are HMAC-hashed on read with
     $VALUE_VIEW_SALT and the raw value is dropped; the schema has no user field.
     If org_members.csv is present and the salt is not, the script refuses to run.
  2. Cells with n < MIN_CELL_SIZE are emitted suppressed, never aggregated past.
  3. Any unit-period with fewer than MIN_DISTINCT_USERS distinct AI users has
     every AI-derived row suppressed, however many sessions it has.
  4. Complementary suppression: when a parent unit has exactly one hidden child,
     the smallest visible sibling is hidden too (no subtraction attacks).
  5. Squads come from the work item first (Jira team field), and only fall back
     to the squad of the people whose sessions served it.
  6. Only work_stream == team_delivery counts toward delivery metrics; platform
     and R&D spend is reported on its own line as capability investment.
  7. Agent vs non-agent comparisons are always segmented by task class;
     unsegmented headline comparisons are not emitted (selection bias).
  8. Unattributed spend is never called waste. It is reported on its own line.
  9. Cycle time is never converted to money.
 10. Raw pass rate by model is only compared within a task class (model choice
     correlates with difficulty); the replay benchmark is the authoritative view.

Self-test (synthetic data, asserts the privacy properties):
  python valueview/value_view.py --selftest
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import hmac
import math
import os
import random
import secrets
import sys
import tempfile
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta
from statistics import median

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from obs.aliases import AliasTable  # noqa: E402
from obs.ids import WI_UNASSIGNED  # noqa: E402

MIN_CELL_SIZE = 5
MIN_DISTINCT_USERS = 3
CURRENCY = "USD"
OUT_FIELDS = ["period", "org_level", "org_unit", "metric", "cohort", "segment_key", "segment_value",
              "value", "unit", "n", "ci_low", "ci_high", "suppressed", "method_note"]
LEVELS = ["squad", "team", "bu", "all"]
PARENT = {"squad": "team", "team": "bu", "bu": "all"}

CATALOGUE = [
    # metric, audience, unit, how to read
    ("cost_per_delivered_work_item", "leadership", CURRENCY, "Headline. AI spend on work items that reached Done and survived 30 days, per item. Read the trend, not the level."),
    ("first_pass_qa_rate", "leadership", "ratio", "Share of done items that passed the QA gate first time. Agent vs non-agent only within a task class."),
    ("change_failure_rate", "leadership", "ratio", "Quality differential: share of done items reverted within 30 days, by cohort and task class."),
    ("adoption_share", "leadership", "ratio", "Share of done items with any AI session. The multiplier on everything else."),
    ("capacity_redeployed", "leadership", "hours", "Not derivable from telemetry. Needs a named statement of what freed capacity moved to."),
    ("governed_path_coverage", "leadership", "ratio", "Not yet computed: no governance field in the events."),
    ("spend_total", "platform", CURRENCY, "All AI spend in the period, every harness and billing source."),
    ("spend_by_harness", "platform", CURRENCY, "Spend split by Claude Code, Copilot, own agents, APIM."),
    ("spend_by_billing_source", "platform", CURRENCY, "Which bill each dollar reconciles against (APIM, GitHub, ...)."),
    ("spend_by_model", "platform", CURRENCY, "Spend split by model."),
    ("spend_by_work_stream", "leadership", CURRENCY, "Team delivery vs capability investment (platform, R&D)."),
    ("spend_by_outcome", "eng", CURRENCY, "Attributed spend split into qualified, failed, no merged change, in progress; unattributed on its own line."),
    ("waste_share", "eng", "ratio", "Failed + no-merged-change spend over closed attributed spend. Only as trustworthy as attribution_rate."),
    ("attribution_rate", "platform", "ratio", "Sessions resolved to a work item. Below ~80% the value numbers are shaky."),
    ("attributed_spend_share", "platform", "ratio", "Share of spend that reached a work item."),
    ("session_success_rate", "dev", "ratio", "Attributed sessions whose work item passed the QA gate first time without bounce-back."),
    ("qa_bounce_back_rate", "eng", "ratio", "Share of done items bounced back from QA."),
    ("cycle_time_days", "eng", "days", "Median created -> done, by cohort within task class. Never converted to money."),
    ("pass_rate_by_model", "platform", "ratio", "Observed first-pass rate by dominant model, within task class. 95% Wilson CI; overlapping CIs = equivalent."),
    ("cost_per_passed_task", "leadership", CURRENCY, "Cost per passed task by model x task class. Bench cohort is authoritative."),
    ("coverage", "platform", "ratio", "Licensed users who emitted telemetry. Spend is understated by the gap."),
    ("org_attribution_source", "platform", "ratio", "How work items got their squad: Jira team field vs session users."),
    ("unpriced_usage_rows", "platform", "count", "Usage rows with no cost and no price to compute one. Should be 0."),
]
AI_DERIVED = {m for m, *_ in CATALOGUE} - {"capacity_redeployed", "governed_path_coverage"}
WORK_ONLY_COHORTS = {"all", "non_agent"}  # cohorts of work-only metrics that are not AI-derived


# --------------------------------------------------------------------------- helpers

def read_csv(path, required=True):
    if not os.path.exists(path):
        if required:
            raise SystemExit(f"missing input {path}")
        return None
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def fnum(v, default=0.0):
    try:
        return float(v) if v not in (None, "") else default
    except ValueError:
        return default


def truthy(v):
    return str(v).strip().lower() in ("1", "true", "yes", "y")


def parse_day(v):
    if not v:
        return None
    return datetime.fromisoformat(str(v).replace("Z", "+00:00")[:19]).date() if "T" in str(v) else date.fromisoformat(str(v)[:10])


def period_of(d: date, grain: str) -> str:
    return f"{d.year}-Q{(d.month - 1) // 3 + 1}" if grain == "quarter" else f"{d.year}-{d.month:02d}"


def wilson(k, n, z=1.96):
    if n == 0:
        return None, None
    p = k / n
    den = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / den
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return max(0.0, centre - half), min(1.0, centre + half)


class Hasher:
    def __init__(self, salt: str | None, require: bool):
        if not salt and require:
            raise SystemExit("org_members.csv is present but $VALUE_VIEW_SALT is not set: refusing to run "
                             "rather than fall back to raw IDs.")
        self.key = (salt or secrets.token_hex(32)).encode()
        self.linkable = bool(salt)

    def __call__(self, uid: str | None) -> str | None:
        if not uid:
            return None
        return hmac.new(self.key, uid.strip().lower().encode(), hashlib.sha256).hexdigest()[:20]


def hash_members(raw_path, out_path, salt):
    """Convert an HR/Entra export (user_id, squad, valid_from, valid_to) to hashed form."""
    h = Hasher(salt, require=True)
    rows = read_csv(raw_path)
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["user_hash", "squad", "valid_from", "valid_to"])
        w.writeheader()
        for r in rows:
            w.writerow({"user_hash": h(r["user_id"]), "squad": r["squad"],
                        "valid_from": r.get("valid_from", ""), "valid_to": r.get("valid_to", "")})
    print(f"hashed {len(rows)} members -> {out_path}")


# --------------------------------------------------------------------------- org model

class Org:
    def __init__(self, units, members):
        self.enabled = bool(units)
        self.squad_team, self.team_bu, self.jira_to_squad = {}, {}, {}
        for u in units or []:
            self.squad_team[u["squad"]] = u["team"]
            self.team_bu[u["team"]] = u["bu"]
            if u.get("jira_team"):
                self.jira_to_squad[u["jira_team"].strip().lower()] = u["squad"]
        self.members = defaultdict(list)
        for m in members or []:
            self.members[m["user_hash"]].append(
                (parse_day(m.get("valid_from")) or date.min, parse_day(m.get("valid_to")) or date.max, m["squad"]))

    def squad_of_user(self, user_hash, on: date | None):
        if not user_hash or on is None:
            return None
        for start, end, squad in self.members.get(user_hash, []):
            if start <= on <= end:
                return squad
        return None

    def chain(self, squad):
        """squad -> {level: unit} for every level, or just 'all'."""
        out = {"all": "all"}
        if squad and squad in self.squad_team:
            team = self.squad_team[squad]
            out.update(squad=squad, team=team, bu=self.team_bu.get(team, "unknown"))
        return out

    def parent(self, level, unit):
        if level == "squad":
            return "team", self.squad_team.get(unit)
        if level == "team":
            return "bu", self.team_bu.get(unit)
        if level == "bu":
            return "all", "all"
        return None, None


# --------------------------------------------------------------------------- load + attribute

def load(indir, grain, salt):
    p = lambda name: os.path.join(indir, name)  # noqa: E731
    members = read_csv(p("org_members.csv"), required=False)
    hasher = Hasher(salt, require=members is not None)
    org = Org(read_csv(p("org_units.csv"), required=False), members)
    aliases = AliasTable(p("aliases.csv"))

    work = {r["work_item_id"]: r for r in read_csv(p("work_items.csv"))}
    for r in read_csv(p("outcomes.csv")):
        if r["work_item_id"] in work:
            work[r["work_item_id"]].update(outcome=r.get("outcome", ""), attempt_n=r.get("attempt_n", ""),
                                           bounced_back=truthy(r.get("bounced_back")),
                                           reverted_30d=truthy(r.get("reverted_30d")))

    prices = {r["model"]: (fnum(r["input_usd_per_mtok"]), fnum(r["output_usd_per_mtok"]))
              for r in read_csv(p("model-prices.csv"), required=False) or []}

    sessions = {}
    for r in read_csv(p("sessions.csv")):
        d = parse_day(r.get("started_at"))
        sessions[r["session_id"]] = {
            "session_id": r["session_id"], "harness": r.get("harness") or "unknown", "user": hasher(r.get("user_id")),
            "day": d, "wi": aliases.resolve(r.get("work_item_alias")),
        }

    usage = []
    for r in read_csv(p("usage.csv")):
        s = sessions.get(r.get("session_id") or "")
        cost, priced = fnum(r.get("cost_usd"), None), True
        if cost is None:
            pin, pout = prices.get(r.get("model", ""), (None, None))
            if pin is not None:
                cost = (fnum(r.get("input_tokens")) * pin + fnum(r.get("output_tokens")) * pout) / 1e6
            else:
                cost, priced = 0.0, False
        usage.append({
            "day": parse_day(r.get("usage_date")) or (s["day"] if s else None),
            "harness": r.get("harness") or (s["harness"] if s else "unknown"),
            "model": r.get("model") or "unknown", "billing_source": r.get("billing_source") or "unknown",
            "user": hasher(r.get("user_id")) or (s["user"] if s else None),
            "wi": s["wi"] if s else WI_UNASSIGNED, "cost": cost, "priced": priced,
            "tokens": fnum(r.get("input_tokens")) + fnum(r.get("output_tokens")),
        })

    seats = [{"user": hasher(r["user_id"]), "harness": r.get("harness", "")}
             for r in read_csv(p("seats.csv"), required=False) or []]
    bench = read_csv(p("bench_runs.csv"), required=False) or []

    # ---- squad per work item: issue first, session users as fallback
    sessions_by_wi = defaultdict(list)
    for s in sessions.values():
        if s["wi"] != WI_UNASSIGNED:
            sessions_by_wi[s["wi"]].append(s)
    attr_source = Counter()
    for wi, w in work.items():
        squad = org.jira_to_squad.get((w.get("team") or "").strip().lower()) if org.enabled else None
        source = "jira_team" if squad else None
        if not squad and org.enabled:
            votes = Counter(org.squad_of_user(s["user"], s["day"]) for s in sessions_by_wi.get(wi, []))
            votes.pop(None, None)
            if votes:
                squad, source = votes.most_common(1)[0][0], "session_users"
        w["squad"], w["attr_source"] = squad, source or "none"
        attr_source[w["attr_source"]] += 1
        w["agent"] = bool(sessions_by_wi.get(wi))
        w["done_day"] = parse_day(w.get("done_at"))
        w["created_day"] = parse_day(w.get("created_at"))

    # ---- dominant model per work item (by tokens)
    tok = defaultdict(Counter)
    spend_wi = defaultdict(float)
    for u in usage:
        if u["wi"] != WI_UNASSIGNED:
            tok[u["wi"]][u["model"]] += u["tokens"]
            spend_wi[u["wi"]] += u["cost"]
    for wi, w in work.items():
        w["model"] = tok[wi].most_common(1)[0][0] if tok.get(wi) else None
        w["spend"] = spend_wi.get(wi, 0.0)

    # ---- squad for sessions and usage: the work item's squad, else the user's squad that day
    def squad_for(wi, user, day):
        if wi != WI_UNASSIGNED and wi in work and work[wi]["squad"]:
            return work[wi]["squad"]
        return org.squad_of_user(user, day) if org.enabled else None
    for s in sessions.values():
        s["squad"] = squad_for(s["wi"], s["user"], s["day"])
    for u in usage:
        u["squad"] = squad_for(u["wi"], u["user"], u["day"])
    for s in seats:
        s["squad"] = org.squad_of_user(s["user"], date.today()) if org.enabled else None

    return dict(org=org, work=work, sessions=list(sessions.values()), usage=usage, seats=seats,
                bench=bench, attr_source=attr_source, grain=grain, hasher=hasher)


# --------------------------------------------------------------------------- metrics

def outcome_bucket(w):
    if not w.get("done_day"):
        return "in_progress"
    if w.get("outcome") == "fail" or w.get("reverted_30d"):
        return "failed"
    if w.get("outcome") == "abandoned":
        return "no_merged_change"
    if w.get("outcome") in ("pass", "reworked"):
        return "qualified"
    return "no_outcome_recorded"


def compute(sessions, usage, work_items, seats, bench, is_global, attr_source):
    rows = []

    def add(metric, value, unit, n, cohort="all", seg_key="", seg_val="", note="", ci=(None, None)):
        rows.append(dict(metric=metric, value=value, unit=unit, n=n, cohort=cohort, segment_key=seg_key,
                         segment_value=seg_val, ci_low=ci[0], ci_high=ci[1], method_note=note))

    # spend
    total = sum(u["cost"] for u in usage)
    add("spend_total", total, CURRENCY, len(usage))
    for key, metric in (("harness", "spend_by_harness"), ("billing_source", "spend_by_billing_source"),
                        ("model", "spend_by_model")):
        groups = defaultdict(list)
        for u in usage:
            groups[u[key]].append(u)
        for k, us in sorted(groups.items()):
            add(metric, sum(x["cost"] for x in us), CURRENCY, len(us), seg_key=key, seg_val=k)
    unpriced = sum(1 for u in usage if not u["priced"])
    add("unpriced_usage_rows", unpriced, "count", len(usage), note="no cost_usd and no model price")

    by_wi = {w["work_item_id"]: w for w in work_items}
    ws_spend = defaultdict(lambda: [0.0, 0])
    for u in usage:
        w = by_wi.get(u["wi"])
        ws = (w.get("work_stream") or "team_delivery") if w else "unattributed"
        ws_spend[ws][0] += u["cost"]
        ws_spend[ws][1] += 1
    for ws, (v, n) in sorted(ws_spend.items()):
        add("spend_by_work_stream", v, CURRENCY, n, seg_key="work_stream", seg_val=ws)

    # attribution
    attributed = [s for s in sessions if s["wi"] != WI_UNASSIGNED]
    if sessions:
        add("attribution_rate", len(attributed) / len(sessions), "ratio", len(sessions))
    if total:
        att_spend = sum(u["cost"] for u in usage if u["wi"] != WI_UNASSIGNED)
        add("attributed_spend_share", att_spend / total, "ratio", len(usage))

    # outcome split (team delivery only); unattributed on its own line, never waste
    delivery = [w for w in work_items if (w.get("work_stream") or "team_delivery") == "team_delivery"]
    buckets = defaultdict(lambda: [0.0, 0])
    for w in delivery:
        if w["spend"]:
            b = outcome_bucket(w)
            buckets[b][0] += w["spend"]
            buckets[b][1] += 1
    unatt = [u for u in usage if u["wi"] == WI_UNASSIGNED]
    buckets["unattributed"] = [sum(u["cost"] for u in unatt), len(unatt)]
    for b, (v, n) in sorted(buckets.items()):
        add("spend_by_outcome", v, CURRENCY, n, seg_key="outcome", seg_val=b,
            note="unattributed is not waste; it is unknown" if b == "unattributed" else "")
    closed = sum(buckets[b][0] for b in ("qualified", "failed", "no_merged_change"))
    closed_n = sum(buckets[b][1] for b in ("qualified", "failed", "no_merged_change"))
    if closed:
        add("waste_share", (buckets["failed"][0] + buckets["no_merged_change"][0]) / closed, "ratio", closed_n,
            note="excludes unattributed spend; read next to attribution_rate")

    # delivery metrics
    done = [w for w in delivery if w.get("done_day")]
    qualified = [w for w in done if outcome_bucket(w) == "qualified" and w["agent"]]
    classes = sorted({w.get("task_class") or "other" for w in done})

    def cpdwi(items, seg_val):
        if items:
            add("cost_per_delivered_work_item", sum(w["spend"] for w in items) / len(items), CURRENCY,
                len(items), cohort="agent", seg_key="task_class" if seg_val else "", seg_val=seg_val or "")
    cpdwi(qualified, None)
    for c in classes:
        cpdwi([w for w in qualified if (w.get("task_class") or "other") == c], c)

    def rate(metric, items, pred, cohort, seg_val):
        if items:
            k = sum(1 for w in items if pred(w))
            add(metric, k / len(items), "ratio", len(items), cohort=cohort,
                seg_key="task_class" if seg_val else "", seg_val=seg_val or "", ci=wilson(k, len(items)))

    with_outcome = [w for w in done if w.get("outcome")]
    first_pass = lambda w: w.get("outcome") == "pass"  # noqa: E731
    rate("first_pass_qa_rate", with_outcome, first_pass, "all", None)
    rate("qa_bounce_back_rate", with_outcome, lambda w: w.get("bounced_back"), "all", None)
    rate("adoption_share", done, lambda w: w["agent"], "all", None)
    for c in classes:
        in_c = [w for w in with_outcome if (w.get("task_class") or "other") == c]
        for cohort, flag in (("agent", True), ("non_agent", False)):
            coh = [w for w in in_c if w["agent"] == flag]
            rate("first_pass_qa_rate", coh, first_pass, cohort, c)
            rate("change_failure_rate", coh, lambda w: w.get("reverted_30d"), cohort, c)
            ct = [(w["done_day"] - w["created_day"]).days for w in coh if w.get("created_day")]
            if ct:
                add("cycle_time_days", median(ct), "days", len(ct), cohort=cohort, seg_key="task_class", seg_val=c,
                    note="wall-clock; includes queue time; never converted to money")

    # session success
    ok_sessions = [s for s in attributed if by_wi.get(s["wi"], {}).get("outcome")]
    if ok_sessions:
        k = sum(1 for s in ok_sessions if by_wi[s["wi"]].get("outcome") == "pass" and not by_wi[s["wi"]].get("bounced_back"))
        add("session_success_rate", k / len(ok_sessions), "ratio", len(ok_sessions), cohort="agent",
            ci=wilson(k, len(ok_sessions)))

    # model effectiveness: only within task class
    for c in classes:
        in_c = [w for w in with_outcome if (w.get("task_class") or "other") == c and w.get("model")]
        for m in sorted({w["model"] for w in in_c}):
            ws = [w for w in in_c if w["model"] == m]
            k = sum(1 for w in ws if first_pass(w))
            add("pass_rate_by_model", k / len(ws), "ratio", len(ws), cohort="production", seg_key=f"model|task_class",
                seg_val=f"{m}|{c}", ci=wilson(k, len(ws)), note="observational; confounded by routing, see bench")
            if k:
                add("cost_per_passed_task", sum(w["spend"] for w in ws) / k, CURRENCY, k, cohort="production",
                    seg_key="model|task_class", seg_val=f"{m}|{c}")
    if is_global and bench:
        groups = defaultdict(list)
        for b in bench:
            groups[(b["model"], b.get("task_class") or "other")].append(b)
        for (m, c), bs in sorted(groups.items()):
            k = sum(1 for b in bs if b["outcome"] == "pass")
            add("pass_rate_by_model", k / len(bs), "ratio", len(bs), cohort="bench", seg_key="model|task_class",
                seg_val=f"{m}|{c}", ci=wilson(k, len(bs)), note="replay benchmark; authoritative")
            if k:
                add("cost_per_passed_task", sum(fnum(b.get("cost_usd")) for b in bs) / k, CURRENCY, k,
                    cohort="bench", seg_key="model|task_class", seg_val=f"{m}|{c}")

    # coverage
    if seats:
        emitting = {u["user"] for u in usage if u["user"]} | {s["user"] for s in sessions if s["user"]}
        licensed = {s["user"] for s in seats if s["user"]}
        if licensed:
            add("coverage", len(licensed & emitting) / len(licensed), "ratio", len(licensed))

    # placeholders: say so rather than vanish
    add("capacity_redeployed", None, "hours", 0,
        note="not derivable from telemetry; needs effort data plus a named statement of where capacity went")
    add("governed_path_coverage", None, "ratio", 0, note="no governance field in events yet")

    if is_global:
        tot = sum(attr_source.values())
        for src, n in sorted(attr_source.items()):
            add("org_attribution_source", n / tot, "ratio", tot, seg_key="source", seg_val=src)
    return rows


# --------------------------------------------------------------------------- run + suppression

def run(indir, outdir, grain="quarter", salt=None):
    d = load(indir, grain, salt)
    org = d["org"]

    def per(items, day_key):
        out = defaultdict(list)
        for x in items:
            if x.get(day_key):
                out[period_of(x[day_key], grain)].append(x)
        return out

    s_by_p, u_by_p = per(d["sessions"], "day"), per(d["usage"], "day")
    w_by_p = per(list(d["work"].values()), "done_day")
    # in-progress items still carry spend: bucket them by created day
    for w in d["work"].values():
        if not w.get("done_day") and w.get("created_day"):
            w_by_p[period_of(w["created_day"], grain)].append(w)
    periods = sorted(set(s_by_p) | set(u_by_p) | set(w_by_p))

    out = []
    unit_users = {}  # (period, level, unit) -> distinct AI users
    for period in periods:
        units = defaultdict(lambda: {"s": [], "u": [], "w": []})
        for key, coll in (("s", s_by_p[period]), ("u", u_by_p[period]), ("w", w_by_p[period])):
            for x in coll:
                for level, unit in org.chain(x.get("squad")).items():
                    units[(level, unit)][key].append(x)
        for (level, unit), g in sorted(units.items(), key=lambda kv: LEVELS.index(kv[0][0])):
            users = {x["user"] for x in g["s"] + g["u"] if x.get("user")}
            unit_users[(period, level, unit)] = len(users)
            for r in compute(g["s"], g["u"], g["w"], d["seats"] if level == "all" else
                             [s for s in d["seats"] if org.chain(s["squad"]).get(level) == unit],
                             d["bench"], level == "all", d["attr_source"]):
                r.update(period=period, org_level=level, org_unit=unit, suppressed=False)
                out.append(r)

    # rule 2: cell size
    for r in out:
        if r["value"] is not None and r["n"] < MIN_CELL_SIZE:
            r.update(value=None, ci_low=None, ci_high=None, suppressed=True,
                     method_note=f"n<{MIN_CELL_SIZE}; " + r["method_note"])

    def ai_row(r):
        return r["metric"] in AI_DERIVED and not (r["metric"] in ("first_pass_qa_rate", "change_failure_rate",
                                                                   "cycle_time_days", "qa_bounce_back_rate")
                                                  and r["cohort"] in WORK_ONLY_COHORTS)

    # rule 3: distinct users per unit-period
    hidden = {k for k, n in unit_users.items() if n < MIN_DISTINCT_USERS and k[1] != "all"}
    # rule 4: complementary suppression, bottom-up
    for level in ("squad", "team", "bu"):
        siblings = defaultdict(list)
        for (period, lvl, unit), n in unit_users.items():
            if lvl == level:
                siblings[(period, org.parent(level, unit))].append(((period, lvl, unit), n))
        for _, kids in siblings.items():
            hid = [k for k, _ in kids if k in hidden]
            vis = sorted([(n, k) for k, n in kids if k not in hidden])
            if len(hid) == 1 and vis:
                hidden.add(vis[0][1])
    for r in out:
        if (r["period"], r["org_level"], r["org_unit"]) in hidden and ai_row(r) and r["value"] is not None:
            r.update(value=None, ci_low=None, ci_high=None, suppressed=True,
                     method_note=f"unit has <{MIN_DISTINCT_USERS} AI users or protects a sibling; " + r["method_note"])

    os.makedirs(outdir, exist_ok=True)
    with open(os.path.join(outdir, "value_view.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=OUT_FIELDS)
        w.writeheader()
        for r in out:
            w.writerow({k: ("" if r.get(k) is None else (round(r[k], 6) if isinstance(r[k], float) else r[k]))
                        for k in OUT_FIELDS})
    with open(os.path.join(outdir, "metric_catalogue.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["metric", "audience", "unit", "how_to_read"])
        w.writerows(CATALOGUE)
    return out, d


# --------------------------------------------------------------------------- self-test

def _write(path, fields, rows):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def selftest():
    rnd = random.Random(7)
    tmp = tempfile.mkdtemp(prefix="value_view_")
    indir, outdir = os.path.join(tmp, "in"), os.path.join(tmp, "out")
    os.makedirs(indir)
    salt = "selftest-salt"
    os.environ["VALUE_VIEW_SALT"] = salt

    units = [("sq-a", "pricing", "hiscox-re", "Pricing A"), ("sq-b", "pricing", "hiscox-re", "Pricing B"),
             ("sq-e", "claims", "hiscox-re", "Claims E"), ("sq-f", "claims", "hiscox-re", "Claims F"),
             ("sq-z", "core", "other-bu", "Core Z"), ("sq-y", "core", "other-bu", "Core Y")]
    _write(os.path.join(indir, "org_units.csv"), ["squad", "team", "bu", "jira_team"],
           [dict(zip(["squad", "team", "bu", "jira_team"], u)) for u in units])
    sizes = {"sq-a": 6, "sq-b": 5, "sq-e": 5, "sq-f": 2, "sq-z": 4, "sq-y": 4}
    people = {sq: [f"{sq}-dev{i}@example.com" for i in range(n)] for sq, n in sizes.items()}
    mover, move_day = "mover@example.com", date(2026, 8, 15)
    raw_members = [{"user_id": u, "squad": sq, "valid_from": "2026-01-01", "valid_to": ""}
                   for sq, us in people.items() for u in us]
    raw_members += [{"user_id": mover, "squad": "sq-a", "valid_from": "2026-01-01", "valid_to": "2026-08-14"},
                    {"user_id": mover, "squad": "sq-b", "valid_from": "2026-08-15", "valid_to": ""}]
    _write(os.path.join(tmp, "members_raw.csv"), ["user_id", "squad", "valid_from", "valid_to"], raw_members)
    hash_members(os.path.join(tmp, "members_raw.csv"), os.path.join(indir, "org_members.csv"), salt)

    aliases = AliasTable(os.path.join(indir, "aliases.csv"))
    work, outcomes, sessions, usage = [], [], [], []
    models = ["claude-sonnet", "claude-opus", "gemini-pro"]
    start = date(2026, 7, 1)
    sid = 0
    for i in range(240):
        sq = rnd.choice(list(sizes))
        key = f"RE-{1000 + i}"
        wi = aliases.ensure(f"jira:{key}")
        created = start + timedelta(days=rnd.randint(0, 150))
        done = created + timedelta(days=rnd.randint(2, 20)) if rnd.random() < 0.8 else None
        team_field = "" if rnd.random() < 0.15 else dict((u[0], u[3]) for u in units)[sq]
        work.append({"work_item_id": wi, "alias": f"jira:{key}", "task_class": rnd.choice(["bug", "feature"]),
                     "task_size": rnd.choice([1, 2, 3, 5]), "team": team_field,
                     "work_stream": "platform" if rnd.random() < 0.08 else "team_delivery",
                     "status": "Done" if done else "In Progress", "created_at": created.isoformat(),
                     "done_at": done.isoformat() if done else ""})
        if done:
            outcomes.append({"work_item_id": wi, "outcome": rnd.choices(["pass", "reworked", "fail", "abandoned"],
                                                                         [6, 2, 1, 1])[0],
                             "attempt_n": 1, "bounced_back": int(rnd.random() < 0.15),
                             "reverted_30d": int(rnd.random() < 0.05)})
        if rnd.random() < 0.7:  # agent involvement
            for _ in range(rnd.randint(1, 4)):
                sid += 1
                user = rnd.choice(people[sq])
                day = created + timedelta(days=rnd.randint(0, 3))
                sessions.append({"session_id": f"s{sid}", "harness": "claude-code", "user_id": user,
                                 "started_at": f"{day.isoformat()}T10:00:00Z",
                                 "work_item_alias": f"git:{key}-some-change"})
                m = rnd.choice(models)
                for _ in range(rnd.randint(1, 3)):
                    usage.append({"usage_date": day.isoformat(), "harness": "claude-code", "model": m,
                                  "billing_source": "apim", "user_id": user, "session_id": f"s{sid}",
                                  "input_tokens": rnd.randint(1000, 90000), "output_tokens": rnd.randint(100, 9000),
                                  "cost_usd": round(rnd.uniform(0.05, 4.0), 4), "ai_credits_used": ""})
    # unattributed sessions (no ticket in branch), including the mover before and after the move
    for day, who in [(date(2026, 8, 1), mover)] * 6 + [(date(2026, 9, 1), mover)] * 6 + \
            [(start + timedelta(days=rnd.randint(0, 150)), rnd.choice(people["sq-z"])) for _ in range(30)]:
        sid += 1
        sessions.append({"session_id": f"s{sid}", "harness": "claude-code", "user_id": who,
                         "started_at": f"{day.isoformat()}T09:00:00Z", "work_item_alias": "git:main"})
        usage.append({"usage_date": day.isoformat(), "harness": "claude-code", "model": "claude-sonnet",
                      "billing_source": "apim", "user_id": who, "session_id": f"s{sid}", "input_tokens": 5000,
                      "output_tokens": 500, "cost_usd": 1.0, "ai_credits_used": ""})
    # Copilot usage: no session, billed by GitHub, priced from the price table
    for sq, us in people.items():
        for u in us:
            usage.append({"usage_date": "2026-09-10", "harness": "copilot", "model": "copilot-mixed",
                          "billing_source": "github", "user_id": u, "session_id": "", "input_tokens": 20000,
                          "output_tokens": 2000, "cost_usd": "", "ai_credits_used": 12})
    aliases.save()
    _write(os.path.join(indir, "work_items.csv"), list(work[0]), work)
    _write(os.path.join(indir, "outcomes.csv"), list(outcomes[0]), outcomes)
    _write(os.path.join(indir, "sessions.csv"), list(sessions[0]), sessions)
    _write(os.path.join(indir, "usage.csv"), list(usage[0]), usage)
    _write(os.path.join(indir, "model-prices.csv"), ["model", "input_usd_per_mtok", "output_usd_per_mtok"],
           [{"model": "copilot-mixed", "input_usd_per_mtok": 1.0, "output_usd_per_mtok": 4.0}])
    _write(os.path.join(indir, "seats.csv"), ["user_id", "harness"],
           [{"user_id": u, "harness": "claude-code"} for us in people.values() for u in us] +
           [{"user_id": "never-used@example.com", "harness": "claude-code"}])
    _write(os.path.join(indir, "bench_runs.csv"), ["model", "task_class", "outcome", "cost_usd"],
           [{"model": m, "task_class": "bug", "outcome": rnd.choice(["pass", "pass", "fail"]),
             "cost_usd": rnd.uniform(0.5, 3)} for m in models for _ in range(30)])

    out, d = run(indir, outdir, "quarter", salt)
    text = open(os.path.join(outdir, "value_view.csv"), encoding="utf-8").read()
    rows = list(csv.DictReader(open(os.path.join(outdir, "value_view.csv"), encoding="utf-8")))
    checks = []

    # 1. no raw identities anywhere in the output
    assert "@example.com" not in text and "dev0" not in text
    checks.append("no raw user IDs in output")

    # 2. a two-person squad never shows an AI-derived value
    leaked = [r for r in rows if r["org_unit"] == "sq-f" and r["metric"] in AI_DERIVED and r["value"] != ""
              and not (r["metric"] in ("first_pass_qa_rate", "change_failure_rate", "cycle_time_days",
                                       "qa_bounce_back_rate") and r["cohort"] in WORK_ONLY_COHORTS)]
    assert not leaked, leaked[:2]
    checks.append("two-person squad never shows an AI-derived value")

    # 3. complementary suppression: wherever sq-f is hidden, its only sibling sq-e is hidden too
    def shown(unit, period, metric="spend_total"):
        return any(r["org_unit"] == unit and r["period"] == period and r["metric"] == metric and r["value"] != ""
                   for r in rows)
    for period in {r["period"] for r in rows}:
        if not shown("sq-f", period) and any(r["org_unit"] == "sq-f" and r["period"] == period for r in rows):
            assert not shown("sq-e", period), f"subtraction leak in {period}"
    checks.append("no subtraction leak between sibling squads")

    # 4. the mover's history stays with the old squad
    h = d["hasher"](mover)
    assert d["org"].squad_of_user(h, date(2026, 8, 1)) == "sq-a"
    assert d["org"].squad_of_user(h, date(2026, 9, 1)) == "sq-b"
    mover_usage = [u for u in d["usage"] if u["user"] == h and u["wi"] == WI_UNASSIGNED]
    assert {u["squad"] for u in mover_usage if u["day"] < move_day} == {"sq-a"}
    assert {u["squad"] for u in mover_usage if u["day"] >= move_day} == {"sq-b"}
    checks.append("a squad move does not rewrite history")

    # 5. BU spend reconciles to global wherever every BU is visible
    reconciled = 0
    for period in sorted({r["period"] for r in rows}):
        g = [r for r in rows if r["period"] == period and r["org_level"] == "all" and r["metric"] == "spend_total"]
        b = [r for r in rows if r["period"] == period and r["org_level"] == "bu" and r["metric"] == "spend_total"]
        unassigned = sum(u["cost"] for u in d["usage"] if period_of(u["day"], "quarter") == period and not u["squad"])
        if g and b and all(r["value"] != "" for r in b):
            assert abs(sum(float(r["value"]) for r in b) + unassigned - float(g[0]["value"])) < 0.05, period
            reconciled += 1
    assert reconciled
    checks.append(f"BU spend reconciles to global ({reconciled} periods)")

    # 6. unattributed spend has its own line and is never inside waste
    ua = [r for r in rows if r["metric"] == "spend_by_outcome" and r["segment_value"] == "unattributed"
          and r["org_level"] == "all"]
    assert ua and all("not waste" in r["method_note"] for r in ua)
    checks.append("unattributed spend reported separately, not as waste")

    # 7. CIs are well-formed
    for r in rows:
        if r["ci_low"] != "" and r["value"] != "":
            assert 0 <= float(r["ci_low"]) <= float(r["value"]) <= float(r["ci_high"]) <= 1, r
    checks.append("confidence intervals well-formed")

    # 8. no unsegmented agent vs non-agent comparison
    assert not [r for r in rows if r["metric"] in ("first_pass_qa_rate", "change_failure_rate", "cycle_time_days")
                and r["cohort"] in ("agent", "non_agent") and not r["segment_key"]]
    checks.append("agent vs non-agent only within task class")

    # 9. Copilot priced from the table; nothing unpriced; coverage below 1 because of the unused seat
    g_unpriced = [r for r in rows if r["org_level"] == "all" and r["metric"] == "unpriced_usage_rows"]
    assert all(r["value"] in ("0", "") for r in g_unpriced)
    cov = [r for r in rows if r["org_level"] == "all" and r["metric"] == "coverage" and r["value"] != ""]
    assert cov and all(float(r["value"]) < 1 for r in cov)
    checks.append("copilot priced, coverage counts unused seats")

    # 10. refusing to run without a salt when members exist
    del os.environ["VALUE_VIEW_SALT"]
    try:
        run(indir, outdir, "quarter", None)
        raise AssertionError("should have refused to run without a salt")
    except SystemExit:
        checks.append("refuses to run without $VALUE_VIEW_SALT when org members are present")

    print(f"selftest OK ({len(rows)} rows) -> {outdir}")
    for c in checks:
        print("  ok:", c)
    for r in rows:
        if r["org_level"] == "all" and r["metric"] in ("cost_per_delivered_work_item", "attribution_rate",
                                                       "first_pass_qa_rate", "adoption_share") \
                and not r["segment_key"]:
            print(f"  {r['period']} {r['metric']}: {r['value']} (n={r['n']})")


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--indir", default="data")
    ap.add_argument("--outdir", default="out")
    ap.add_argument("--period", choices=["quarter", "month"], default="quarter")
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--hash-members", nargs=2, metavar=("RAW_CSV", "OUT_CSV"),
                    help="hash an HR/Entra export (user_id, squad, valid_from, valid_to)")
    a = ap.parse_args(argv)
    if a.selftest:
        selftest()
        return 0
    salt = os.environ.get("VALUE_VIEW_SALT")
    if a.hash_members:
        hash_members(a.hash_members[0], a.hash_members[1], salt)
        return 0
    out, _ = run(a.indir, a.outdir, a.period, salt)
    print(f"{len(out)} rows -> {os.path.join(a.outdir, 'value_view.csv')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
