# Canonical event contract v0

The contract is the product. Sources and consumers can be swapped; this
cannot change without a version bump. The code version lives in
`obs/events.py` (`CONTRACT`), and `validate()` enforces it.

## Envelope: CloudEvents 1.0

| Field | Value |
|---|---|
| `specversion` | `1.0` |
| `id` | ULID |
| `source` | `/bu-ai-obs/<adapter>` e.g. `/bu-ai-obs/adapters/jira` |
| `type` | `com.hiscox.re.ai.<EventType>.v0` |
| `subject` | **our work-item ID** (`wi_` + ULID), or `wi_unassigned` |
| `time` | ISO 8601 UTC |
| `workitemalias` | extension, optional: raw tracker alias when the emitter can't resolve it (e.g. CI) |
| `data` | event fields below; **never** prompt, completion or message content |

In New Relic each event is flattened into one custom event:
`eventType` = the short type, `work_item.id` = subject, data fields as-is,
plus `org.bu` and `telemetry.pipeline`.

## Work-item IDs and aliases

- We mint the ID: `wi_01JD...` (ULID). Jira keys, Azure DevOps IDs and
  branch names are **aliases**.
- Alias forms: `jira:RE-1234`, `ado:AB#5678`, `git:<branch>` (resolved via the
  ticket key inside the branch name).
- The alias table (`data/aliases.csv`) is maintained by the Jira adapter and
  uploaded to New Relic as the `aliases` lookup table.
- Migration: `AliasTable.link("ado:AB#5678", "jira:RE-1234")` points the new
  key at the existing work item, so history stays joined.
- No ticket in the branch: `wi_unassigned`. Its share is tracked as a metric.

## Event types

| Type | Required | Optional | Emitted by |
|---|---|---|---|
| `WorkItemCreated` | alias | task_class, task_size, team, work_stream, created_at | Jira adapter |
| `WorkItemStatusChanged` | alias, to_status | from_status, status_category, changed_at | Jira adapter / Automation rule |
| `WorkItemDone` | alias, done_at | resolution | Jira adapter |
| `AISessionStarted` | session.id, harness | enduser.id, git.branch, git.repo, work_item.alias, session.source | Claude Code SessionStart hook (as an OTLP log) |
| `AIUsage` | harness, gen_ai.request.model, billing_source | session.id, enduser.id, gen_ai.usage.input_tokens, gen_ai.usage.output_tokens, cost_usd, ai_credits_used, usage_date | Copilot usage adapter; Claude Code via its own OTel metrics |
| `CIRunCompleted` | repo, run_id, conclusion | branch, attempt, duration_s, workflow | GitHub workflow |
| `PRMerged` | repo, pr_number | branch, merged_at | GitHub workflow |
| `QAGatePassed` | attempt_n | repo, branch, mutation_score | QA gate workflow |
| `QABouncedBack` | attempt_n | reason | QA gate workflow / Jira transition |
| `TaskOutcome` | outcome, attempt_n | gen_ai.request.model, task_class, task_size, cost_usd, wallclock_hours | emitted when a work item reaches a terminal state |
| `EvalResult` | suite, case_id, passed | gen_ai.request.model, score, harness_version | eval runner |
| `BenchRun` | bench.version, gen_ai.request.model, outcome | task_class, task_size, attempt_n, cost_usd, turns, tool_calls, tool_errors, wallclock_s, mutation_score, crap_delta | replay benchmark |

Enumerations:

- `outcome`: `pass` (QA gate passed on first run) · `reworked` (failed, then
  passed, or reopened) · `fail` · `abandoned` (closed without merge)
- `harness`: `claude-code`, `copilot`, `copilot-cli`, `copilot-sdk`, `own-agent`, `apim`, `unknown`
- `billing_source`: `apim`, `github`, `anthropic`, `vertex`, `unknown`.
  Each one reconciles against a different bill.
- `task_class`: `bug`, `feature`, `refactor`, `test`, `migration`, `data`, `other`
  (mapped from Jira issue type + labels in the Jira adapter)

## Resource attributes on OTel signals

| Attribute | Example | Set by |
|---|---|---|
| `enduser.id` | `mike@hiscox.com` (lowercase UPN) | identity script / APIM JWT |
| `enduser.oid` | Entra object ID | APIM (quota key) |
| `team`, `bu` | `pricing-platform`, `hiscox-re` | identity script |
| `harness` | `claude-code`, `copilot` | collector (`transform/harness`) |
| `org.bu` | `hiscox-re` | collector |
| `deployment.environment` | `local`, `prod` | collector |
| `telemetry.pipeline` | `agentic-ops` | collector |

Rules: lowercase, no spaces (W3C baggage format), UPN not display name.
Squad and budget live in the `org` lookup table, not on the wire, so reorgs
don't require re-instrumenting anyone.
