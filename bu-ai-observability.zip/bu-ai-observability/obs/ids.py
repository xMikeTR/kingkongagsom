"""Work-item IDs: 'wi_' + ULID (26 chars, Crockford base32, time-sortable).

We mint these ourselves. Jira keys, Azure DevOps IDs and branch names are
only aliases that point at one of them, so moving trackers never re-keys
history.
"""
from __future__ import annotations

import os
import time

_CROCKFORD = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"
WI_PREFIX = "wi_"
WI_UNASSIGNED = "wi_unassigned"


def ulid(ts_ms: int | None = None, rand: bytes | None = None) -> str:
    ts = int(time.time() * 1000) if ts_ms is None else ts_ms
    if not 0 <= ts < 2 ** 48:
        raise ValueError("timestamp out of ULID range")
    r = os.urandom(10) if rand is None else rand
    if len(r) != 10:
        raise ValueError("ULID randomness must be 10 bytes")
    n = (ts << 80) | int.from_bytes(r, "big")
    out = []
    for _ in range(26):
        out.append(_CROCKFORD[n & 31])
        n >>= 5
    return "".join(reversed(out))


def new_work_item_id(ts_ms: int | None = None) -> str:
    return WI_PREFIX + ulid(ts_ms)


def is_work_item_id(value: str | None) -> bool:
    if not value or not value.startswith(WI_PREFIX):
        return False
    body = value[len(WI_PREFIX):]
    return body == "unassigned" or (len(body) == 26 and all(c in _CROCKFORD for c in body))
