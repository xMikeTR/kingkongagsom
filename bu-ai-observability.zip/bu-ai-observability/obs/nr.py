"""Send canonical events to New Relic's Event API (the PoV's event stream).

Uses the ingest licence key (same key the collector uses). EU accounts use
the eu01 endpoint. With --dry-run / NR_DRY_RUN=1 nothing is sent; events are
appended to an NDJSON file instead, which is also handy for backfills.
"""
from __future__ import annotations

import gzip
import json
import os
import urllib.request
from typing import Any, Iterable

from .events import to_newrelic

ENDPOINTS = {
    "eu": "https://insights-collector.eu01.nr-data.net/v1/accounts/{account}/events",
    "us": "https://insights-collector.newrelic.com/v1/accounts/{account}/events",
}
MAX_EVENTS_PER_POST = 1000
MAX_BYTES_PER_POST = 900_000  # API limit is 1 MB compressed; stay under it uncompressed


class NewRelicSender:
    def __init__(self, account_id: str | None = None, key: str | None = None,
                 region: str | None = None, dry_run_path: str | None = None, org_bu: str | None = None):
        self.account_id = account_id or os.environ.get("NEW_RELIC_ACCOUNT_ID")
        self.key = key or os.environ.get("NEW_RELIC_LICENSE_KEY")
        self.region = (region or os.environ.get("NEW_RELIC_REGION") or "eu").lower()
        self.org_bu = org_bu or os.environ.get("ORG_BU") or "hiscox-re"
        env_dry = os.environ.get("NR_DRY_RUN") == "1"
        self.dry_run_path = dry_run_path or (os.environ.get("NR_DRY_RUN_PATH", "events.ndjson") if env_dry else None)
        if not self.dry_run_path and not (self.account_id and self.key):
            raise SystemExit("Set NEW_RELIC_ACCOUNT_ID and NEW_RELIC_LICENSE_KEY, or use a dry run")

    def send(self, envelopes: Iterable[dict[str, Any]]) -> int:
        flat = [to_newrelic(e, self.org_bu) for e in envelopes]
        if not flat:
            return 0
        if self.dry_run_path:
            with open(self.dry_run_path, "a", encoding="utf-8") as f:
                for e in flat:
                    f.write(json.dumps(e) + "\n")
            return len(flat)
        sent = 0
        for batch in _batches(flat):
            body = gzip.compress(json.dumps(batch).encode())
            req = urllib.request.Request(
                ENDPOINTS[self.region].format(account=self.account_id), data=body, method="POST",
                headers={"Api-Key": self.key, "Content-Type": "application/json", "Content-Encoding": "gzip"})
            with urllib.request.urlopen(req, timeout=30) as resp:
                if resp.status >= 300:
                    raise RuntimeError(f"New Relic returned {resp.status}")
            sent += len(batch)
        return sent


def _batches(events: list[dict]) -> Iterable[list[dict]]:
    batch, size = [], 2
    for e in events:
        n = len(json.dumps(e)) + 1
        if batch and (len(batch) >= MAX_EVENTS_PER_POST or size + n > MAX_BYTES_PER_POST):
            yield batch
            batch, size = [], 2
        batch.append(e)
        size += n
    if batch:
        yield batch
