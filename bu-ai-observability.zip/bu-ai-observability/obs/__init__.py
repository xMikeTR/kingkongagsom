"""Shared core for the BU AI observability layer.

ids      -> our own work-item IDs (wi_ + ULID)
aliases  -> alias table: jira:RE-1234 / ado:AB#5678 / git:branch/... -> wi_...
events   -> canonical event contract (CloudEvents 1.0 envelope)
nr       -> sender for New Relic's Event API (the PoV's event stream)
"""
