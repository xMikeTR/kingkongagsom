"""Alias table: every external key resolves to one of our work-item IDs.

Alias forms (system:key):
  jira:RE-1234        a Jira issue key
  ado:AB#5678         an Azure DevOps work item
  git:<branch name>   a branch; resolved through the ticket key inside it

Resolution happens at the edge (adapters, value view). Nothing downstream
ever sees a raw Jira key as an identifier: parse, don't validate.

Storage is a plain CSV (work_item_id, alias, created_at) so it can be uploaded
to New Relic as a lookup table and read by Power BI without a database.
"""
from __future__ import annotations

import csv
import os
import re
from datetime import datetime, timezone

from .ids import WI_UNASSIGNED, is_work_item_id, new_work_item_id

DEFAULT_TICKET_PATTERN = r"([A-Z][A-Z0-9]+-[0-9]+|AB#[0-9]+)"
FIELDS = ["work_item_id", "alias", "created_at"]


def ticket_key_from_text(text: str | None, pattern: str | None = None) -> str | None:
    m = re.search(pattern or DEFAULT_TICKET_PATTERN, text or "")
    return m.group(1) if m else None


def normalise(alias: str | None, pattern: str | None = None) -> str | None:
    """Turn any alias form into its canonical tracker alias.

    'jira:RE-1234' -> 'jira:RE-1234'
    'RE-1234'      -> 'jira:RE-1234'
    'AB#5678'      -> 'ado:AB#5678'
    'git:RE-1234-fix-pricing' or a bare branch -> 'jira:RE-1234'
    Anything without a ticket key -> None
    """
    if not alias:
        return None
    alias = alias.strip()
    system, _, rest = alias.partition(":")
    if rest and system in ("jira", "ado"):
        return f"{system}:{rest}"
    text = rest if (rest and system == "git") else alias
    key = ticket_key_from_text(text, pattern)
    if not key:
        return None
    return f"ado:{key}" if key.startswith("AB#") else f"jira:{key}"


class AliasTable:
    def __init__(self, path: str | None = None, pattern: str | None = None):
        self.path = path
        self.pattern = pattern or os.environ.get("AI_OBS_TICKET_REGEX") or DEFAULT_TICKET_PATTERN
        self._by_alias: dict[str, str] = {}
        self._rows: list[dict] = []
        if path and os.path.exists(path):
            with open(path, newline="", encoding="utf-8") as f:
                for row in csv.DictReader(f):
                    self._add(row["work_item_id"], row["alias"], row.get("created_at", ""))

    def _add(self, wi: str, alias: str, created_at: str) -> None:
        if not is_work_item_id(wi):
            raise ValueError(f"not a work-item id: {wi!r}")
        if alias in self._by_alias and self._by_alias[alias] != wi:
            raise ValueError(f"alias {alias} already points at {self._by_alias[alias]}")
        if alias not in self._by_alias:
            self._by_alias[alias] = wi
            self._rows.append({"work_item_id": wi, "alias": alias, "created_at": created_at})

    def resolve(self, alias_or_branch: str | None) -> str:
        """Any alias or branch -> work-item ID, or WI_UNASSIGNED. Never raises."""
        canon = normalise(alias_or_branch, self.pattern)
        return self._by_alias.get(canon, WI_UNASSIGNED) if canon else WI_UNASSIGNED

    def ensure(self, alias: str) -> str:
        """Return the work-item ID for a tracker alias, minting one if new."""
        canon = normalise(alias, self.pattern)
        if not canon:
            raise ValueError(f"no ticket key in alias {alias!r}")
        if canon in self._by_alias:
            return self._by_alias[canon]
        wi = new_work_item_id()
        self._add(wi, canon, datetime.now(timezone.utc).isoformat(timespec="seconds"))
        return wi

    def link(self, new_alias: str, existing_alias: str) -> str:
        """Migration: point a new tracker's key at an existing work item.
        e.g. link('ado:AB#5678', 'jira:RE-1234') keeps all history joined."""
        wi = self.resolve(existing_alias)
        if wi == WI_UNASSIGNED:
            raise ValueError(f"{existing_alias} is not in the table")
        canon = normalise(new_alias, self.pattern)
        if not canon:
            raise ValueError(f"no ticket key in alias {new_alias!r}")
        self._add(wi, canon, datetime.now(timezone.utc).isoformat(timespec="seconds"))
        return wi

    def aliases_of(self, wi: str) -> list[str]:
        return [r["alias"] for r in self._rows if r["work_item_id"] == wi]

    def save(self, path: str | None = None) -> None:
        target = path or self.path
        if not target:
            raise ValueError("no path to save to")
        tmp = target + ".tmp"
        with open(tmp, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=FIELDS)
            w.writeheader()
            w.writerows(self._rows)
        os.replace(tmp, target)

    def __len__(self) -> int:
        return len(self._rows)
