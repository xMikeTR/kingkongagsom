"""Canonical event contract v0 (see contracts/events.md).

Every event is a CloudEvents 1.0 envelope. `subject` is always our
work-item ID (or wi_unassigned), so every consumer can join on it.

Attribute names follow OTel GenAI semantic conventions where one exists;
in the flat New Relic form, dots are kept (gen_ai.request.model).
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from .ids import WI_UNASSIGNED, is_work_item_id, ulid

SPEC_VERSION = "1.0"
TYPE_PREFIX = "com.hiscox.re.ai."
CONTRACT_VERSION = "v0"

# type -> (required data fields, optional data fields)
CONTRACT: dict[str, tuple[tuple[str, ...], tuple[str, ...]]] = {
    # work
    "WorkItemCreated": (("alias",), ("task_class", "task_size", "team", "work_stream", "created_at")),
    "WorkItemStatusChanged": (("alias", "to_status"), ("from_status", "status_category", "changed_at")),
    "WorkItemDone": (("alias", "done_at"), ("resolution",)),
    # AI
    "AISessionStarted": (("session.id", "harness"), ("enduser.id", "git.branch", "git.repo", "work_item.alias", "session.source")),
    "AIUsage": (("harness", "gen_ai.request.model", "billing_source"),
                ("session.id", "enduser.id", "gen_ai.usage.input_tokens", "gen_ai.usage.output_tokens",
                 "cost_usd", "ai_credits_used", "usage_date")),
    # delivery
    "CIRunCompleted": (("repo", "run_id", "conclusion"), ("branch", "attempt", "duration_s", "workflow")),
    "PRMerged": (("repo", "pr_number"), ("branch", "merged_at")),
    "QAGatePassed": (("attempt_n",), ("repo", "branch", "mutation_score")),
    "QABouncedBack": (("attempt_n",), ("reason",)),
    # outcomes and evaluation
    "TaskOutcome": (("outcome", "attempt_n"), ("gen_ai.request.model", "task_class", "task_size", "cost_usd", "wallclock_hours")),
    "EvalResult": (("suite", "case_id", "passed"), ("gen_ai.request.model", "score", "harness_version")),
    "BenchRun": (("bench.version", "gen_ai.request.model", "outcome"),
                 ("task_class", "task_size", "attempt_n", "cost_usd", "turns", "tool_calls", "tool_errors",
                  "wallclock_s", "mutation_score", "crap_delta")),
}

OUTCOMES = {"pass", "reworked", "fail", "abandoned"}
HARNESSES = {"claude-code", "copilot", "copilot-cli", "copilot-sdk", "own-agent", "apim", "unknown"}
BILLING_SOURCES = {"apim", "github", "anthropic", "vertex", "unknown"}


class ContractError(ValueError):
    pass


def make_event(event_type: str, source: str, subject: str | None, data: dict[str, Any],
               time: datetime | None = None, event_id: str | None = None,
               alias: str | None = None) -> dict[str, Any]:
    """`alias` (CloudEvents extension `workitemalias`) carries the raw tracker
    key when the emitter cannot resolve it (e.g. a CI job without the alias
    table). Consumers re-resolve wi_unassigned events through it."""
    if event_type not in CONTRACT:
        raise ContractError(f"unknown event type {event_type!r}")
    ev = {
        "specversion": SPEC_VERSION,
        "id": event_id or ulid(),
        "source": source,
        "type": f"{TYPE_PREFIX}{event_type}.{CONTRACT_VERSION}",
        "subject": subject or WI_UNASSIGNED,
        "time": (time or datetime.now(timezone.utc)).isoformat(timespec="seconds"),
        "datacontenttype": "application/json",
        "data": {k: v for k, v in data.items() if v is not None and v != ""},
    }
    if alias:
        ev["workitemalias"] = alias
    validate(ev)
    return ev


def short_type(ev: dict[str, Any]) -> str:
    t = ev.get("type", "")
    if not t.startswith(TYPE_PREFIX):
        raise ContractError(f"type {t!r} is not ours")
    return t[len(TYPE_PREFIX):].rsplit(".", 1)[0]


def validate(ev: dict[str, Any]) -> None:
    for k in ("specversion", "id", "source", "type", "subject", "time", "data"):
        if k not in ev:
            raise ContractError(f"missing envelope field {k}")
    if ev["specversion"] != SPEC_VERSION:
        raise ContractError("specversion must be 1.0")
    if not is_work_item_id(ev["subject"]):
        raise ContractError(f"subject must be a work-item id, got {ev['subject']!r}")
    name = short_type(ev)
    if name not in CONTRACT:
        raise ContractError(f"unknown event type {name!r}")
    required, optional = CONTRACT[name]
    data = ev["data"]
    missing = [f for f in required if f not in data]
    if missing:
        raise ContractError(f"{name}: missing {missing}")
    unknown = [f for f in data if f not in required and f not in optional]
    if unknown:
        raise ContractError(f"{name}: fields not in contract {unknown}")
    for prompt_like in ("prompt", "completion", "messages", "gen_ai.prompt", "gen_ai.completion"):
        if prompt_like in data:
            raise ContractError("content fields are never allowed in events")
    if name in ("TaskOutcome", "BenchRun") and data["outcome"] not in OUTCOMES:
        raise ContractError(f"outcome must be one of {sorted(OUTCOMES)}")
    if name in ("AISessionStarted", "AIUsage") and data["harness"] not in HARNESSES:
        raise ContractError(f"harness must be one of {sorted(HARNESSES)}")
    if name == "AIUsage" and data["billing_source"] not in BILLING_SOURCES:
        raise ContractError(f"billing_source must be one of {sorted(BILLING_SOURCES)}")


def to_newrelic(ev: dict[str, Any], org_bu: str = "hiscox-re") -> dict[str, Any]:
    """Flatten an envelope into one New Relic custom event."""
    validate(ev)
    ts = datetime.fromisoformat(ev["time"])
    flat = {
        "eventType": short_type(ev),
        "timestamp": int(ts.timestamp() * 1000),
        "work_item.id": ev["subject"],
        "ce.id": ev["id"],
        "ce.source": ev["source"],
        "ce.type": ev["type"],
        "org.bu": org_bu,
        "telemetry.pipeline": "agentic-ops",
    }
    if ev.get("workitemalias"):
        flat["work_item.alias"] = ev["workitemalias"]
    for k, v in ev["data"].items():
        flat[k] = v if isinstance(v, (int, float, str, bool)) else str(v)
    return flat
