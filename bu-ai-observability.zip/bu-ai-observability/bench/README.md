# Replay benchmark (Phase 7.2)

An internal SWE-bench-style suite on our own codebase. The authoritative
answer to "would a cheaper model do as well?".

1. **Corpus.** Closed tickets with a merged PR and passing tests. Stratify
   across `task_class` and size. Start with ~30, grow to 100+. One file per
   task: `bench/tasks/<work_item_id>.yaml` (see `TEMPLATE.yaml`).
2. **Isolation.** Each run in a fresh environment checked out at the base SHA —
   reuse the per-ticket slots script or a container. Reference tests are hidden
   from the agent and added only at scoring time.
3. **Run matrix.** Each task × each candidate model × k runs (k ≥ 3), same
   harness, prompt, tools and budget caps (max tokens, max wall-clock). Only
   the model changes.
4. **Scoring.** Run the existing QA gate (tests incl. hidden reference tests,
   mutation score, CRAP/complexity delta, lint/security). Record pass/fail plus
   each sub-score.
5. **Emit** a `BenchRun` event per run (contract fields: bench.version, model,
   outcome, task_class, task_size, attempt_n, cost_usd, turns, tool_calls,
   tool_errors, wallclock_s, mutation_score, crap_delta), and append a row to
   `bench_runs.csv` for the value view.
6. **Cadence.** On demand, and when a new model becomes available on
   Vertex/APIM. Pin `bench.version`; never edit tasks in place.
7. **Contamination.** Prefer recent tickets. Public models won't have trained on
   our private repo, but keep reference tests hidden regardless.

Acceptance: ≥ 30 tasks × 2 models × k=3 end to end, frontier chart with CIs,
and a one-paragraph finding per task class stating where a cheaper model is
statistically equivalent.
