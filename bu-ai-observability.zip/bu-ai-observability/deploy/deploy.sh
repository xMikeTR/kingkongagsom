#!/usr/bin/env bash
# max-replicas=1 while the Event Hub receiver lives in this app (see apim overlay).
# Deploys the collector to Azure Container Apps. Idempotent-ish: rerun to update.
# Langfuse is not deployed: it stays a local, personal workbench.
set -euo pipefail
: "${RG:?}" "${LOCATION:?}" "${ACR:?}" "${ENV_NAME:?}" "${KV_NAME:?}" "${IDENTITY_ID:?}"
APP=agentic-ops-collector
TAG=$(git rev-parse --short HEAD 2>/dev/null || date +%s)

az acr build -r "$ACR" -t "$APP:$TAG" ../collector

# Secrets come from Key Vault via the managed identity (needs 'Key Vault Secrets User').
kv() { echo "keyvaultref:https://${KV_NAME}.vault.azure.net/secrets/$1,identityref:${IDENTITY_ID}"; }

az containerapp create -g "$RG" -n "$APP" --environment "$ENV_NAME" \
  --image "$ACR.azurecr.io/$APP:$TAG" \
  --registry-server "$ACR.azurecr.io" --registry-identity "$IDENTITY_ID" \
  --user-assigned "$IDENTITY_ID" \
  --ingress external --target-port 4318 --transport http \
  --min-replicas 1 --max-replicas 1 --cpu 0.5 --memory 1Gi \
  --args "--config=/etc/otelcol-contrib/config.yaml" "--config=/etc/otelcol-contrib/apim.yaml" \
  --secrets \
    "ingest-token=$(kv otel-ingest-token)" \
    "nr-license=$(kv newrelic-license-key)" \
    "eventhub-conn=$(kv apim-eventhub-connection)" \
  --env-vars \
    DEPLOY_ENV=prod DEBUG_VERBOSITY=basic ORG_BU=hiscox-re \
    NEW_RELIC_OTLP_ENDPOINT=https://otlp.eu01.nr-data.net \
    INGEST_TOKEN=secretref:ingest-token \
    NEW_RELIC_LICENSE_KEY=secretref:nr-license \
    EVENTHUB_CONNECTION=secretref:eventhub-conn

az containerapp show -g "$RG" -n "$APP" --query properties.configuration.ingress.fqdn -o tsv
