# Teams channel for Claude Code

Drive running Claude Code sessions from Microsoft Teams — the same idea as the
official Telegram/Discord channels, adapted to Microsoft Graph.

```
Teams (phone, work profile)
   │  you type in a chat, or in a session's thread
   ▼
Microsoft Graph  ◄──── poll every 4s (your delegated token) ────┐
   ▲                                                            │
   │ reply / react / edit                                       │
   │                                          teams channel MCP server (bun)
Workflows webhook ◄──── notify (pings phone) ───┘               │
                                                                ▼
                                            <channel source="teams" ...> → your Claude Code session
```

## Why it's built this way

- **Polling Graph, not a bot.** No public endpoint, no Azure Bot resource, works from behind the corporate network. A bot is the v2 path if you want buttons.
- **Delegated auth, verified sender.** Messages are gated on `from.user.id` as reported by Graph. You're always allowed; anyone else must be in `access.json`. No pairing codes to leak.
- **Two modes.**
  - `chat`: one 1:1 or group chat. Needs only `Chat.ReadWrite`, usually without admin consent. Several sessions can share it — prefix with `#tag` to target one (tag defaults to the project folder name, `#all` hits every session).
  - `channel`: every session opens its **own thread** in a Teams channel. This is the clean way to watch many sessions. Needs `ChannelMessage.Read.All` (admin consent).
- **The notification catch.** Anything posted with your token shows up as *you*, and Teams doesn't notify you about your own messages. So replies are silent. The `notify` tool and permission prompts also go through a **Workflows webhook**, which posts as a bot and pings your phone.

## What you get

| From Teams | What happens |
|---|---|
| any message | lands in the session as a channel event (👀 reaction = received) |
| pasted image | downloaded and handed to Claude to Read |
| `#legacy-migration run the tests` | only that session picks it up |
| `!ping` | each listening session answers with host, folder and last activity, without waking Claude |
| `yes abcde` / `no abcde` | approves or denies a pending tool permission prompt |

Claude can `reply` (Markdown, code fences, images), `react`, `edit_message` (progress), and `notify` (phone ping when done or blocked).

## Setup

**1. Entra app registration** (single tenant, no secret)
- Authentication → *Allow public client flows* = **Yes**
- API permissions → Microsoft Graph → **Delegated**:
  - chat mode: `User.Read`, `Chat.ReadWrite`
  - channel mode: add `ChannelMessage.Send`, `ChannelMessage.Read.All`, `Team.ReadBasic.All`, `Channel.ReadBasic.All`

**2. Install the plugin**
```
/plugin marketplace add <path-or-git-url-of-this-repo>
/plugin install teams@mike-channels
/teams:configure tenant <tenant-id>
/teams:configure client <client-id>
/teams:configure mode chat          # or channel
```

**3. Sign in and pick the target** (terminal, once; refresh token is cached)
```bash
cd ~/.claude/plugins/.../teams && bun run login
```

**4. Phone pings** (recommended): in the target chat/channel → `…` → Workflows → *Send webhook alerts to a chat* → copy URL →
```
/teams:configure webhook <url>
```

**5. Run**
```bash
claude --dangerously-load-development-channels plugin:teams@mike-channels
```
Custom channels need the development flag during the research preview.

## Enterprise gates (the real blockers at work)

1. **`channelsEnabled`** — on a claude.ai Team/Enterprise org, channels are off until an Owner enables them (Admin settings → Claude Code → Channels).
2. **`allowedChannelPlugins`** — to run without the dev flag, an admin lists `{ "marketplace": "mike-channels", "plugin": "teams" }` (or wherever it ends up in an internal marketplace).
3. **Graph consent** — chat mode is usually user-consentable; channel mode needs admin consent. If user consent is off tenant-wide, both need an admin.

All three are policy conversations, not code. It's worth pitching as a governed surface: one registered app, delegated scopes, Graph-verified sender, every message auditable in Teams.

## Develop

```bash
cd plugins/teams
bun install
bun run typecheck
bun run test        # fake Graph + fake webhook + real MCP client, 31 checks
```

## Limits (v0.1)

- Sending non-image files isn't supported (Teams files live in SharePoint/OneDrive).
- Inbound shared files are listed by name only.
- `edit_message` in channel mode may need extra consent depending on tenant.
- The `48:notes` (chat with yourself) target is offered in login but untested against real Graph.
- Sessions only listen while open; run Claude in tmux for always-on.
