/**
 * Delegated Microsoft Graph auth via MSAL public client.
 *
 * Interactive sign-in (device code) only happens in `bun run login`, in a
 * terminal the user is looking at. The channel server only ever refreshes
 * silently from the cached refresh token — it never prompts.
 */

import {
  PublicClientApplication,
  type Configuration,
  type ICachePlugin,
  type TokenCacheContext,
  type AccountInfo,
} from '@azure/msal-node'
import { readFileSync, writeFileSync } from 'fs'
import { TOKEN_CACHE_FILE, ensureStateDir, type Config, type Mode } from './state.ts'

export function scopesFor(mode: Mode): string[] {
  // offline_access/openid/profile are added by MSAL automatically.
  return mode === 'channel'
    ? [
        'User.Read',
        'ChannelMessage.Send',
        'ChannelMessage.Read.All', // needs admin consent
        'Team.ReadBasic.All',
        'Channel.ReadBasic.All',
      ]
    : ['User.Read', 'Chat.ReadWrite']
}

const cachePlugin: ICachePlugin = {
  async beforeCacheAccess(ctx: TokenCacheContext) {
    try {
      ctx.tokenCache.deserialize(readFileSync(TOKEN_CACHE_FILE, 'utf8'))
    } catch {}
  },
  async afterCacheAccess(ctx: TokenCacheContext) {
    if (!ctx.cacheHasChanged) return
    ensureStateDir()
    writeFileSync(TOKEN_CACHE_FILE, ctx.tokenCache.serialize(), { mode: 0o600 })
  },
}

export function makeClient(cfg: Config): PublicClientApplication {
  if (!cfg.tenantId || !cfg.clientId) {
    throw new Error('tenantId and clientId must be set — run /teams:configure')
  }
  const proxyUrl = process.env.HTTPS_PROXY ?? process.env.https_proxy
  const conf: Configuration = {
    auth: {
      clientId: cfg.clientId,
      authority: `https://login.microsoftonline.com/${cfg.tenantId}`,
    },
    cache: { cachePlugin },
    system: proxyUrl ? { proxyUrl } : undefined,
  }
  return new PublicClientApplication(conf)
}

export type TokenSource = () => Promise<string>

/**
 * Returns a function that yields a valid access token, refreshing silently.
 * TEAMS_ACCESS_TOKEN short-circuits MSAL (testing, or tokens minted elsewhere).
 */
export function tokenSource(cfg: Config): TokenSource {
  const fixed = process.env.TEAMS_ACCESS_TOKEN
  if (fixed) return async () => fixed

  const pca = makeClient(cfg)
  const scopes = scopesFor(cfg.mode ?? 'chat')
  let account: AccountInfo | null = null

  return async () => {
    if (!account) {
      const accounts = await pca.getTokenCache().getAllAccounts()
      account = accounts.find(a => a.localAccountId === cfg.selfId) ?? accounts[0] ?? null
      if (!account) throw new Error('not signed in — run `bun run login` in the plugin folder')
    }
    const res = await pca.acquireTokenSilent({ account, scopes })
    if (!res?.accessToken) throw new Error('token refresh returned nothing — run `bun run login` again')
    return res.accessToken
  }
}
