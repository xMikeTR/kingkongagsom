#!/usr/bin/env bun
/**
 * One-time sign-in + target picker. Run in a terminal:
 *
 *   bun run login                       # sign in, then pick a chat/channel interactively
 *   bun run login -- --chat <chatId>    # sign in, set chat non-interactively
 *   bun run login -- --team <id> --channel <id>
 *
 * tenantId, clientId and mode come from config.json (/teams:configure).
 */

import { createInterface } from 'readline/promises'
import { readConfig, writeConfig, loadEnvFile, ensureStateDir, CONFIG_FILE } from './state.ts'
import { makeClient, scopesFor } from './auth.ts'
import { Graph } from './graph.ts'

loadEnvFile()
const cfg = readConfig()
const mode = cfg.mode ?? 'chat'
const arg = (name: string) => {
  const i = process.argv.indexOf(`--${name}`)
  return i > 0 ? process.argv[i + 1] : undefined
}

if (!cfg.tenantId || !cfg.clientId) {
  console.error(`tenantId and clientId missing in ${CONFIG_FILE} — run /teams:configure in Claude Code first.`)
  process.exit(1)
}
ensureStateDir()

const pca = makeClient(cfg)
const scopes = scopesFor(mode)
console.log(`Signing in for ${mode} mode. Scopes: ${scopes.join(', ')}\n`)

const result = await pca.acquireTokenByDeviceCode({
  scopes,
  deviceCodeCallback: r => console.log(r.message + '\n'),
})
if (!result?.accessToken) {
  console.error('Sign-in did not return a token.')
  process.exit(1)
}
const token = result.accessToken
const graph = new Graph(async () => token)
const me = await graph.me()
console.log(`Signed in as ${me.displayName} (${me.id})\n`)
cfg.selfId = me.id
cfg.selfName = me.displayName

const rl = createInterface({ input: process.stdin, output: process.stdout })
async function pick<T>(items: T[], show: (t: T) => string, prompt: string): Promise<T> {
  items.forEach((t, i) => console.log(`  ${String(i + 1).padStart(2)}. ${show(t)}`))
  for (;;) {
    const n = Number(await rl.question(`\n${prompt} [1-${items.length}]: `))
    if (n >= 1 && n <= items.length) return items[n - 1]
  }
}

type Chat = { id: string; topic?: string | null; chatType: string; members?: { displayName?: string; userId?: string }[] }

if (mode === 'chat') {
  const given = arg('chat')
  if (given) {
    cfg.chatId = given
  } else {
    const r = await graph.json<{ value: Chat[] }>('GET', '/me/chats?$expand=members&$top=50')
    const chats: Chat[] = [
      { id: '48:notes', topic: 'Chat with yourself (Notes) — experimental via Graph', chatType: 'self' },
      ...(r.value ?? []),
    ]
    const name = (c: Chat) =>
      c.topic ||
      (c.members ?? []).filter(m => m.userId !== me.id).map(m => m.displayName).join(', ') ||
      c.id
    console.log('Pick the chat to bridge. A group chat with just you (or you + a test account) is ideal.\n')
    cfg.chatId = (await pick(chats, c => `[${c.chatType}] ${name(c)}`, 'Chat')).id
  }
} else {
  const team = arg('team')
  const channel = arg('channel')
  if (team && channel) {
    cfg.teamId = team
    cfg.channelId = channel
  } else {
    const teams = (await graph.json<{ value: { id: string; displayName: string }[] }>('GET', '/me/joinedTeams')).value
    const t = await pick(teams, x => x.displayName, 'Team')
    const chans = (await graph.json<{ value: { id: string; displayName: string; membershipType?: string }[] }>(
      'GET', `/teams/${t.id}/channels`,
    )).value
    const c = await pick(chans, x => `${x.displayName}${x.membershipType && x.membershipType !== 'standard' ? ` (${x.membershipType})` : ''}`, 'Channel')
    cfg.teamId = t.id
    cfg.channelId = c.id
  }
}
rl.close()

writeConfig(cfg)
console.log(`\nSaved to ${CONFIG_FILE}. Start Claude Code with the channel enabled (see README).`)
process.exit(0)
