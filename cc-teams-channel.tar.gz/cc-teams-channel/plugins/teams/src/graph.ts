/**
 * Thin Microsoft Graph client + two "targets" the channel can talk to:
 *
 *   ChatTarget    — a 1:1 or group chat. Only Chat.ReadWrite (no admin consent).
 *   ThreadTarget  — a thread in a Teams channel. The session posts a root
 *                   message at startup and only listens to replies under it,
 *                   so several sessions can share one channel cleanly.
 */

import type { TokenSource } from './auth.ts'

export const GRAPH_BASE = (process.env.TEAMS_GRAPH_BASE ?? 'https://graph.microsoft.com/v1.0').replace(/\/$/, '')
const GRAPH_ORIGIN = new URL(GRAPH_BASE).origin

export type GraphMessage = {
  id: string
  createdDateTime: string
  messageType?: string
  deletedDateTime?: string | null
  from?: { user?: { id?: string; displayName?: string } | null; application?: unknown } | null
  body?: { contentType?: string; content?: string }
  attachments?: { id?: string; contentType?: string; name?: string; contentUrl?: string }[]
}

export type HostedImage = { tempId: string; bytesB64: string; contentType: string }

export class GraphError extends Error {
  constructor(public status: number, public body: string, path: string) {
    super(`Graph ${status} on ${path}: ${body.slice(0, 300)}`)
  }
}

export class Graph {
  constructor(private token: TokenSource) {}

  async raw(method: string, path: string, body?: unknown): Promise<Response> {
    const url = path.startsWith('http') ? path : GRAPH_BASE + path
    // Never send the bearer token anywhere but Graph.
    if (new URL(url).origin !== GRAPH_ORIGIN) throw new Error(`refusing to call non-Graph URL: ${url}`)
    for (let attempt = 1; ; attempt++) {
      const res = await fetch(url, {
        method,
        headers: {
          Authorization: `Bearer ${await this.token()}`,
          ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}),
        },
        body: body !== undefined ? JSON.stringify(body) : undefined,
      })
      const retryable = res.status === 429 || res.status === 503 || res.status === 504
      if (retryable && attempt < 5) {
        const ra = Number(res.headers.get('Retry-After'))
        const delay = Number.isFinite(ra) && ra > 0 ? ra * 1000 : Math.min(1000 * 2 ** attempt, 20000)
        await new Promise(r => setTimeout(r, delay))
        continue
      }
      if (!res.ok) throw new GraphError(res.status, await res.text(), path)
      return res
    }
  }

  async json<T>(method: string, path: string, body?: unknown): Promise<T> {
    const res = await this.raw(method, path, body)
    const text = await res.text()
    return (text ? JSON.parse(text) : {}) as T
  }

  me() {
    return this.json<{ id: string; displayName: string }>('GET', '/me?$select=id,displayName')
  }

  /** Download a hostedContents image. Only Graph URLs are fetched (token safety). */
  async download(url: string): Promise<{ buf: Buffer; contentType: string }> {
    const res = await this.raw('GET', url)
    return {
      buf: Buffer.from(await res.arrayBuffer()),
      contentType: res.headers.get('Content-Type') ?? 'application/octet-stream',
    }
  }
}

export interface Target {
  /** ID Claude passes back to `reply` (chat id or thread root id). */
  readonly id: string
  readonly label: string
  /** Newest messages, any order. Caller filters. */
  recent(): Promise<GraphMessage[]>
  send(html: string, images?: HostedImage[]): Promise<string>
  edit(messageId: string, html: string): Promise<void>
  react(messageId: string, emoji: string): Promise<void>
}

function messageBody(html: string, images: HostedImage[] = []) {
  return {
    body: { contentType: 'html', content: html },
    ...(images.length
      ? {
          hostedContents: images.map(i => ({
            '@microsoft.graph.temporaryId': i.tempId,
            contentBytes: i.bytesB64,
            contentType: i.contentType,
          })),
        }
      : {}),
  }
}

export class ChatTarget implements Target {
  readonly label: string
  constructor(private g: Graph, readonly id: string) {
    this.label = `chat ${id.slice(0, 12)}…`
  }
  private base() {
    return `/chats/${encodeURIComponent(this.id)}/messages`
  }
  async recent() {
    const r = await this.g.json<{ value: GraphMessage[] }>(
      'GET', `${this.base()}?$top=20&$orderby=createdDateTime desc`,
    )
    return r.value ?? []
  }
  async send(html: string, images?: HostedImage[]) {
    const r = await this.g.json<{ id: string }>('POST', this.base(), messageBody(html, images))
    return r.id
  }
  async edit(messageId: string, html: string) {
    await this.g.raw('PATCH', `${this.base()}/${encodeURIComponent(messageId)}`, {
      body: { contentType: 'html', content: html },
    })
  }
  async react(messageId: string, emoji: string) {
    await this.g.raw('POST', `${this.base()}/${encodeURIComponent(messageId)}/setReaction`, { reactionType: emoji })
  }
}

export class ThreadTarget implements Target {
  private rootId = ''
  readonly label: string
  constructor(private g: Graph, private teamId: string, private channelId: string) {
    this.label = `channel ${channelId.slice(0, 12)}…`
  }
  get id() {
    return this.rootId
  }
  private chan() {
    return `/teams/${encodeURIComponent(this.teamId)}/channels/${encodeURIComponent(this.channelId)}/messages`
  }
  private replies() {
    return `${this.chan()}/${encodeURIComponent(this.rootId)}/replies`
  }
  /** Post the root message that defines this session's thread. */
  async open(html: string): Promise<string> {
    const r = await this.g.json<{ id: string }>('POST', this.chan(), messageBody(html))
    this.rootId = r.id
    return r.id
  }
  async recent() {
    const r = await this.g.json<{ value: GraphMessage[] }>('GET', `${this.replies()}?$top=50`)
    return r.value ?? []
  }
  async send(html: string, images?: HostedImage[]) {
    const r = await this.g.json<{ id: string }>('POST', this.replies(), messageBody(html, images))
    return r.id
  }
  async edit(messageId: string, html: string) {
    await this.g.raw('PATCH', `${this.replies()}/${encodeURIComponent(messageId)}`, {
      body: { contentType: 'html', content: html },
    })
  }
  async react(messageId: string, emoji: string) {
    await this.g.raw('POST', `${this.replies()}/${encodeURIComponent(messageId)}/setReaction`, { reactionType: emoji })
  }
}
