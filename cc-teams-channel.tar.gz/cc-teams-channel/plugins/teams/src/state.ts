/**
 * Shared state: where config, tokens and access lists live.
 *
 *   <state-dir>/config.json   tenant, app id, target chat/channel, UX knobs
 *   <state-dir>/access.json   AAD object IDs allowed to drive the session
 *   <state-dir>/.env          secrets (notify webhook URL)
 *   <state-dir>/msal-cache.json  refresh token cache (0600)
 *
 * Default <state-dir> is ~/.claude/channels/teams.
 */

import { readFileSync, writeFileSync, mkdirSync, renameSync, chmodSync } from 'fs'
import { homedir } from 'os'
import { join } from 'path'

export const STATE_DIR = process.env.TEAMS_STATE_DIR
  ?? join(process.env.CLAUDE_CONFIG_DIR ?? join(homedir(), '.claude'), 'channels', 'teams')
export const CONFIG_FILE = join(STATE_DIR, 'config.json')
export const ACCESS_FILE = join(STATE_DIR, 'access.json')
export const ENV_FILE = join(STATE_DIR, '.env')
export const TOKEN_CACHE_FILE = join(STATE_DIR, 'msal-cache.json')
export const INBOX_DIR = join(STATE_DIR, 'inbox')

export type Mode = 'chat' | 'channel'

export type Config = {
  tenantId?: string
  clientId?: string
  /** 'chat' = a 1:1/group chat (no admin consent). 'channel' = a Teams channel, one thread per session. */
  mode?: Mode
  chatId?: string
  teamId?: string
  channelId?: string
  /** Signed-in user's AAD object ID, written by login. Messages from this ID are always allowed. */
  selfId?: string
  selfName?: string
  pollIntervalMs?: number
  /** Emoji reaction on receipt. "" disables. */
  ackReaction?: string
  /** Post an "online" message when a session starts. Default true. */
  announce?: boolean
  /** Max chars per outbound message before splitting. */
  textChunkLimit?: number
}

export type Access = {
  /** Extra AAD object IDs allowed besides selfId (only matters in shared chats/channels). */
  allowFrom: string[]
}

export function ensureStateDir(): void {
  mkdirSync(STATE_DIR, { recursive: true, mode: 0o700 })
}

/** Load <state-dir>/.env into process.env. Real env wins. */
export function loadEnvFile(): void {
  try {
    chmodSync(ENV_FILE, 0o600)
    for (const line of readFileSync(ENV_FILE, 'utf8').split('\n')) {
      const m = line.match(/^(\w+)=(.*)$/)
      if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2]
    }
  } catch {}
}

function readJson<T>(file: string, fallback: T): T {
  try {
    return JSON.parse(readFileSync(file, 'utf8')) as T
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code === 'ENOENT') return fallback
    try { renameSync(file, `${file}.corrupt-${Date.now()}`) } catch {}
    process.stderr.write(`teams channel: ${file} is corrupt, moved aside\n`)
    return fallback
  }
}

function writeJson(file: string, value: unknown): void {
  ensureStateDir()
  const tmp = file + '.tmp'
  writeFileSync(tmp, JSON.stringify(value, null, 2) + '\n', { mode: 0o600 })
  renameSync(tmp, file)
}

export function readConfig(): Config {
  return readJson<Config>(CONFIG_FILE, {})
}

export function writeConfig(c: Config): void {
  writeJson(CONFIG_FILE, c)
}

export function readAccess(): Access {
  const a = readJson<Partial<Access>>(ACCESS_FILE, {})
  return { allowFrom: a.allowFrom ?? [] }
}
