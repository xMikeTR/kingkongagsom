/**
 * Teams speaks HTML. Claude speaks Markdown-ish text. Convert both ways,
 * conservatively — this is a chat bridge, not a renderer.
 */

/** Marker prefixed to everything the channel posts, so the poller never feeds Claude its own output. */
export const BOT_MARK = '🤖'

const ENTITIES: Record<string, string> = {
  amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ', '#39': "'",
}

function decodeEntities(s: string): string {
  return s.replace(/&(#x[0-9a-f]+|#\d+|\w+);/gi, (m, e: string) => {
    if (e[0] === '#') {
      const code = e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10)
      return Number.isFinite(code) ? String.fromCodePoint(code) : m
    }
    return ENTITIES[e.toLowerCase()] ?? m
  })
}

export function escapeHtml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
}

/** Graph message body (html or text) → plain text Claude can read. */
export function htmlToText(body: { contentType?: string; content?: string } | undefined): string {
  const raw = body?.content ?? ''
  if ((body?.contentType ?? 'html').toLowerCase() === 'text') return raw.trim()
  let s = raw
  // Code blocks: keep their newlines, fence them.
  s = s.replace(/<pre[^>]*>([\s\S]*?)<\/pre>/gi, (_m, inner: string) => {
    const code = decodeEntities(inner.replace(/<br\s*\/?>/gi, '\n').replace(/<[^>]+>/g, ''))
    return `\n\`\`\`\n${code.replace(/\n+$/, '')}\n\`\`\`\n`
  })
  s = s.replace(/<code[^>]*>([\s\S]*?)<\/code>/gi, (_m, inner: string) => '`' + inner + '`')
  s = s.replace(/<img[^>]*>/gi, '') // images are surfaced separately via image_path
  s = s.replace(/<br\s*\/?>/gi, '\n')
  s = s.replace(/<li[^>]*>/gi, '\n- ')
  s = s.replace(/<\/(p|div|li|h\d|tr|blockquote)>/gi, '\n')
  s = s.replace(/<[^>]+>/g, '')
  s = decodeEntities(s)
  return s.replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim()
}

/** Pull Graph hostedContents image URLs out of a message body. */
export function imageUrls(html: string | undefined): string[] {
  const out: string[] = []
  for (const m of (html ?? '').matchAll(/<img[^>]+src="([^"]+)"/gi)) out.push(decodeEntities(m[1]))
  return out
}

/** Markdown-ish → Teams HTML. Handles fences, inline code, bold, italics, links, newlines. */
export function markdownToHtml(md: string): string {
  const parts = md.split(/```[^\n]*\n?/)
  return parts
    .map((part, i) => {
      if (i % 2 === 1) return `<pre><code>${escapeHtml(part.replace(/\n$/, ''))}</code></pre>`
      let s = escapeHtml(part)
      s = s.replace(/`([^`\n]+)`/g, '<code>$1</code>')
      s = s.replace(/\*\*([^*\n]+)\*\*/g, '<b>$1</b>')
      s = s.replace(/(^|[^*])\*([^*\n]+)\*/g, '$1<i>$2</i>')
      s = s.replace(/\[([^\]\n]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2">$1</a>')
      return s.replace(/\n/g, '<br>')
    })
    .join('')
}

/** Split long text, preferring paragraph then line then space boundaries, never inside a fence if avoidable. */
export function chunk(text: string, limit: number): string[] {
  if (text.length <= limit) return [text]
  const out: string[] = []
  let rest = text
  while (rest.length > limit) {
    const para = rest.lastIndexOf('\n\n', limit)
    const line = rest.lastIndexOf('\n', limit)
    const space = rest.lastIndexOf(' ', limit)
    const cut = para > limit / 2 ? para : line > limit / 2 ? line : space > 0 ? space : limit
    let head = rest.slice(0, cut)
    rest = rest.slice(cut).replace(/^\n+/, '')
    // Keep code fences balanced across chunks.
    if ((head.match(/```/g)?.length ?? 0) % 2 === 1) {
      head += '\n```'
      rest = '```\n' + rest
    }
    out.push(head)
  }
  if (rest) out.push(rest)
  return out
}

/** Meta values land inside a <channel ...> tag attribute; strip delimiter chars. */
export function safeAttr(s: string | undefined): string | undefined {
  return s?.replace(/[<>"\[\]\r\n;]/g, '_')
}
