# Changes, 14 Nov 2026 (verification hardening)

Four additions to the kit, all run against the demo. Then what designc's `docs/ui-contract.md` and the Factory's `docs/ui-contract-verify.md` need to pick up from them.

## What changed in the kit

| Addition | Files | Proven by |
| --- | --- | --- |
| Per-placement screenshots | `preview/vitest-ui.tsx` (`checkPlacements`), `vitest.config.ts` (`resolveScreenshotPath`), `examples/previews/bordereaux/placements/` (30 files: 6 placements × 5 states) | Sabotage: wrong tone is caught in `empty` and `ready`; a dropped `data-ui-id` is an error |
| Holdout check | `preview/vitest-ui.tsx` (`holdoutTests`, `holdoutMatches`, `holdoutProblem`), `examples/holdout/bordereaux.json`, `examples/ui-tests/bordereaux.holdout.test.tsx`, project `ui-holdout` | Sabotage: a page hard-coded to the visible sample passes ARIA, page pixels and placements, and fails the holdout |
| Sabotage tests | `examples/sabotage/`, project `ui-sabotage` | 8 tests, including two controls on the real page |
| Claude Code guard | `.claude/hooks/ui-contract-guard.mjs`, its test table, `.claude/settings.ui-contract.example.json` | 46 tests: 31 attacks blocked, 14 kinds of normal work allowed, 1 bad-input case |

Also: `capture` is split into `checkAria`, `checkPixels` and `checkPlacements` (exported, so sabotage tests can call one at a time); `useWorker()` shares the MSW setup; the `ui-screen-spec` skill renders one named screen (`-u <screen>.preview`) and states what is frozen after approval; `.gitignore` covers `.vitest/` (failure diffs).

Runs on Vitest 5.1.0, Chromium, Linux: preview 5, page 5, holdout 5, sabotage 8, guard 46, all passing. The five approved page pictures are byte-identical to before.

## For the Factory's `ui-contract-verify.md`

- **Tooling.** Placement screenshots are named `ui__<screen>__<state>__<placement>` and land in `ui-contract/previews/<screen>/placements/<state>__<placement>-<browser>-<platform>.png`. Placement ids must match `[a-z0-9-]+`.
- **Preview run.** `ui_preview_rendered.files` already hashes everything under `previews/<screen>/`, so the placement files are covered once the copy is recursive. Check that it is.
- **Drift.** `ui-contract/previews/**` already includes `placements/`. No rule change.
- **Page tests.** A third failure kind: `ui_check_failed {screen, state, placement, kind: placement-pixels}`. A missing placement element is `kind: placement-missing`, which overlaps `UiGuard` `ContractMissing` on purpose (one static, one at run time).
- **Section 6, UI mutation.** The survivor from the demo is now killed by default. The section stands for generated mutants; its "fix" line (screenshot each placement) is done.
- **New check, after page tests: holdout.** The holdout sample stays in the registry (`ui/holdout/<screen>.json`) and is never written into a worktree. The Factory writes it into a scratch copy for the run only, runs `FACTORY_UI_HOLDOUT_CMD` (default `npx vitest run --project ui-holdout --reporter=json`), and records `holdout_failed {screen, state}` with no trees. `could_not_run` is exit 3 and never a pass. The agent's feedback is the screen and state only. Cap reports per holdout, then a person looks.
- **Sabotage table.** Add: wrong token on one placement (placement pixels), page hard-coded to the sample (holdout), `..` path to a preview (write scope on the resolved path), update command on a second line (command parser).
- **Policy.** The hook's test table is a ready list of rows for `RoleAllowListPolicy`. One difference: the hook lets an agent render previews for a screen that is not approved yet, because at work the same session does the spec stage. In the Factory the preview run is not an agent run, so every build role stays denied.

## For designc's `ui-contract.md`

- **Pieces.** A new row: holdout sample, `ui/holdout/<screen>.json`, one value per data key, written by a person. No stage reads it (`READ` deny for every stage, like `ui/pack/` is write-denied). It is in the handover by hash only.
- **Checks.** A spec clause: every key in a holdout exists in the spec's `data`, and the holdout differs from the visible sample. A holdout is optional per screen; a screen without one is listed (coverage, not a failure).
- **Feeding System 3.** A new `caught_by` stage, `holdout`. A holdout failure means the visible checks passed without the behaviour being right, so count it on its own. `ui-visual` gains the placement kind.
- **Preview and approval.** People approve the page pictures. Placement files are in `ui_preview_approved.files` because they are in the folder, but nobody is asked to look at 30 crops.

## Not done

- The holdout compares ARIA trees only. A page that hard-codes a colour or width for the visible sample's values would pass. Holdout pixels would need the holdout preview rendered and compared in the same run; possible, not built.
- One viewport, as before.
- The hook matches shell commands by pattern. Real isolation is the Factory's job.
