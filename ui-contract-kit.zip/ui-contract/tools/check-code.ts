#!/usr/bin/env -S npx tsx
/**
 * Code ↔ spec conformance — the second CI gate.
 *
 * The spec is what a human approved. This checks the generated page actually follows it:
 *   - every placement id appears as data-ui-id on the right component
 *   - no data-ui-id in the code that the spec doesn't know about
 *   - components come only from the catalogue's import module(s)
 *   - no inline styles or raw px / hex values (tokens only)
 *
 * It is a static, regex-level check: cheap, fast, catches drift. The visual gate
 * (Playwright screenshots, see README) catches what this can't.
 *
 * Usage: npx tsx tools/check-code.ts --root ui-contract <spec.json> <Page.tsx>
 */
import { readFileSync, readdirSync, existsSync } from "node:fs";
import { join, resolve } from "node:path";

const args = process.argv.slice(2);
const rootIdx = args.indexOf("--root");
const root = resolve(rootIdx >= 0 ? args[rootIdx + 1] : "ui-contract");
const [specPath, codePath] = args.filter((a, i) => !a.startsWith("--") && args[i - 1] !== "--root");
if (!specPath || !codePath) { console.error("usage: check-code.ts --root <dir> <spec.json> <Page.tsx>"); process.exit(2); }

const spec = JSON.parse(readFileSync(specPath, "utf8"));
const code = readFileSync(codePath, "utf8");
const manifestDir = join(root, "manifests");
const manifests = existsSync(manifestDir)
  ? readdirSync(manifestDir).filter((f) => f.endsWith(".json")).map((f) => JSON.parse(readFileSync(join(manifestDir, f), "utf8")))
  : [];
const allowedModules = new Set(manifests.map((m) => m.import));
const catalogued = new Set(manifests.map((m) => m.name));

const errors: string[] = [];

// 1. every placement is in the code, on the right component
const expected = new Map<string, string>();
for (const placements of Object.values<any[]>(spec.slots ?? {}))
  for (const p of placements) if (p.id) expected.set(p.id, p.component);

const found = new Map<string, string>();
// owning tag = nearest "<Component" before the attribute (convention: data-ui-id comes first)
for (const m of code.matchAll(/data-ui-id=\{?["']([\w-]+)["']\}?/g)) {
  const before = code.slice(0, m.index);
  const tags = [...before.matchAll(/<([A-Za-z][A-Za-z0-9.]*)\b/g)];
  const tag = tags.length ? tags[tags.length - 1][1] : "?";
  if (found.has(m[1])) errors.push(`duplicate data-ui-id '${m[1]}'`);
  found.set(m[1], tag);
}

for (const [id, comp] of expected) {
  if (!found.has(id)) errors.push(`missing: spec placement '${id}' (${comp}) has no element with data-ui-id="${id}"`);
  else if (found.get(id) !== comp) errors.push(`wrong component: '${id}' should be <${comp}>, code has <${found.get(id)}>`);
}
for (const [id, comp] of found) if (!expected.has(id)) errors.push(`unspecified: <${comp} data-ui-id="${id}"> is not in the spec`);

// 2. imports: JSX components must come from the catalogue
const importRe = /import\s+(?:type\s+)?\{([^}]+)\}\s+from\s+["']([^"']+)["']/g;
const importedFrom = new Map<string, string>();
for (const m of code.matchAll(importRe))
  for (const name of m[1].split(",").map((s) => s.trim().split(/\s+as\s+/).pop()!).filter(Boolean)) importedFrom.set(name, m[2]);

const usedTags = new Set([...code.matchAll(/<([A-Z][A-Za-z0-9]*)\b/g)].map((m) => m[1]));
for (const tag of usedTags) {
  const mod = importedFrom.get(tag);
  if (catalogued.has(tag) && mod && !allowedModules.has(mod)) errors.push(`import: ${tag} imported from '${mod}', expected ${[...allowedModules].join(" | ")}`);
  if (!catalogued.has(tag) && mod && allowedModules.has(mod)) errors.push(`uncatalogued: <${tag}> comes from the UI library but has no approved manifest`);
}
// raw HTML layout elements are allowed only as layout glue, not as styled UI
const rawEls = [...code.matchAll(/<(button|table|input|select|h[1-6])\b/g)].map((m) => m[1]);
if (rawEls.length) errors.push(`raw elements: <${[...new Set(rawEls)].join(">, <")}> — use the library component`);

// 3. no inline styling or raw values
if (/style=\{\{/.test(code)) errors.push("inline style={{...}} found — use tokens / library props");
const raw = [...code.matchAll(/["'`](\d+(?:\.\d+)?px|#[0-9a-fA-F]{3,8}|rgba?\([^)]*\))["'`]/g)].map((m) => m[1]);
if (raw.length) errors.push(`raw design values: ${[...new Set(raw)].join(", ")} — use tokens`);

for (const e of errors) console.log(`✗ ${e}`);
console.log(`\n${expected.size} placements in spec, ${found.size} in code — ${errors.length} errors`);
process.exit(errors.length ? 1 : 0);
