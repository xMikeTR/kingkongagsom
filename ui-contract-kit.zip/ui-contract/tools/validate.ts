#!/usr/bin/env -S npx tsx
/**
 * UI contract validator — the CI gate.
 *
 * Checks, in order:
 *   1. tokens.json, every manifest and every template against their JSON Schemas
 *   2. each screen spec against its schema, then against the catalogue:
 *      template, slot paths, categories, cardinality, props, tokens, data bindings, shapes
 *
 * Usage:
 *   npx tsx tools/validate.ts --root ui-contract [specs...]   # no specs = every file in <root>/specs
 *   flags: --allow-proposed   accept 'proposed' components/templates (bootstrap round-trip only)
 *          --require-approved fail if a spec is still 'draft' (use on main / release branches)
 *          --json             machine-readable output for agents
 *
 * Exit code 1 on any error. Warnings never fail the build.
 */
import Ajv2020 from "ajv/dist/2020";
import { readFileSync, readdirSync, existsSync } from "node:fs";
import { join, resolve, basename, dirname } from "node:path";
import { fileURLToPath } from "node:url";

type Issue = { level: "error" | "warning"; file: string; path: string; message: string; fix?: string };
type Json = Record<string, any>;

const args = process.argv.slice(2);
const flag = (f: string) => args.includes(f);
const rootIdx = args.indexOf("--root");
const root = resolve(rootIdx >= 0 ? args[rootIdx + 1] : "ui-contract");
const specArgs = args.filter((a, i) => !a.startsWith("--") && args[i - 1] !== "--root");
const allowProposed = flag("--allow-proposed");
const requireApproved = flag("--require-approved");

const here = dirname(fileURLToPath(import.meta.url));
const schemaDir = existsSync(join(root, "schemas")) ? join(root, "schemas") : join(here, "..", "schemas");

const issues: Issue[] = [];
const err = (file: string, path: string, message: string, fix?: string) => issues.push({ level: "error", file, path, message, fix });
const warn = (file: string, path: string, message: string, fix?: string) => issues.push({ level: "warning", file, path, message, fix });

const readJson = (p: string): Json => {
  try { return JSON.parse(readFileSync(p, "utf8")); }
  catch (e: any) { err(p, "", `Cannot parse JSON: ${e.message}`); return {}; }
};
const listJson = (dir: string) => (existsSync(dir) ? readdirSync(dir).filter((f) => f.endsWith(".json")).map((f) => join(dir, f)) : []);

// ---------- schemas ----------
const ajv = new Ajv2020({ allErrors: true, strict: false });
for (const f of ["component-manifest", "template", "screen-spec"]) ajv.addSchema(readJson(join(schemaDir, `${f}.schema.json`)));
const schemaCheck = (id: string, file: string, doc: Json) => {
  const validate = ajv.getSchema(`${id}.schema.json`)!;
  if (!validate(doc)) for (const e of validate.errors ?? []) err(file, e.instancePath || "/", `schema: ${e.message}${e.params ? " " + JSON.stringify(e.params) : ""}`);
};

// ---------- load catalogue ----------
const tokensPath = join(root, "tokens.json");
const tokens: Record<string, string[]> = existsSync(tokensPath) ? readJson(tokensPath) : {};
if (!existsSync(tokensPath)) warn(tokensPath, "", "No tokens.json — token props cannot be checked");

const manifests = new Map<string, { file: string; m: Json }>();
for (const file of listJson(join(root, "manifests"))) {
  const m = readJson(file);
  schemaCheck("component-manifest", file, m);
  if (manifests.has(m.name)) err(file, "/name", `Duplicate component '${m.name}' (also in ${manifests.get(m.name)!.file})`);
  if (basename(file, ".json") !== m.name) warn(file, "/name", `File name should match component name '${m.name}'`);
  for (const [p, def] of Object.entries<Json>(m.props ?? {}))
    if (def.type === "token" && !tokens[def.token]) err(file, `/props/${p}`, `Unknown token group '${def.token}'`, `Add it to tokens.json or use one of: ${Object.keys(tokens).filter((k) => !k.startsWith("$")).join(", ")}`);
  manifests.set(m.name, { file, m });
}

const templates = new Map<string, { file: string; t: Json }>();
for (const file of listJson(join(root, "templates"))) {
  const t = readJson(file);
  schemaCheck("template", file, t);
  templates.set(t.name, { file, t });
}

// ---------- spec checks ----------
type Slot = { accepts: string[]; min?: number; max?: number; subslots?: Record<string, Slot> };
const flattenSlots = (slots: Record<string, Slot>, prefix = ""): Map<string, Slot> => {
  const out = new Map<string, Slot>();
  for (const [name, s] of Object.entries(slots ?? {})) {
    const path = prefix ? `${prefix}.${name}` : name;
    out.set(path, s);
    for (const [k, v] of flattenSlots(s.subslots ?? {}, path)) out.set(k, v);
  }
  return out;
};
const okStatus = (s: string) => s === "approved" || (allowProposed && s === "proposed");

function checkSpec(file: string) {
  const spec = readJson(file);
  schemaCheck("screen-spec", file, spec);
  if (requireApproved && spec.status !== "approved") err(file, "/status", "Spec is not approved", "A human reviews the spec against the intent, then sets status: approved and approvedBy");

  const tpl = templates.get(spec.template);
  if (!tpl) { err(file, "/template", `Unknown template '${spec.template}'`, `Use one of: ${[...templates.keys()].join(", ")}`); return; }
  if (!okStatus(tpl.t.status)) err(file, "/template", `Template '${spec.template}' is ${tpl.t.status}, not approved`);

  const slots = flattenSlots(tpl.t.slots);
  const data: Json = spec.data ?? {};
  const usedData = new Set<string>();
  const ids = new Set<string>();

  for (const [path, placements] of Object.entries<Json[]>(spec.slots ?? {})) {
    const slot = slots.get(path);
    if (!slot) { err(file, `/slots/${path}`, `Template '${spec.template}' has no slot '${path}'`, `Slots are: ${[...slots.keys()].join(", ")}`); continue; }
    if (slot.max !== undefined && placements.length > slot.max) err(file, `/slots/${path}`, `Slot '${path}' takes at most ${slot.max}, got ${placements.length}`);

    placements.forEach((pl, i) => {
      const at = `/slots/${path}/${i}`;
      if (pl.id) { if (ids.has(pl.id)) err(file, `${at}/id`, `Duplicate id '${pl.id}'`); ids.add(pl.id); }
      else warn(file, at, "No id — the visual gate cannot map this element back to the spec");

      const entry = manifests.get(pl.component);
      if (!entry) { err(file, `${at}/component`, `'${pl.component}' is not in the catalogue`, "Use a catalogued component, or add a manifest (ui-contract-extract skill) and get it approved"); return; }
      const m = entry.m;
      if (!okStatus(m.status)) err(file, `${at}/component`, `'${m.name}' is ${m.status}, not approved`);
      if (!slot.accepts.includes(m.category)) err(file, `${at}/component`, `'${m.name}' is a ${m.category}; slot '${path}' accepts ${slot.accepts.join(" | ")}`);

      // props
      const props: Json = pl.props ?? {};
      for (const [p, def] of Object.entries<Json>(m.props ?? {}))
        if (def.required && !(p in props)) err(file, `${at}/props`, `'${m.name}' requires prop '${p}'`);
      for (const [p, v] of Object.entries(props)) {
        const def = m.props?.[p];
        if (!def) {
          const hint = m.data?.[p] ? `'${p}' is a data prop — put it under bind` : `Allowed props: ${Object.keys(m.props ?? {}).join(", ") || "none"}`;
          err(file, `${at}/props/${p}`, `'${m.name}' has no prop '${p}'`, hint); continue;
        }
        if (def.type === "enum" && !def.values.includes(v)) err(file, `${at}/props/${p}`, `'${v}' is not one of ${def.values.join(" | ")}`);
        if (def.type === "token" && tokens[def.token] && !tokens[def.token].includes(String(v))) err(file, `${at}/props/${p}`, `'${v}' is not a ${def.token} token`, `Use one of: ${tokens[def.token].join(", ")}`);
        if (["string", "action"].includes(def.type) && typeof v !== "string") err(file, `${at}/props/${p}`, `Expected a string`);
        if (def.type === "number" && typeof v !== "number") err(file, `${at}/props/${p}`, `Expected a number`);
        if (def.type === "boolean" && typeof v !== "boolean") err(file, `${at}/props/${p}`, `Expected a boolean`);
      }

      // data bindings
      const bind: Json = pl.bind ?? {};
      for (const [dp, def] of Object.entries<Json>(m.data ?? {}))
        if (def.required && !(dp in bind)) err(file, `${at}/bind`, `'${m.name}' needs data '${dp}' (${def.shape})`);
      for (const [dp, key] of Object.entries<string>(bind)) {
        const def = m.data?.[dp];
        if (!def) { err(file, `${at}/bind/${dp}`, `'${m.name}' has no data prop '${dp}'`); continue; }
        const d = data[key];
        if (!d) { err(file, `${at}/bind/${dp}`, `No data key '${key}'`, `Declare it under data with a shape and source`); continue; }
        usedData.add(key);
        if (d.shape !== def.shape) err(file, `${at}/bind/${dp}`, `'${key}' is ${d.shape}; '${m.name}.${dp}' expects ${def.shape}`);
      }
    });
  }

  for (const [path, slot] of slots) {
    const n = spec.slots?.[path]?.length ?? 0;
    // only enforce min on subslots when the parent slot is filled
    const parent = path.includes(".") ? path.slice(0, path.lastIndexOf(".")) : null;
    if ((slot.min ?? 0) > n && (!parent || (spec.slots?.[parent]?.length ?? 0) > 0))
      err(file, `/slots/${path}`, `Slot '${path}' needs at least ${slot.min}, got ${n}`);
  }
  for (const key of Object.keys(data)) if (!usedData.has(key)) warn(file, `/data/${key}`, `Data '${key}' is declared but never shown`);
  if (basename(file, ".json") !== spec.screen) warn(file, "/screen", `File name should be the screen name '${spec.screen}.json'`);
  checkStates(file, spec);
}

// ---------- state graph: the spine shared with acceptance, scenarios and QA bugs ----------
const REQUIRED_STATES = ["ready", "loading", "empty", "error"];
// designc's acceptance locator roles (renderer/core.js LOCATOR_ROLES), so spec locators join acceptance and parity
const LOCATOR_ROLES = ["alert", "button", "cell", "checkbox", "combobox", "dialog", "form", "heading", "img", "label", "link", "list", "listitem", "main", "navigation", "option", "radio", "region", "row", "searchbox", "status", "switch", "tab", "table", "tabpanel", "textbox"];
function checkStates(file: string, spec: Json) {
  const states: Json = spec.states ?? {};
  const names = Object.keys(states);
  const initial = names.filter((n) => states[n].initial);
  if (initial.length !== 1) err(file, "/states", `Exactly one state is initial, found ${initial.length}${initial.length ? `: ${initial.join(", ")}` : ""}`);
  const missing = REQUIRED_STATES.filter((s) => !(s in states));
  if (missing.length) warn(file, "/states", `No state named ${missing.join(", ")}`, "Acceptance asks for a case per required state. Add it, or name your main state 'ready'");
  for (const [n, st] of Object.entries<Json>(states))
    for (const [where, keys] of [["data", Object.keys(st.data ?? {})], ["pending", st.pending ?? []], ["failed", st.failed ?? []]] as const)
      for (const key of keys) if (!(key in (spec.data ?? {}))) err(file, `/states/${n}/${where}/${key}`, `No data key '${key}'`);

  const edges = new Map<string, string[]>();
  (spec.transitions ?? []).forEach((t: Json, i: number) => {
    for (const a of ["click", "fill", "select"]) if (t.on?.[a] && !LOCATOR_ROLES.includes(t.on[a].role)) err(file, `/transitions/${i}/on/${a}`, `Locator role '${t.on[a].role}' is not an acceptance role`);
    for (const end of ["from", "to"]) if (!(t[end] in states)) err(file, `/transitions/${i}/${end}`, `No state '${t[end]}'`, `States are: ${names.join(", ")}`);
    edges.set(t.from, [...(edges.get(t.from) ?? []), t.to]);
  });
  if (initial.length === 1) {
    const seen = new Set([initial[0]]); const todo = [initial[0]];
    while (todo.length) for (const n of edges.get(todo.pop()!) ?? []) if (!seen.has(n)) { seen.add(n); todo.push(n); }
    for (const n of names) if (!seen.has(n)) warn(file, `/states/${n}`, `State '${n}' cannot be reached from '${initial[0]}'`, "No scenario can record it. Add a transition");
  }

  const locs = new Map<string, string>();
  for (const [path, pls] of Object.entries<Json[]>(spec.slots ?? {}))
    for (const pl of pls) if (pl.locator) {
      if (!LOCATOR_ROLES.includes(pl.locator.role)) err(file, `/slots/${path}`, `Locator role '${pl.locator.role}' is not an acceptance role`, `Use one of: ${LOCATOR_ROLES.join(", ")}`);
      const k = `${pl.locator.role}|${pl.locator.name}`;
      if (locs.has(k)) warn(file, `/slots/${path}`, `Locator ${pl.locator.role} '${pl.locator.name}' is used twice (also ${locs.get(k)})`, "Parity and acceptance cannot tell them apart");
      locs.set(k, pl.id ?? path);
    }
}

const specFiles = specArgs.length ? specArgs.map((s) => resolve(s)) : listJson(join(root, "specs"));
specFiles.forEach(checkSpec);

// ---------- report ----------
const errors = issues.filter((i) => i.level === "error");
if (flag("--json")) {
  console.log(JSON.stringify({ ok: errors.length === 0, issues }, null, 2));
} else {
  const rel = (f: string) => f.replace(process.cwd() + "/", "");
  for (const i of issues) console.log(`${i.level === "error" ? "✗" : "!"} ${rel(i.file)} ${i.path}\n    ${i.message}${i.fix ? `\n    → ${i.fix}` : ""}`);
  console.log(`\n${manifests.size} components, ${templates.size} templates, ${specFiles.length} specs — ${errors.length} errors, ${issues.length - errors.length} warnings`);
}
process.exit(errors.length ? 1 : 0);
