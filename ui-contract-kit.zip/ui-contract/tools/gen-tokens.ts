#!/usr/bin/env -S npx tsx
/** tokens.json → closed TS unions. Agents get compile errors for values outside the curated set. */
import { readFileSync, writeFileSync } from "node:fs";
const [src = "ui-contract/tokens.json", out = "src/ui-contract/tokens.ts"] = process.argv.slice(2);
const tokens: Record<string, string[]> = JSON.parse(readFileSync(src, "utf8"));
const pascal = (s: string) => s[0].toUpperCase() + s.slice(1);
const body = Object.entries(tokens)
  .filter(([k]) => !k.startsWith("$"))
  .map(([k, vs]) => `export const ${k} = [${vs.map((v) => JSON.stringify(v)).join(", ")}] as const;\nexport type ${pascal(k)} = (typeof ${k})[number];`)
  .join("\n\n");
writeFileSync(out, `// GENERATED from ${src} — do not edit. Change tokens.json and get it approved.\n\n${body}\n`);
console.log(`wrote ${out}`);
