import spec from "../specs/bordereaux.json";
import { BordereauxList } from "../pages/BordereauxList";
import { pageTests, ariaFiles } from "../../preview/vitest-ui";

// The approved trees, read as text at build time. Never written by this test.
const approvedAria = ariaFiles(import.meta.glob("../previews/**/*.aria.yml", { query: "?raw", import: "default", eager: true }) as Record<string, string>);

pageTests(spec as any, BordereauxList, { previewsRel: "../previews", approvedAria, props: { initialSelectedId: "B-2" } });
