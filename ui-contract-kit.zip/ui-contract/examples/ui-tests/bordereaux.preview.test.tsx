import spec from "../specs/bordereaux.json";
import * as UI from "../demo/mock-ui";
import { previewTests } from "../../preview/vitest-ui";

const manifests = Object.values(import.meta.glob("../manifests/*.json", { eager: true, import: "default" })) as any[];
const components = Object.fromEntries(manifests.map((m) => [m.name, (UI as any)[m.name]]).filter(([, c]) => c));

previewTests(spec as any, { components, layouts: { "list-detail": UI.ListDetailLayout }, manifests, previewsRel: "../previews" });
