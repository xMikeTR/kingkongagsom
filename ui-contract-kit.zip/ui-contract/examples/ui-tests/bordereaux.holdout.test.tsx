import spec from "../specs/bordereaux.json";
import * as UI from "../demo/mock-ui";
import { BordereauxList } from "../pages/BordereauxList";
import { holdoutTests, type Holdout } from "../../preview/vitest-ui";

const manifests = Object.values(import.meta.glob("../manifests/*.json", { eager: true, import: "default" })) as any[];
const components = Object.fromEntries(manifests.map((m) => [m.name, (UI as any)[m.name]]).filter(([, c]) => c));
// A missing file gives no holdout, and holdoutTests then fails every state as could_not_run.
const holdout = (Object.values(import.meta.glob("../holdout/bordereaux.json", { eager: true, import: "default" }))[0] ?? {}) as Holdout;

holdoutTests(spec as any, BordereauxList, { components, layouts: { "list-detail": UI.ListDetailLayout }, manifests, holdout, props: { initialSelectedId: "B-2" } });
