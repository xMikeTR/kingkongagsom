/**
 * Planted breaks. Each test builds a page that is wrong in one way and expects the named check to fail.
 * If one of these goes green-on-broken, a check has gone soft: fix the check, not this file.
 *
 *   npx vitest run --project ui-sabotage     (never with -u)
 */
import React from "react";
import { describe, test, expect } from "vitest";
import { render } from "vitest-browser-react";
import spec from "../specs/bordereaux.json";
import * as UI from "../demo/mock-ui";
import { BordereauxList } from "../pages/BordereauxList";
import { WrongTone, HardCodedSample, DroppedId } from "./pages";
import { ariaFiles, handlersFor, useWorker, checkAria, checkPixels, checkPlacements, holdoutMatches, holdoutProblem, type Holdout } from "../../preview/vitest-ui";

const s = spec as any;
const PREVIEWS = "../previews";
const approvedAria = ariaFiles(import.meta.glob("../previews/**/*.aria.yml", { query: "?raw", import: "default", eager: true }) as Record<string, string>);
const manifests = Object.values(import.meta.glob("../manifests/*.json", { eager: true, import: "default" })) as any[];
const components = Object.fromEntries(manifests.map((m) => [m.name, (UI as any)[m.name]]).filter(([, c]) => c));
const holdout = (Object.values(import.meta.glob("../holdout/bordereaux.json", { eager: true, import: "default" }))[0] ?? {}) as Holdout;
const hOpts = { components, layouts: { "list-detail": UI.ListDetailLayout }, manifests, holdout, props: { initialSelectedId: "B-2" } };
const props = { initialSelectedId: "B-2" };

const caught = async (check: () => Promise<unknown>) => { try { await check(); return false; } catch { return true; } };

describe("bordereaux sabotage", () => {
  const worker = useWorker();
  const show = async (Page: React.ComponentType<any>, state: string) => {
    worker.use(...handlersFor(s, state));
    render(<div data-testid="ui-root"><Page {...props} /></div>);
  };

  test("control: the real page passes every check in every state", async () => {
    for (const state of Object.keys(s.states)) {
      worker.use(...handlersFor(s, state));
      const view = await render(<div data-testid="ui-root"><BordereauxList {...props} /></div>);
      await checkAria(s, state, PREVIEWS, approvedAria);
      await checkPixels(s, state);
      await checkPlacements(s, state);
      await view.unmount();
      worker.resetHandlers();
    }
  });

  test("wrong tone on the metric, empty state: caught by the placement screenshot", async () => {
    await show(WrongTone, "empty");
    await checkAria(s, "empty", PREVIEWS, approvedAria);          // same roles and names, so the tree still matches
    expect(await caught(() => checkPlacements(s, "empty"))).toBe(true);
  });

  test("wrong tone on the metric, ready state: caught", async () => {
    await show(WrongTone, "ready");
    await checkAria(s, "ready", PREVIEWS, approvedAria);
    expect(await caught(() => checkPlacements(s, "ready"))).toBe(true);
  });

  test("dropped data-ui-id: caught as a missing placement, not skipped", async () => {
    await show(DroppedId, "ready");
    await checkAria(s, "ready", PREVIEWS, approvedAria);
    expect(await caught(() => checkPlacements(s, "ready"))).toBe(true);
  });

  test("page hard-coded to the visible sample: passes the visible checks", async () => {
    await show(HardCodedSample, "ready");
    await checkAria(s, "ready", PREVIEWS, approvedAria);
    await checkPixels(s, "ready");
    await checkPlacements(s, "ready");
  });

  test("page hard-coded to the visible sample: caught by the holdout", async () => {
    expect(holdoutProblem(s, holdout)).toBe(null);
    expect(await holdoutMatches(s, "ready", HardCodedSample, hOpts, worker)).toBe(false);
  });

  test("control: the real page matches the holdout", async () => {
    expect(await holdoutMatches(s, "ready", BordereauxList, hOpts, worker)).toBe(true);
  });

  test("a holdout that cannot run is never a pass", () => {
    expect(holdoutProblem(s, {})).toMatch(/^could_not_run/);
    expect(holdoutProblem(s, { nope: 1 })).toMatch(/^could_not_run/);
    expect(holdoutProblem(s, { totalPremium: s.data.totalPremium.sample })).toMatch(/^could_not_run/);
  });
});
