/**
 * Broken copies of examples/pages/BordereauxList.tsx. Each one is a way to look done without being done.
 * The sabotage tests expect every one of them to be caught.
 */
import { useState } from "react";
import { PageHeader, Button, MetricCard, FilterBar, DataTable, DetailPanel } from "@your-org/ui";
import { ListDetailLayout } from "@your-org/ui/layouts";
import { useBordereaux, useBordereauxSummary, useBordereau } from "../data/bordereaux";
import spec from "../specs/bordereaux.json";

const LOAD_ERROR = "Bordereaux could not be loaded";
type Variant = { tone?: string; hardCodeSample?: boolean; dropId?: boolean };

function make({ tone = "neutral", hardCodeSample = false, dropId = false }: Variant) {
  return function Sabotaged({ initialSelectedId }: { initialSelectedId?: string }) {
    const [filters, setFilters] = useState<Record<string, string>>({});
    const [selectedId, setSelectedId] = useState<string | undefined>(initialSelectedId);
    const bordereaux = useBordereaux(filters);
    const summary = useBordereauxSummary(filters);
    const selected = useBordereau(selectedId);
    const err = (r: { error: string | null }) => (r.error ? LOAD_ERROR : undefined);
    // The cheat: whenever the API answers with rows, show the rows from the spec's visible sample instead.
    const rows = hardCodeSample && bordereaux.data?.length ? (spec.data.bordereaux.sample as Record<string, unknown>[]) : bordereaux.data;
    const total = hardCodeSample && summary.data?.amount ? spec.data.totalPremium.sample : summary.data;
    const record = hardCodeSample && selected.data ? (spec.data.selected.sample as Record<string, string>) : selected.data;

    return (
      <ListDetailLayout
        header={
          <PageHeader data-ui-id="hdr" title="Bordereaux"
            actions={<Button data-ui-id={dropId ? undefined : "export"} label="Export" variant="secondary" onClick={() => {}} />} />
        }
        summary={<MetricCard data-ui-id="premium" label="Total premium" tone={tone} value={total} loading={summary.loading} error={err(summary)} />}
        filters={<FilterBar data-ui-id="filters" fields="cedant,period" onChange={setFilters} />}
        main={<DataTable data-ui-id="table" density="compact" rows={rows} loading={bordereaux.loading} error={err(bordereaux)} rowAction={setSelectedId} />}
        aside={<DetailPanel data-ui-id="detail" title="Bordereau" record={record} loading={selected.loading} error={err(selected)} />}
      />
    );
  };
}

/** The metric's tone changed. In `empty` the red "$0" is too small for the page-wide ratio. */
export const WrongTone = make({ tone: "danger" });
/** Renders the spec's visible sample whatever the API sends. */
export const HardCodedSample = make({ hardCodeSample: true });
/** A placement lost its data-ui-id. */
export const DroppedId = make({ dropId: true });
