---
name: ui-screen-spec
description: Build or change a UI screen spec-first against the UI contract. Use for any new screen, page, or layout change in the React app — write and validate the screen spec before writing any JSX.
---

# Spec-first screens

You never start with JSX. You place catalogued components into an approved template, the validator checks it, a human approves it, and only then do you write code.

## 1. Bottom-up: data first

From the ticket, list every piece of data the screen shows. For each one, record its `shape` (schema enum) and `source` (hook or endpoint). This is the spec's `data` section.

## 2. Components from data

For each data key, find the catalogued components (`ui-contract/manifests/`, approved only) whose `data` prop accepts that shape. Pick using `useWhen` / `avoidWhen`. Write a one-line `why` on each placement.

## 3. Template from components

Pick the approved template (`ui-contract/templates/`) whose slots accept the categories you need. Read its `useWhen` / `avoidWhen`. Don't force data into a template that doesn't fit. If none fits, **stop and report** — a new template is a team decision.

## 4. Write and validate the spec

Write `ui-contract/specs/<screen>.json` (lower-case screen name, the same `screen:` parity and QA bugs use; `component` is the React name) with `status: "draft"`, an `intent` that restates the ask in plain words, the ticket key, an `id` on every placement, and a `locator` (`{role, name}`) on every placement a user interacts with.

**State graph.** Add `states` and `transitions`. Include `ready`, `loading`, `empty` and `error` (and `forbidden` when the screen sits behind an authenticated relationship). Each transition is one action (`goto`, `click`, `fill`, `select`) or an `event` (data arrives, request fails); mark writes with `commits: true`. Per state, say which data is `pending`, which `failed`, and any `data` overrides. These state names are the ones acceptance criteria, scenarios and QA bugs must use.

`npx tsx ui-contract/tools/validate.ts --root ui-contract ui-contract/specs/<screen>.json`

Fix until it passes. Each error comes with a `→` hint. If the only fix is a component or template that doesn't exist, stop and report it; don't swap in something type-valid but wrong.

## 5. Preview, then hand off for approval

Give every data key a realistic `sample`: 3–8 rows, real-looking names and amounts taken from the ticket or existing fixtures. Generic samples hide layout problems.

Add `ui-contract/ui-tests/<screen>.preview.test.tsx` (copy the example: one `previewTests(spec, …)` call) and render **every state**, naming the screen so no other screen's previews are touched:
`npx vitest run --project ui-preview -u <screen>.preview`

If a state shows "not in registry", fix that first. Commit `ui-contract/previews/<screen>/` (a PNG and an `.aria.yml` per state, plus `placements/`, one PNG per placement per state, written by the same run). On the CI runner if the repo does that: baselines are platform-specific. In the PR, show the reviewer the screenshots (all states), the intent and a short table (slot → component → data → why). The **picture** is what gets approved. On approval, set `status: "approved"`, `approvedBy`, and `preview` to the screenshots folder. Don't write page code before that.

## 6. Generate code

- Use the template's layout component; one library component per placement, in spec order.
- Put `data-ui-id="<id>"` as the **first** attribute on each placed component.
- Import only from the manifest's `import` module. No inline `style`, no raw px or hex values, no raw `<button>`, `<table>`, `<input>`, `<h1>`…
- Handle every state listed in each component's manifest `states`.

From here the screen is approved, and these are frozen: its spec, its previews, `ui-contract/preview/` and anything in `ui-contract/holdout/` (which you never read). If a check fails, the page is wrong. If you believe the spec or preview is wrong, stop and say so; a person sets the spec back to draft.

Then add `ui-contract/ui-tests/<screen>.page.test.tsx` (one `pageTests(spec, Page, …)` call) and run:
`npx vitest run --project ui-page` (**never with `-u`**: a mismatch means the page is wrong, not the preview), and
`npx tsx ui-contract/tools/check-code.ts --root ui-contract ui-contract/specs/<screen>.json <path/to/Component.tsx>`

## Changing an existing screen

Edit the spec first, re-validate, get approval, then regenerate. A code change without a spec change will fail `check-code`. An approved spec is frozen: ask the person to set `status` back to `draft` before you edit it.
