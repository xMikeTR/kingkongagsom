---
name: ui-contract-extract
description: Write UI contract files (component manifests, page templates, round-trip specs) from real code. Use when bootstrapping the contract from an agreed screen, adding a manifest for a library component, or when the validator reports a component "is not in the catalogue".
---

# UI contract extraction

You turn existing, agreed UI into contract files in `ui-contract/`. You **describe** what exists; you never design. Everything you write has `status: "proposed"`. Only a human sets `approved`.

Schemas: `ui-contract/schemas/*.schema.json`. Examples: `ui-contract/examples/`. Read one example of each kind before writing.

## Mode A — Bootstrap from an agreed screen

Input: a path to a screen the team has agreed on (e.g. `src/pages/Claims/ClaimsList.tsx`).

1. **Read the screen and everything it renders**, down to library components. Note each library component, where it sits, and what data feeds it.
2. **Identify regions.** Group the screen into named regions by role (header, summary, filters, main, aside, footer…), not by DOM position. Nested regions (e.g. buttons inside the header) become subslots.
3. **Write a manifest per library component used** (Mode B for each). Skip ones that already exist; if an existing manifest disagrees with what you see, add a `notes` entry rather than editing it.
4. **Write the template** to `ui-contract/templates/<name>.json`:
   - name it after the archetype (`list-detail`, `dashboard`, `form-wizard`), not the screen
   - each slot's `accepts` = the categories you actually saw there, plus only obvious siblings (`table` → also `list`); justify extras in `notes`
   - `min`/`max` from what the screen does; if unsure, leave `max` open and say so in `notes`
   - `reference.screen` = the input path
5. **Write the round-trip spec** to `ui-contract/specs/<screen>.json` (lower-case screen name, as in parity): a spec that describes the existing screen exactly, with `intent` written from what the screen does. Draft its `states` and `transitions` from the conditions the screen renders under (designc's UI graph `when` gives them, when available); each distinct condition is often a state. Set `reference.spec` in the template to it.
6. **Prove it.** Run:
   `npx tsx ui-contract/tools/validate.ts --root ui-contract --allow-proposed ui-contract/specs/<screen>.json`
   Fix your **manifests/template** until it passes — never bend the spec away from the real screen. If it can't pass without lying, stop and report the conflict.
7. **Reference screenshot** (if Playwright is set up): capture the screen in its loaded state to `ui-contract/references/<template>.png`. Otherwise list it as a follow-up.
8. **Report** for the reviewer: files written, every judgement call (category choices, slot boundaries, guessed shapes), and every `notes` entry. Keep it short and scannable.

## Mode B — Manifest for one component

Input: a component name or source path.

- `props`: only props that exist in the component's TypeScript type. Map types:
  - string literal union → `enum` with `values`
  - union that matches a group in `ui-contract/tokens.json` → `token` with that group
  - callback (`() => void`, `(x) => …`) → `action`
  - `string` / `number` / `boolean` → same
  - anything that carries data to display → goes in `data`, not `props`
- `data`: pick the closest `shape` from the schema enum. If none fits, choose the nearest and say so in `notes`.
- `category`: one of the closed list. If two fit, pick by the role it plays on agreed screens and note the other.
- `states`: only states the component actually renders (look for loading/empty/error branches).
- `useWhen` / `avoidWhen`: from evidence — how and where it is used (`source.seenIn`). Don't write generic UX advice. `avoidWhen` should name the component to use instead when one exists.
- Omit props that are internal plumbing (className passthrough, refs, test ids) — the contract should be the narrow, intended surface.

## Rules

- Never set `status: "approved"`. Never edit an approved file; propose changes in `notes` or a new file.
- Never invent props, data, categories or tokens. If the code doesn't show it, it isn't in the manifest.
- Don't add a category or token group. If one is missing, report it as a decision for the team.
- Validate after every write. A file that fails its schema is not done.
