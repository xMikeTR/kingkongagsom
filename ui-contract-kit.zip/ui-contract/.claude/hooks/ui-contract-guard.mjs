#!/usr/bin/env node
/**
 * Claude Code PreToolUse hook for the UI contract. It stops the ways an agent can make the
 * visual gate pass without the page being right:
 *
 *   1. changing an approved screen's previews, or its spec
 *   2. re-rendering previews (vitest -u) for a screen that is already approved
 *   3. changing the test helper that holds the pixel threshold
 *   4. reading or changing the holdout samples
 *   5. changing this hook
 *
 * A screen is approved when ui-contract/specs/<screen>.json has "status": "approved".
 * Until then the agent may write the spec and render its previews: that is the spec stage.
 *
 * Exit 0 allows. Exit 2 blocks, and stderr goes back to the agent as the reason.
 * The hook reads the tool call as JSON on stdin: { tool_name, tool_input, cwd }.
 *
 * This is a guard, not a sandbox. A shell command built to dodge the patterns below can get
 * past it. The reviewer seeing the preview diff in the PR is still the real approval.
 */
import { readFileSync, existsSync, readdirSync } from "node:fs";
import { resolve, relative, sep } from "node:path";

const CONTRACT = "ui-contract";                       // folder of the kit inside the app repo
const HELPER = [`${CONTRACT}/preview/`];              // holds the pixel ratio and the comparisons
const SELF = [".claude/hooks/ui-contract-guard"];

function main() {
  let call;
  try { call = JSON.parse(readFileSync(0, "utf8")); }
  catch { console.error("ui-contract-guard: could not read the tool call, not blocking."); process.exit(1); }

  const root = process.env.CLAUDE_PROJECT_DIR || call.cwd || process.cwd();
  const cwd = call.cwd || root;
  const input = call.tool_input ?? {};
  const tool = call.tool_name ?? "";

  /** Path inside the repo with forward slashes, with any `..` already resolved. Null when outside. */
  const rel = (p) => {
    if (typeof p !== "string" || !p) return null;
    const r = relative(resolve(root), resolve(cwd, p));
    if (r.startsWith("..")) return null;
    return r.split(sep).join("/").replace(/\\/g, "/");
  };
  const approved = (screen) => {
    try { return JSON.parse(readFileSync(resolve(root, CONTRACT, "specs", `${screen}.json`), "utf8")).status === "approved"; }
    catch { return false; }
  };
  const approvedScreens = () => {
    const dir = resolve(root, CONTRACT, "specs");
    if (!existsSync(dir)) return [];
    return readdirSync(dir).filter((f) => f.endsWith(".json")).map((f) => f.slice(0, -5)).filter(approved);
  };
  const block = (why) => { console.error(`Blocked by ui-contract-guard: ${why}`); process.exit(2); };
  const lower = (s) => s.toLowerCase();

  // ---- file tools -------------------------------------------------------------------------
  const WRITES = ["Edit", "Write", "MultiEdit", "NotebookEdit"];
  const READS = ["Read", "Grep", "Glob"];
  const target = rel(input.file_path ?? input.notebook_path ?? input.path);

  if (target && (WRITES.includes(tool) || READS.includes(tool))) {
    const t = lower(target);
    if (t.startsWith(`${CONTRACT}/holdout/`) || t === `${CONTRACT}/holdout`)
      block("holdout samples are not for the agent that builds the page. Do not read or change them.");
  }
  if (target && WRITES.includes(tool)) {
    const t = lower(target);
    if (SELF.some((p) => t.startsWith(p))) block("this hook is changed by a person, not in an agent session.");
    if (HELPER.some((p) => t.startsWith(p)))
      block(`${CONTRACT}/preview/ holds the thresholds the visual gate uses. A person changes it, in its own PR.`);
    let m = new RegExp(`^${CONTRACT}/previews/([a-z0-9-]+)/`).exec(t);
    if (m) block(approved(m[1])
      ? `the previews of '${m[1]}' are approved. A page that differs is wrong; the preview is not. To change the screen, a person sets the spec back to draft first.`
      : `previews are written by the preview tests, never by hand. Run: npx vitest run --project ui-preview -u ${m[1]}.preview`);
    m = new RegExp(`^${CONTRACT}/specs/([a-z0-9-]+)\\.json$`).exec(t);
    if (m && approved(m[1]))
      block(`the spec of '${m[1]}' is approved. A change needs a new approval: ask the person to set "status" back to "draft", then edit, re-render and get it approved again.`);
  }

  // ---- shell ------------------------------------------------------------------------------
  if (tool === "Bash" || tool === "PowerShell") {
    const cmd = String(input.command ?? "");
    const c = lower(cmd).replace(/\\/g, "/");

    if (c.includes(`${CONTRACT}/holdout`) || /(^|[\s/"'=])holdout\/[a-z0-9-]+\.json/.test(c))
      block("holdout samples are not for the agent that builds the page. Do not read, list or change them.");

    const CHANGES = /(^|[\s;&|(])(rm|mv|cp|tee|truncate|del|rd|rmdir|sed\s+-i|remove-item|move-item|copy-item|set-content|add-content|out-file|new-item)\b|>/;
    for (const dir of [`${CONTRACT}/previews`, `${CONTRACT}/preview/`, ...SELF])
      if (c.includes(dir) && CHANGES.test(c)) block(`shell commands may not change ${dir}.`);
    if (/git\s+(checkout|restore|reset|stash|apply|am|cherry-pick|revert)\b/.test(c) && c.includes(`${CONTRACT}/previews`) && approvedScreens().length)
      block("approved previews are not rewritten from git in an agent session.");

    // Updating snapshots. `-u` rewrites every baseline in the run, so it must name its screens.
    const runsVitest = /\bvitest\b/.test(c);
    const updates = (runsVitest && /(^|\s)(-u|--update|-[a-z]*u[a-z]*)(\s|=|$)/.test(c)) || /\bui:preview\b/.test(c);
    if (updates) {
      if (runsVitest && !/--project[\s=]+["']?ui-preview\b/.test(c))
        block("snapshots are only updated in the ui-preview project. Page, holdout and sabotage tests never run with -u.");
      const screens = [...c.matchAll(/([a-z0-9-]+)\.preview\b/g)].map((x) => x[1]);
      if (!screens.length)
        block("an update must name the screen, so approved screens are not re-rendered: npx vitest run --project ui-preview -u <screen>.preview");
      const done = screens.filter(approved);
      if (done.length)
        block(`the previews of '${done.join("', '")}' are approved and are not re-rendered. To change the screen, a person sets the spec back to draft first.`);
    }
  }
  process.exit(0);
}
main();
