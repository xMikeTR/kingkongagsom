# UI contract

Agents produce consistent screens because they **fill slots in approved templates with catalogued components**. They don't design. Based on Gus's (Commerce Tools) generative-UI talk: the catalogue is the contract, and layout resolves bottom-up from data.

```
tokens.json        vocabulary   closed set of design values  → TS unions (gen-tokens)
manifests/*.json   parts        what each library component is, takes, and is for
templates/*.json   grammar      page archetypes: slots → accepted categories, cardinality
specs/<screen>.json sentence    one screen: template + placements + data bindings + its state graph
```

## The flow

```
ticket ─▶ spec (draft) ─▶ validate.ts ─▶ ui:preview ─▶ human approves PICTURES (PR) ─▶ code ─▶ check-code.ts ─▶ ui:page
           agent            CI gate 1     all states    + intent + spec table           agent     CI gate 2      page vs approved previews
```

What each gate proves:

| Gate | Proves | Doesn't prove |
|---|---|---|
| `validate.ts` | Spec only uses approved templates, components, props, tokens; data shapes fit | That it's the right screen for the ask |
| Preview + human review | The screen looks right for the intent, using real components and sample data | Real-data edge cases (long names, empty states): add samples for those |
| `check-code.ts` | Code implements exactly the approved spec, with no off-contract styling | Pixels |
| Visual gate | The built page, loaded with the spec's samples, matches the approved preview | — |

So CI doesn't check "what was asked". It checks that the code matches what a human approved, which is a small JSON file and fast to review.

## Bootstrap from your agreed screen

1. Copy this folder into the repo as `ui-contract/`, and `.claude/skills/` and `.claude/hooks/` into the repo's `.claude/`. Merge `.claude/settings.ui-contract.example.json` into `.claude/settings.json`.
2. Start `tokens.json` (copy the example and edit it). It's fine to start small.
3. In Claude Code: *"Use ui-contract-extract on src/pages/<AgreedScreen>.tsx"*.
   It writes manifests for every library component the screen uses, a template, and a **round-trip spec** describing the screen itself, then validates with `--allow-proposed`.
   The round trip is the proof: if the contract can describe the agreed screen, it's a valid base.
4. Review, then set `status: "approved"` on what you accept. This is the moment the team agrees on the base.
5. Next screen: *"Use ui-screen-spec for RE-1234"*.

Repeat step 3 on two or three more agreed screens (different archetypes) to grow the catalogue.

## Preview (approve pictures, not JSON)

Previews and the visual check both run in **Vitest browser mode** (`vitest.config.ts`, `preview/vitest-ui.tsx`), in a real browser, with your real library.

- `previewTests(spec, …)` renders the spec with `SpecPreview`, **one test per state**, and writes two baselines per state into `previews/<screen>/`:
  - `<state>-<browser>-<platform>.png`, the picture people approve;
  - `<state>.aria.yml`, the accessibility tree (roles, names, states), the same view parity's tier 1 and acceptance locators use.
- `pageTests(spec, Page, …)` renders the **built page**, with MSW serving the spec's samples for each state (`pending` held open, `failed` returns 500). It compares against the **same** files: it polls until the tree equals the approved one, then compares the screenshot (pixelmatch, retried until two captures agree).

```
npm run ui:preview -- <screen>.preview   # vitest run --project ui-preview -u   write/refresh one screen's previews → commit → approve in the PR
npm run ui:page                          # vitest run --project ui-page         CI: never with -u
npm run ui:holdout                       # vitest run --project ui-holdout      CI or a person: a sample the page's author never saw
npm run ui:sabotage                      # vitest run --project ui-sabotage     planted breaks, each must be caught
npm run guard:test                       # the Claude Code hook's own sabotage table
```

Approval is the PR that adds or changes `previews/`. Reviewers see the image diffs. Generate baselines **on the CI runner**, not a laptop: fonts and GPUs differ, and the platform is in the file name.

Shared file names: the tests name screenshots `ui__<screen>__<state>`, and `resolveScreenshotPath` maps that into `previews/`. Vitest strips folders from a screenshot name, hence the separator.

## Library requirements

- Library components forward `data-ui-id` to their root DOM node (one line per component, or a shared wrapper).
- Each template has a layout component (e.g. `ListDetailLayout`) with one prop per slot.

## CI

```yaml
# Azure Pipelines / GitHub Actions step, adapt as needed
- run: npx tsx ui-contract/tools/validate.ts --root ui-contract            # every spec
- run: npx tsx ui-contract/tools/validate.ts --root ui-contract --require-approved   # on main only
- run: |                                                                  # each spec ↔ its page
    for s in ui-contract/specs/*.json; do
      n=$(basename "$s" .json)
      f=$(git ls-files "src/**/$n.tsx" | head -1)
      [ -n "$f" ] && npx tsx ui-contract/tools/check-code.ts --root ui-contract "$s" "$f"
    done
```

Use `--json` for agent-readable output. Every error carries a `→` fix hint, so the agent can self-correct.

### Visual gate (gate 3)

`npm run ui:page` (see Preview). Three checks per state against the approved previews:

1. the accessibility tree (exact);
2. the page's pixels (`allowedMismatchedPixelRatio: 0.001`);
3. each placement's pixels, one screenshot per `[data-ui-id=…]`, same ratio.

The third exists because a whole-page ratio misses a small change. In the demo, a metric turning red passed `empty` on the page-wide check: the red "$0" was under 0.1% of the page. On the metric's own screenshot it fails. Placement baselines live in `previews/<screen>/placements/<state>__<placement>-<browser>-<platform>.png` and are written by the same preview run. People approve the page pictures; the placement files ride along in the same PR. A placement with no element in the DOM is an error, never a skip.

### Holdout (gate 4)

The page's author sees the spec's `sample`, so a page can be written to show exactly those rows. `holdoutTests(spec, Page, …)` closes that: it renders the spec with a **second sample** (`holdout/<screen>.json`, one value per data key) through `SpecPreview`, renders the built page with MSW serving the same values, and compares the two accessibility trees, per state. There are no baseline files and nothing to approve, because both sides come from the approved spec.

- A person writes the holdout sample, with different row counts, longer names and other statuses than the visible one.
- The agent that builds the page never reads `holdout/`. The hook below blocks it.
- A failure says `holdout_failed: <screen>/<state>` and nothing else. The trees hold the holdout data, so printing them would spend the holdout. Pass `verbose: true` when a person is debugging.
- No holdout file, unknown keys, or a holdout equal to the visible sample is `could_not_run`, which fails.

### Sabotage tests

`npm run ui:sabotage` builds pages that are wrong in one way each and expects the named check to fail: a changed tone (caught by the placement screenshot, in `empty` too), a dropped `data-ui-id`, and a page hard-coded to the visible sample (passes every visible check, caught by the holdout). If one of these passes on a broken page, a check has gone soft. Add a row whenever QA finds something the gates let through.

## Guarding the gates from the agent

`.claude/hooks/ui-contract-guard.mjs` is a Claude Code `PreToolUse` hook. Merge `.claude/settings.ui-contract.example.json` into the repo's `.claude/settings.json` to switch it on. It blocks:

| Attack | Blocked when |
| --- | --- |
| Editing a preview, placement baseline or ARIA tree | Always by hand; by re-render once the screen's spec is `approved` |
| Editing the spec | Once it is `approved` |
| `vitest -u` | Outside the `ui-preview` project, with no screen named, or naming an approved screen |
| Editing `ui-contract/preview/` (the thresholds) or the hook | Always |
| Reading or changing `ui-contract/holdout/` | Always |
| `rm`, `cp`, `mv`, redirects, `git checkout` onto previews | Always |

Paths are resolved before they are matched, so `a/../../ui-contract/previews/…` is caught. `npm run guard:test` runs 45 rows of attacks and of normal work that must stay allowed.

It is a guard, not a sandbox: a shell command written to dodge the patterns can get past it, and a holdout file inside the repo can still be reached by a script that builds the path. The PR diff on `previews/` is still the approval, and CI should run `ui:page` and `ui:holdout` itself.

### Variance test (optional, Gus's idea)

Run `ui-screen-spec` several times on the same ticket and diff the specs. Agreement means the contract is doing the work. Disagreement shows a missing rule: a vague `useWhen`, a slot that accepts too much, or a missing template.

## Try the examples

The demo maps `@your-org/ui` to a stand-in library (`examples/demo/mock-ui.tsx`) in `vitest.config.ts`.

```
npm i && npx playwright install chromium     # or CHROME_PATH=/path/to/chrome
npx tsx tools/validate.ts --root examples --allow-proposed examples/specs/bordereaux.json   # passes
npx tsx tools/validate.ts --root examples examples/specs/broken.json                          # 12 errors, on purpose
npx tsx tools/check-code.ts --root examples examples/specs/bordereaux.json examples/pages/BordereauxList.tsx
npm run ui:preview -- bordereaux.preview && npm run ui:page                                     # 5 + 5 passing
npm run ui:holdout && npm run ui:sabotage && npm run guard:test                                 # 5 + 8 + 46 passing
```

## In designc

This kit is the standalone version. `docs/ui-contract.md` in designc describes the same contract as a UI pack, with the spec's state graph shared by acceptance criteria, parity scenarios and QA bugs.

## Known limits

- `check-code.ts` is regex-level. That's good enough to catch drift. If it gets noisy, move it to the TS compiler API or an ESLint rule.
- Shapes are coarse on purpose. If two components keep getting confused, refine the shape or sharpen `avoidWhen` before adding machinery.
- Semantic choice is still judgement: a component can be valid and still wrong for the data. The `why` field and the spec review exist for that.
