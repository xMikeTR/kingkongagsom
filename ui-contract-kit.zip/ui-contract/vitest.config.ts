/**
 * Vitest browser mode for the UI contract (example setup; merge into the app's vite/vitest config).
 *
 *   npx vitest run --project ui-preview -u   write or refresh the previews people approve
 *   npx vitest run --project ui-page         CI: built pages against the approved previews (never -u)
 *   npx vitest run --project ui-holdout      CI or a person: built pages against a sample their author never saw
 *   npx vitest run --project ui-sabotage     planted breaks, each must be caught
 *
 * Generate baselines on the CI runner, not a laptop: fonts and GPUs differ, and the
 * platform is part of the file name.
 */
import { defineConfig } from "vitest/config";
import { playwright } from "@vitest/browser-playwright";
import react from "@vitejs/plugin-react";
import { resolve } from "node:path";

const PREVIEWS = "examples/previews";   // at work: ui-contract/previews

const browser = () => ({
  enabled: true,
  headless: true,
  provider: playwright({ launchOptions: process.env.CHROME_PATH ? { executablePath: process.env.CHROME_PATH } : {} }),
  instances: [{ browser: "chromium" as const, viewport: { width: 1440, height: 900 } }],
  expect: {
    toMatchScreenshot: {
      // name `ui__<screen>__<state>` → previews/<screen>/<state>-<browser>-<platform>.png, shared by preview and page tests.
      // name `ui__<screen>__<state>__<placement>` → previews/<screen>/placements/<state>__<placement>-<browser>-<platform>.png.
      // (Vitest strips folders from the name, hence the __ separator.)
      resolveScreenshotPath: ({ arg, ext, root, browserName, platform, testFileDirectory, screenshotDirectory, testFileName }: any) => {
        const m = /^ui__([a-z0-9-]+)__([a-z0-9-]+)(?:__([a-z0-9-]+))?$/.exec(arg);
        return m
          ? m[3]
            ? resolve(root, PREVIEWS, m[1], "placements", `${m[2]}__${m[3]}-${browserName}-${platform}${ext}`)
            : resolve(root, PREVIEWS, m[1], `${m[2]}-${browserName}-${platform}${ext}`)
          : resolve(root, testFileDirectory, screenshotDirectory, testFileName, `${arg}-${browserName}-${platform}${ext}`);
      },
    },
  },
});

export default defineConfig({
  plugins: [react()],
  publicDir: "examples/demo/public",       // mockServiceWorker.js (npx msw init <publicDir>)
  resolve: {
    alias: {                               // demo only: your app resolves the real library
      "@your-org/ui/layouts": resolve(import.meta.dirname, "examples/demo/mock-ui.tsx"),
      "@your-org/ui": resolve(import.meta.dirname, "examples/demo/mock-ui.tsx"),
    },
  },
  test: {
    projects: [
      { extends: true, test: { name: "ui-preview", include: ["examples/ui-tests/*.preview.test.tsx"], browser: browser() } },
      { extends: true, test: { name: "ui-page", include: ["examples/ui-tests/*.page.test.tsx"], browser: browser() } },
      // Second sample the page's author never saw. Run by a person or CI, not by the agent that built the page.
      { extends: true, test: { name: "ui-holdout", include: ["examples/ui-tests/*.holdout.test.tsx"], browser: browser() } },
      // Proves the checks catch what they claim to: each test plants a break and expects a failure.
      { extends: true, test: { name: "ui-sabotage", include: ["examples/sabotage/*.test.tsx"], browser: browser() } },
    ],
  },
});
