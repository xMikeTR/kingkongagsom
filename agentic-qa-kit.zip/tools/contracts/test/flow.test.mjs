// End-to-end: the author → builder → runner flow on a copy of examples/demo-repo, through the CLI.
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const cli = path.join(here, "..", "bin", "contracts.mjs");
const demo = path.join(here, "..", "..", "..", "examples", "demo-repo");

function repo() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "contracts-"));
  fs.cpSync(demo, dir, { recursive: true });
  const sh = (...a) => spawnSync("git", a, { cwd: dir, encoding: "utf8" });
  sh("init", "-q", "-b", "main");
  sh("add", "-A");
  sh("-c", "user.email=t@t", "-c", "user.name=t", "commit", "-qm", "base");
  const run = (...args) => spawnSync("node", [cli, ...args, "--root", dir], { cwd: dir, encoding: "utf8" });
  const commit = (msg) => { sh("add", "-A"); sh("-c", "user.email=t@t", "-c", "user.name=t", "commit", "-qm", msg); };
  const write = (f, s) => { fs.mkdirSync(path.dirname(path.join(dir, f)), { recursive: true }); fs.writeFileSync(path.join(dir, f), s); };
  return { dir, run, commit, write, fixture: (n) => path.join(dir, "fixtures", n) };
}

const buildReport = `kind: build-report
schema_version: v1
id: REIN-123/WP-FE-1
status: proposed
wp_ref: REIN-123/WP-FE-1
files_changed: [src/features/contracts/Filter.tsx]
self_check: believes-done
`;

function authored() {
  const r = repo();
  assert.equal(r.run("red-run", "REIN-123", "--from-report", r.fixture("red-good.json")).status, 0);
  assert.equal(r.run("lock", "REIN-123").status, 0);
  assert.equal(r.run("gate-author", "REIN-123").status, 0);
  r.commit("test: lock acceptance suite REIN-123");
  return r;
}

test("author: a scenario that passes before any code is rejected", () => {
  const r = repo();
  const res = r.run("red-run", "REIN-123", "--from-report", r.fixture("red-wrong-reason.json"));
  assert.equal(res.status, 1);
  assert.match(res.stdout, /passes without the implementation/);
  assert.match(res.stdout, /failed\/environment/);
});

test("builder: building before the suite is committed is refused", () => {
  const r = repo();
  r.run("red-run", "REIN-123", "--from-report", r.fixture("red-good.json"));
  r.run("lock", "REIN-123");
  const res = r.run("gate-builder", "REIN-123/WP-FE-1", "--no-run");
  assert.equal(res.status, 1);
  assert.match(res.stdout, /commit the locked suite before building/);
});

test("builder: changes inside its scope pass", () => {
  const r = authored();
  r.write("src/features/contracts/Filter.tsx", "export const Filter = () => null;\n");
  r.write("artifacts/build-reports/REIN-123/WP-FE-1.yaml", buildReport);
  r.write(".features-gen/tests/acceptance/x.feature.spec.js", "// generated\n");
  r.write("test-results/run/trace.zip", "x");
  const res = r.run("gate-builder", "REIN-123/WP-FE-1", "--from-report", r.fixture("green.json"));
  assert.equal(res.status, 0, res.stdout);
  assert.match(res.stdout, /2\/2 acceptance scenario\(s\) green/);
});

test("builder: claiming done with red scenarios fails; honestly reporting blocked may stop", () => {
  const r = authored();
  r.write("src/features/contracts/Filter.tsx", "export const Filter = () => null;\n");
  r.write("artifacts/build-reports/REIN-123/WP-FE-1.yaml", buildReport);
  let res = r.run("gate-builder", "REIN-123/WP-FE-1", "--from-report", r.fixture("red-good.json"));
  assert.equal(res.status, 1);
  assert.match(res.stdout, /acceptance: REIN-123\/AC-1\/S1 fail \(element-not-found\)/);
  r.write("artifacts/build-reports/REIN-123/WP-FE-1.yaml", buildReport.replace("believes-done", "blocked") + "blockers: [\"AC-2 scenario expects a Clear filters button the design does not have\"]\n");
  res = r.run("gate-builder", "REIN-123/WP-FE-1", "--from-report", r.fixture("red-good.json"));
  assert.equal(res.status, 0, res.stdout);
});

test("builder: editing a locked scenario or a file outside scope fails", () => {
  const r = authored();
  r.write("artifacts/build-reports/REIN-123/WP-FE-1.yaml", buildReport);
  r.write("src/shared/api/client.ts", "export {};\n");
  const feature = path.join(r.dir, "tests/acceptance/rein-123-contract-filter.feature");
  fs.writeFileSync(feature, fs.readFileSync(feature, "utf8").replace('only contracts for underwriting year "2026" are listed', "contracts are listed"));
  const res = r.run("gate-builder", "REIN-123/WP-FE-1", "--no-run");
  assert.equal(res.status, 1);
  assert.match(res.stdout, /src\/shared\/api\/client\.ts: forbidden/);
  assert.match(res.stdout, /rein-123-contract-filter\.feature: forbidden/);
  assert.match(res.stdout, /locked scenario was modified/);
});

test("builder: committing the forbidden change does not hide it", () => {
  const r = authored();
  r.write("artifacts/build-reports/REIN-123/WP-FE-1.yaml", buildReport);
  r.write("package.json", '{"dependencies":{"left-pad":"1"}}');
  r.commit("sneaky");
  const res = r.run("gate-builder", "REIN-123/WP-FE-1", "--no-run");
  assert.equal(res.status, 1);
  assert.match(res.stdout, /package\.json: (outside|dependency)/);
});

test("runner: green run is ready for QA; regression or a hand-edited verdict is not", () => {
  const r = authored();
  let res = r.run("report", "REIN-123", "--from-report", r.fixture("green.json"));
  assert.equal(res.status, 0, res.stdout);
  assert.equal(r.run("verdict", "REIN-123").status, 0);

  res = r.run("report", "REIN-123", "--from-report", r.fixture("green-regression.json"));
  assert.equal(res.status, 1);
  assert.match(res.stdout, /regression: 1 other scenario/);

  const f = path.join(r.dir, "artifacts/ac-reports/REIN-123.yaml");
  fs.writeFileSync(f, fs.readFileSync(f, "utf8").replace("verdict: not-ready", "verdict: ready-for-qa"));
  res = r.run("verdict", "REIN-123");
  assert.equal(res.status, 1);
  assert.match(res.stdout, /do not support it/);
});

test("runner: a scenario edited after the lock fails its AC even if green", () => {
  const r = authored();
  const feature = path.join(r.dir, "tests/acceptance/rein-123-contract-filter.feature");
  fs.writeFileSync(feature, fs.readFileSync(feature, "utf8").replace("When I clear the underwriting year filter", "When I reload the page"));
  const res = r.run("report", "REIN-123", "--from-report", r.fixture("green.json"));
  assert.equal(res.status, 1);
  assert.match(res.stdout, /AC-2 failed: REIN-123\/AC-2\/S1 pass \(lock broken\)/);
});

test("runner gate: an honest not-ready report passes report-check; a doctored one does not", () => {
  const r = authored();
  r.run("report", "REIN-123", "--from-report", r.fixture("green-regression.json"));
  assert.equal(r.run("report-check", "REIN-123").status, 0);
  const f = path.join(r.dir, "artifacts/ac-reports/REIN-123.yaml");
  fs.writeFileSync(f, fs.readFileSync(f, "utf8").replace("verdict: not-ready", "verdict: ready-for-qa"));
  assert.equal(r.run("report-check", "REIN-123").status, 1);
});
