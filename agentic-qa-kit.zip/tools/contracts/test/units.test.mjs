import { test } from "node:test";
import assert from "node:assert/strict";
import { parseFeature, scenarioHash } from "../lib/gherkin.mjs";
import { globToRegex, matchAny } from "../lib/glob.mjs";
import { classify, checkRedFirst } from "../lib/results.mjs";
import { lintStory } from "../lib/acs.mjs";
import { DEFAULTS } from "../lib/io.mjs";

test("gherkin: tags, background, outlines and tags after an Examples block", () => {
  const f = parseFeature(`@story:X-1
Feature: F
  Background:
    Given a thing
  @id:X-1/AC-1/S1 @ac:AC-1
  Scenario Outline: one
    When I do <a>
    Then I see <b>
    @slow
    Examples:
      | a | b |
      | 1 | 2 |
  @id:X-1/AC-2/S1 @ac:AC-2
  Scenario: two
    When I go
    Then I arrive
`);
  assert.deepEqual(f.tags, ["@story:X-1"]);
  assert.equal(f.scenarios.length, 2);
  assert.deepEqual(f.scenarios[0].tags, ["@id:X-1/AC-1/S1", "@ac:AC-1"]);
  assert.deepEqual(f.scenarios[1].tags, ["@id:X-1/AC-2/S1", "@ac:AC-2"]);
  assert.equal(f.scenarios[0].steps.length, 2);
  assert.match(f.scenarios[0].text, /\| 1 \| 2 \|/);
});

test("gherkin: hash ignores whitespace and comments, not wording", () => {
  const a = scenarioHash("Scenario: s\n  When I go\n  Then I arrive");
  assert.equal(a, scenarioHash("  Scenario:   s\n# note\n    When I go\n\n Then  I arrive  "));
  assert.notEqual(a, scenarioHash("Scenario: s\n  When I go\n  Then I arrive somewhere"));
});

test("glob", () => {
  assert.ok(globToRegex("src/features/**").test("src/features/a/b.tsx"));
  assert.ok(matchAny("tests/acceptance/x.feature", ["tests/acceptance/**"]));
  assert.ok(!matchAny("src/shared/x.ts", ["src/features/**"]));
  assert.ok(matchAny("src/a.ts", ["src/*.ts"]));
  assert.ok(!matchAny("src/a/b.ts", ["src/*.ts"]));
  assert.ok(matchAny("a/b/c.ts", ["**/c.ts"]));
});

test("classify Playwright errors", () => {
  assert.equal(classify("Error: locator.click: Test timeout of 30000ms exceeded.\n  - waiting for getByRole('button')"), "element-not-found");
  assert.equal(classify("Error: expect(received).toBe(expected)\nExpected: 1\nReceived: 2"), "assertion");
  assert.equal(classify("page.goto: net::ERR_CONNECTION_REFUSED"), "environment");
  assert.equal(classify("Missing step definitions: 2"), "undefined-step");
  assert.equal(classify("Test timeout of 30000ms exceeded."), "timeout");
});

test("red-first accepts only right reasons", () => {
  assert.deepEqual(checkRedFirst({ results: [{ scenario: "a", outcome: "failed", failure_kind: "assertion" }] }), []);
  assert.equal(checkRedFirst({ results: [{ scenario: "a", outcome: "passed", failure_kind: "none" }] }).length, 1);
  assert.equal(checkRedFirst({ results: [{ scenario: "a", outcome: "failed", failure_kind: "undefined-step" }] }).length, 1);
});

test("AC lint catches vague, compound and implementation-flavoured criteria", () => {
  const story = {
    kind: "story", schema_version: "v1", id: "X-1", status: "draft", ticket: "X-1", title: "t",
    narrative: { as_a: "a", i_want: "b", so_that: "c" },
    acceptance_criteria: [
      { id: "AC-1", given: ["g"], when: "I save and then I submit", then: ["the system processes it"], category: "functional", surface: "ui", testable: true },
      { id: "AC-2", given: ["g"], when: "I open the page", then: ["the component re-renders"], category: "functional", surface: "ui", testable: true },
      { id: "AC-3", given: ["g"], when: "I compare", then: ["it matches"], category: "parity", testable: true },
    ],
  };
  const schemaOnly = lintStory(story, DEFAULTS);
  assert.ok(schemaOnly.errors.some((e) => e.includes("parity_ref")), "parity AC without parity_ref fails the schema");
  story.acceptance_criteria[2].parity_ref = "LEG-1";
  const { errors } = lintStory(story, DEFAULTS);
  assert.ok(errors.some((e) => e.startsWith("AC-1") && e.includes("more than one action")));
  assert.ok(errors.some((e) => e.startsWith("AC-1") && e.includes("not observable")));
  assert.ok(errors.some((e) => e.startsWith("AC-2") && e.includes('"component"')));
});
