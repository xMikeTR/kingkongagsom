---
name: deliver-story
description: Orchestrate one PO-signed story from work packages to a ready-for-QA evidence report - acceptance author first, then builders, then the runner, with a gate at every handoff. Use when the user asks to deliver, build or implement a story by its id (e.g. "deliver REIN-123").
---

# Deliver a story

You are the orchestrator on the main thread. You spawn subagents and check gates. You don't write tests or feature code yourself.

`contracts` below means `node tools/contracts/bin/contracts.mjs`. Always put the artifact **file path** in each subagent's prompt: the stop hooks find the story or work package from it.

## 0. Preconditions (stop and tell the user if any fails)

```
contracts check-signed <ID>     # PO has signed the story
contracts lint-acs <ID>         # ACs are testable as written
contracts coverage-wp <ID>      # every AC owned by a work package; test trees forbidden to builders
```
- If the work packages don't exist yet, create them first: run the planning skill (`impl-plan`), whose output must follow `tools/contracts/schemas/work-package.v1.json`. Then rerun `coverage-wp`.
- Make sure the app is running and `BASE_URL` points at it. The red run needs a live app.

## 1. Acceptance (tests before code)

Spawn **acceptance-author**:

> Write the acceptance scenarios for the story in `artifacts/stories/<ID>.yaml`. Its work packages are in `artifacts/work-packages/<ID>/`. Follow your skill; finish only when `contracts gate-author <ID>` passes.

Then:
1. Run `contracts gate-author <ID>` yourself.
2. Show the user the new step definitions it listed (`new_steps` in `artifacts/acceptance-suites/<ID>.yaml`). They need QA review.
3. **Commit** the feature files, steps, suite and updated work packages:
   ```
   git add tests artifacts && git commit -m "test(<ID>): lock acceptance suite"
   ```
   Builders are measured from this commit. Without it, the builder gate refuses to run.

## 2. Build

- For each work package, spawn **builder-frontend** or **builder-backend** according to its `role`:
  > Implement the work package in `artifacts/work-packages/<ID>/<WP>.yaml`. Follow your skill; finish only when `contracts gate-builder <ID>/<WP>` passes, or stop with self_check: blocked and a precise blocker.
- **Ordering:** build packages in `depends_on` order (usually backend first). Packages with no dependency between them and no overlapping `allowed_paths` can run in parallel, but only in separate git worktrees. Packages in the same working tree must run one at a time, because the gate checks every changed file in that tree.
- After each builder:
  1. Run `contracts gate-builder <ID>/<WP>` yourself.
  2. Read its build report.
  3. If it says `blocked`, **don't** send it back to the builder. Route the blocker:
     - a wrong scenario goes to the acceptance author, with the scenario id and the blocker. Re-locking changes the suite, so the user must agree;
     - an ambiguous AC goes to the user or the PO;
     - a missing interface goes to the package that provides it.
  4. Commit each package separately: `git commit -m "feat(<ID>): <WP> <objective>"`.

## 3. Verify

Spawn **acceptance-runner**:

> Produce the evidence report for the story in `artifacts/stories/<ID>.yaml`. Follow your skill.

Then run `contracts verdict <ID>`:
- **ready-for-qa:** commit the report, and tell the user the story can move to Ready for QA, with the report path. If there's a Jira integration, attach the report and the evidence there.
- **not-ready:** show the runner's triage. Fix by routing each failure to its owner (step 2's routing rules), then rerun step 3. Never edit the report.

## 4. Review (optional, after ready-for-qa)

Spawn the code reviewer on the story's diff since the lock commit. Review covers design and code quality. Regression is already covered by step 3's executed run.

## Rules for you, the orchestrator

- Never weaken a gate to get past it: don't edit `contracts.config.json`, the roles file, a locked scenario or a report.
- A blocked builder is a result to route, not a failure to hide.
- Keep the user informed at each handoff with one line: what passed, what's next.
