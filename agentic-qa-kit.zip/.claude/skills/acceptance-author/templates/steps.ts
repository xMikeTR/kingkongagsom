// Step definitions for playwright-bdd. One file per domain area (contracts.steps.ts, quotes.steps.ts, ...).
// Reuse before adding: every new pattern goes into the acceptance suite's new_steps for QA review.
import { expect } from '@playwright/test';
import { createBdd } from 'playwright-bdd';

const { Given, When, Then } = createBdd();

// Given: put the system in a state. Prefer the app's test-data API over clicking through the UI.
Given('contracts exist for underwriting years {string} and {string}', async ({ request }, y1: string, y2: string) => {
  const res = await request.post('/test-data/contracts', { data: { years: [y1, y2] } });
  expect(res.ok()).toBeTruthy(); // fail loudly if setup didn't happen
});

// When: exactly one user action. Locate by role + name, then label, then test id. Never CSS/XPath.
When('I filter by underwriting year {string}', async ({ page }, year: string) => {
  await page.getByLabel('Underwriting year').selectOption(year);
});

// Then: an observable outcome, with an expect that fails if the behaviour is missing.
Then('the underwriting year filter shows {string}', async ({ page }, year: string) => {
  await expect(page.getByLabel('Underwriting year')).toHaveValue(year);
});
