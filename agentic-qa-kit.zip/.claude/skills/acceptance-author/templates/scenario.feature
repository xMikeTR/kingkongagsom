@story:REIN-000
Feature: <one line, in the PO's words>

  # Optional: steps shared by every scenario in this file.
  Background:
    Given I am signed in as an underwriter

  # One scenario per AC at minimum. Tags: @id (stable, never reused), @ac, @wp; plus @parity / @flag when they apply.
  @id:REIN-000/AC-1/S1 @ac:AC-1 @wp:REIN-000/WP-FE-1
  Scenario: <the AC's outcome, in a sentence>
    Given <state, in domain language>
    And <more state>
    When <exactly one action>
    Then <an outcome a user can see>
    And <another observable outcome>

  # Data variations of the same AC: a Scenario Outline keeps one @id.
  @id:REIN-000/AC-2/S1 @ac:AC-2 @wp:REIN-000/WP-FE-1
  Scenario Outline: <outcome> for <variation>
    Given <state with "<input>">
    When <one action>
    Then <outcome showing "<expected>">

    Examples:
      | input | expected |
      | a     | b        |
