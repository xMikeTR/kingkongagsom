---
name: acceptance-author
description: Write failing, locked playwright-bdd acceptance scenarios and step definitions from a PO-signed story, before any code exists. Use in the acceptance phase, after work packages are planned and before builders start.
---

# Acceptance author

**Input:** a story file `artifacts/stories/<ID>.yaml` (must be `status: signed` by the PO) and its work packages under `artifacts/work-packages/<ID>/`.

**Output:**
- `.feature` files under `tests/acceptance/`;
- any new step definitions under `tests/steps/`;
- `artifacts/acceptance-suites/<ID>.yaml` (written by the CLI, never by hand);
- each work package's `acceptance_tests` list filled in.

`contracts` below means `node tools/contracts/bin/contracts.mjs`.

## Procedure

1. **Check the inputs.** Run `contracts check-signed <ID>` and `contracts coverage-wp <ID>`. If either fails, stop and report it: unsigned criteria and unowned ACs are not yours to fix.
2. **Read the step library first.** List the existing patterns with `grep -rhoE "(Given|When|Then)\('[^']+'" tests/steps`. Reuse a step whenever its meaning matches, even if you'd have worded it differently.
3. **Write one or more scenarios per testable AC**, in a feature file named after the story (`tests/acceptance/<id-lowercase>-<slug>.feature`). Use `templates/scenario.feature`:
   - The Feature carries `@story:<ID>`.
   - Every scenario carries `@id:<ID>/<AC>/S<n>`, `@ac:<AC>` and `@wp:<WP-ID>` (the work package that owns that AC and builds its UI or behaviour). Add `@parity:<ref>` for parity ACs and `@flag:<name>` for flagged ones.
   - One `When` per scenario. Copy the AC's intent; don't add behaviour the PO didn't sign.
   - Every `Then` checks something a user or API consumer can observe.
   - Step text is domain language: no selectors, URLs, test ids or CSS.
4. **Add step definitions only where no existing step matches**, using `templates/steps.ts`:
   - Every `Then` contains at least one `expect(...)` that would fail if the behaviour were missing.
   - Locate elements by role and accessible name, then by label, then by test id. Never by CSS or XPath.
   - No `test.skip`, `.only`, `.fixme`, `expect(true)` or catch-and-ignore.
   - Keep test data setup in `Given` steps, through the app's test-data API or fixtures, never by poking the UI.
5. **Check form:** `contracts coverage <ID>` and `contracts steps-lint`. Fix everything they report.
6. **Red run:** `contracts red-run <ID>`. This runs bddgen and only this story's scenarios, against the app as it is now, without the new code. Every scenario must fail for a **right reason**: `assertion`, `element-not-found` or `timeout`.
   - `passed` means the scenario doesn't test the new behaviour. Tighten it.
   - `undefined-step`, `syntax-error` or `fixture-error` means your test is broken. Fix it.
   - `environment` means the app isn't reachable. Say so and stop; the orchestrator must start the app.
   - Repeat until `contracts red-run <ID>` passes.
7. **Lock:** `contracts lock <ID>`. This records a hash per scenario. From now on, any change to these scenarios fails every later gate.
8. **Fill each work package's `acceptance_tests`** with the scenario ids it owns (the `@wp` tags you assigned).
9. **List new steps** in the suite file's `new_steps` (pattern, file, one-line justification) so QA can review them. This is the only manual edit allowed in the suite file; rerun `contracts lock <ID>` afterwards.
10. **Final check:** `contracts gate-author <ID>` must pass. Then reply with:
    - scenario count per AC;
    - the new steps added;
    - anything in the ACs you found ambiguous: note it, don't resolve it.

## When to stop and ask instead

- An AC can't be tested as written (no observable outcome): stop, quote it, and say what's missing.
- Two ACs contradict each other, or an AC contradicts the work package's interfaces.
- The app or test-data API needed for `Given` steps doesn't exist.
