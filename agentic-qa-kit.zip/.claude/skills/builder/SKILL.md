---
name: builder
description: Implement exactly one work package (artifacts/work-packages/<ID>/<WP>.yaml) inside its allowed paths until its locked acceptance scenarios pass. Used by the builder-frontend and builder-backend subagents.
---

# Builder

**Input:**
- one work package file;
- the repo at the commit where the acceptance suite was locked;
- the acceptance scenarios and step definitions, which are read-only.

**Output:**
- code inside `scope.allowed_paths`, with unit tests;
- `artifacts/build-reports/<ID>/<WP>.yaml`.

`contracts` below means `node tools/contracts/bin/contracts.mjs`.

## Procedure

1. **Read the work package.** In five lines or fewer, write down in your scratchpad:
   - the objective;
   - the ACs it owns;
   - its allowed paths;
   - the interfaces it provides and consumes;
   - its definition of done.
2. **Check what you depend on.** For each `consumes` interface, confirm it exists and matches its spec. If it doesn't, stop with `self_check: blocked`; don't invent it.
3. **See the target fail.** Run only your scenarios:
   ```
   npx bddgen && npx playwright test --grep "@wp:<WP-ID>"
   ```
   Read the failures. They describe what to build.
4. **Implement in small steps.** After each meaningful change, rerun your scenarios and the unit tests for the code you touched.
5. **Add unit tests** for any logic you introduce: branching, mapping, validation, calculations.
6. **When green, run the repo's lint and type checks** for the files you changed.
7. **Write the build report** at `artifacts/build-reports/<ID>/<WP>.yaml`:
   ```yaml
   kind: build-report
   schema_version: v1
   id: <ID>/<WP>
   status: proposed
   wp_ref: <ID>/<WP>
   files_changed: [<every file you changed>]
   unit_tests_added: [<test files>]
   self_check: believes-done   # or blocked / partial
   blockers: []                # required when blocked/partial: one precise sentence each
   ```
8. **Check yourself:** `contracts gate-builder <ID>/<WP>`. This is what the stop hook runs. With `believes-done`, your scenarios must be green and every changed file must be inside your allowed paths.

## Never

- Edit anything under `tests/acceptance/`, `tests/steps/` or `artifacts/` except your build report.
- Make a test pass by special-casing test data, detecting the test environment, or hard-coding the expected values.
- Change an interface you consume, add dependencies (unless `may_add_dependencies: true`), or edit files outside your allowed paths to "help".
- Keep going past `budget.max_turns`. Write a `partial` build report and stop.

## If a scenario seems wrong

Don't work around it. Write the build report with `self_check: blocked` and a blocker that quotes the scenario and says why (for example, "AC-2/S1 expects a 'Clear filters' button; the UI contract shows a reset link"). Then stop. The orchestrator takes it back to the acceptance author or the PO.

## Frontend notes

- Build from the design system's components and tokens; don't invent styles.
- Every interactive element needs an accessible name (label, `aria-label` or visible text). The scenarios locate by role and name, so missing names show up as `element-not-found`.
- Cover the states the UI contract lists (empty, loading, error, no permission), not only the happy path.

## Backend notes

- Provide each `provides` interface exactly as specified, and add a contract test for each HTTP one.
- Keep data access behind the existing repository and service patterns in the codebase.
- Validate inputs at the boundary, and return the error shapes the existing API uses.
