#!/usr/bin/env node
// PreToolUse hook: stops a subagent from writing outside its role's paths.
// Reads the hook JSON on stdin. Exit 0 = allow; exit 2 = block (stderr is shown to the agent).
// Roles come from .claude/contracts-roles.json, keyed by the subagent's agent_type.
import fs from "node:fs";
import path from "node:path";

const dir = process.env.CLAUDE_PROJECT_DIR || process.cwd();
const { matchAny } = await import(new URL("../../tools/contracts/lib/glob.mjs", import.meta.url));

let input;
try { input = JSON.parse(fs.readFileSync(0, "utf8")); } catch { process.exit(0); }

const debug = (msg) => {
  if (!process.env.CONTRACTS_HOOK_DEBUG) return;
  fs.mkdirSync(path.join(dir, ".claude", "state"), { recursive: true });
  fs.appendFileSync(path.join(dir, ".claude", "state", "hooks.log"), `${new Date().toISOString()} path-guard ${msg}\n`);
};

const role = input.agent_type;
let cfg;
try { cfg = JSON.parse(fs.readFileSync(path.join(dir, ".claude", "contracts-roles.json"), "utf8")); } catch { process.exit(0); }
const rules = role && cfg.roles[role];
debug(`agent_type=${role ?? "(main)"} tool=${input.tool_name}`);
if (!rules) process.exit(0); // main thread or a role this kit doesn't govern

const toRel = (p) => path.relative(dir, path.resolve(dir, p)).split(path.sep).join("/");
const verdict = (file) => {
  if (file.startsWith("..")) return `${file} is outside the project`;
  if (matchAny(file, cfg.always_deny)) return `${file} is protected (gates and agent config)`;
  if (rules.allow && !matchAny(file, rules.allow)) return `${role} may only write ${rules.allow.join(", ")}; not ${file}`;
  if (rules.deny && matchAny(file, rules.deny)) return `${role} may not write ${file}`;
  return null;
};

const ti = input.tool_input || {};
const problems = [];

if (input.tool_name === "Bash") {
  // Best effort: a command that both names a protected path and looks like a write. The SubagentStop gate re-checks from git.
  const cmd = String(ti.command || "");
  const writes = /(>|>>|\btee\b|\bsed\s+-i|\bperl\s+-pi|\bmv\b|\bcp\b|\brm\b|\btouch\b|\bgit\s+(checkout|restore|reset|rm|mv|apply|stash)\b|writeFile)/.test(cmd);
  if (writes) {
    const candidates = cmd.match(/[\w./@-]+\/[\w./@*-]+/g) || [];
    for (const c of candidates) {
      const v = verdict(toRel(c));
      if (v && !v.includes("outside the project")) problems.push(v);
    }
  }
} else {
  const target = ti.file_path || ti.notebook_path || ti.path;
  if (target) {
    const v = verdict(toRel(target));
    if (v) problems.push(v);
  }
}

if (problems.length) {
  const msg = [...new Set(problems)].join("\n");
  debug(`BLOCK ${msg}`);
  process.stderr.write(
    `Blocked by the path guard:\n${msg}\n` +
    (role.startsWith("builder")
      ? "Builders never change acceptance tests or artifacts. If a scenario looks wrong, stop with self_check: blocked and explain why in your build report."
      : "Stay inside your role's paths.") + "\n"
  );
  process.exit(2);
}
process.exit(0);
