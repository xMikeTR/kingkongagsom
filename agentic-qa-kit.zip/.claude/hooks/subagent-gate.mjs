#!/usr/bin/env node
// SubagentStop hook: a governed subagent may only finish when its phase gate passes.
// Exit 0 = let it stop; exit 2 = keep it working (stderr is shown to the subagent).
//
// Which story or work package the subagent is on is read from its transcript: the orchestrator
// must put the artifact path in the prompt (artifacts/stories/<ID>.yaml or
// artifacts/work-packages/<ID>/<WP>.yaml). The deliver-story skill does this.
import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";

const MAX_ATTEMPTS = Number(process.env.CONTRACTS_GATE_MAX_ATTEMPTS || 3);
const dir = process.env.CLAUDE_PROJECT_DIR || process.cwd();
const cli = path.join(dir, "tools", "contracts", "bin", "contracts.mjs");
const stateDir = path.join(dir, ".claude", "state");

let input;
try { input = JSON.parse(fs.readFileSync(0, "utf8")); } catch { process.exit(0); }

const role = input.agent_type || "";
const governed = ["acceptance-author", "acceptance-runner", "builder-frontend", "builder-backend"];
if (!governed.includes(role)) process.exit(0);

const transcriptFile = input.agent_transcript_path || input.transcript_path;
const transcript = transcriptFile && fs.existsSync(transcriptFile) ? fs.readFileSync(transcriptFile, "utf8") : "";
const wpMatch = transcript.match(/artifacts\/work-packages\/([A-Z][A-Z0-9]*-\d+)\/(WP-[A-Za-z0-9-]+)\.yaml/);
const storyMatch = transcript.match(/artifacts\/stories\/([A-Z][A-Z0-9]*-\d+)\.yaml/);

const run = (...args) => spawnSync("node", [cli, ...args, "--root", dir], { cwd: dir, encoding: "utf8" });

let gate;
if (role === "acceptance-author") {
  if (!storyMatch) gate = { problem: "no artifacts/stories/<ID>.yaml path found in the task; the orchestrator must name the story file" };
  else gate = run("gate-author", storyMatch[1]);
} else if (role === "acceptance-runner") {
  if (!storyMatch) gate = { problem: "no artifacts/stories/<ID>.yaml path found in the task" };
  else gate = run("report-check", storyMatch[1]);
} else {
  if (!wpMatch) gate = { problem: "no artifacts/work-packages/<ID>/<WP>.yaml path found in the task; the orchestrator must name the work package file" };
  else gate = run("gate-builder", `${wpMatch[1]}/${wpMatch[2]}`);
}

if (!gate.problem && gate.status === 0) { clearAttempts(); process.exit(0); }

// Count attempts so a stuck agent can't loop forever. After MAX_ATTEMPTS it may stop, and the overrun is logged.
const attempts = bumpAttempts();
const detail = gate.problem || `${gate.stdout}${gate.stderr}`.trim();
if (attempts > MAX_ATTEMPTS) {
  fs.mkdirSync(path.join(dir, "artifacts", "_runs"), { recursive: true });
  fs.appendFileSync(path.join(dir, "artifacts", "_runs", "gate-overruns.log"),
    `${new Date().toISOString()} ${role} ${wpMatch ? `${wpMatch[1]}/${wpMatch[2]}` : storyMatch?.[1] ?? "?"} stopped after ${MAX_ATTEMPTS} failed gate attempts\n${detail}\n\n`);
  process.stderr.write(`Gate still failing after ${MAX_ATTEMPTS} attempts; stopping. Logged to artifacts/_runs/gate-overruns.log. Report the blocker in your final message.\n`);
  process.exit(0);
}
process.stderr.write(
  `You can't finish yet: your phase gate failed (attempt ${attempts} of ${MAX_ATTEMPTS}).\n${detail}\n\n` +
  (role.startsWith("builder")
    ? "Fix the code within your work package's allowed paths. Never edit acceptance tests. If a test is wrong, write a build report with self_check: blocked and a blocker, then stop."
    : "Fix the problems above, rerun the listed contracts command, then finish.") + "\n"
);
process.exit(2);

function attemptsFile() { return path.join(stateDir, "gate-attempts.json"); }
function readAttempts() { try { return JSON.parse(fs.readFileSync(attemptsFile(), "utf8")); } catch { return {}; } }
function key() { return input.agent_id || `${role}:${input.session_id}`; }
function bumpAttempts() {
  const a = readAttempts();
  a[key()] = (a[key()] || 0) + 1;
  fs.mkdirSync(stateDir, { recursive: true });
  fs.writeFileSync(attemptsFile(), JSON.stringify(a, null, 2));
  return a[key()];
}
function clearAttempts() {
  const a = readAttempts();
  if (a[key()]) { delete a[key()]; fs.writeFileSync(attemptsFile(), JSON.stringify(a, null, 2)); }
}
