# Agentic QA kit for Claude Code

Tests before code, scoped builders, and a "Ready for QA" verdict computed by a script, not claimed by an agent. Drop it into a repo that uses Claude Code. No other platform is needed.

```
story (PO-signed) ─► work packages ─► acceptance-author ─► [commit lock] ─► builders ─► acceptance-runner ─► verdict
                                        writes failing,                     make the        runs everything,
                                        locked scenarios                    scenarios pass  writes evidence
```

| Phase | Who | Gate (deterministic) | Enforced by |
|---|---|---|---|
| Ready | you (orchestrator) | story signed, ACs lint clean, every AC owned by a work package | `deliver-story` skill |
| Acceptance | `acceptance-author` (Sonnet) | every testable AC has a scenario; tags complete; steps assert; every scenario failed for a right reason before code; scenarios locked | SubagentStop hook → `contracts gate-author` |
| Build | `builder-frontend` / `builder-backend` (Sonnet) | changed files (since the lock commit) inside the work package's allowed paths; locked scenarios untouched; the work package's scenarios green, unless it honestly reports `blocked` | PreToolUse path guard + SubagentStop hook → `contracts gate-builder` |
| Verify | `acceptance-runner` (Haiku) | per-AC report from a full run, including regression; verdict computed; report not hand-edited | SubagentStop hook → `contracts report-check`; you run `contracts verdict` |

## What's in the box

```
.claude/
  agents/            acceptance-author, builder-frontend, builder-backend, acceptance-runner
  skills/            acceptance-author (+ templates), builder, acceptance-runner, deliver-story (orchestration)
  hooks/             path-guard.mjs (PreToolUse), subagent-gate.mjs (SubagentStop)
  contracts-roles.json   who may write where
  settings.json      registers the hooks
tools/contracts/     the CLI: schemas, Gherkin reader, coverage, red-first, locks, path guard, AC report, verdict (+ tests)
examples/demo-repo/  a worked story (REIN-123): story, two work packages, feature, steps, Playwright config, report fixtures
```

## Install into a repo

1. Copy `.claude/` and `tools/contracts/` into the repo root. If the repo already has `.claude/settings.json`, merge the `hooks` block.
2. Install the CLI's dependencies: `cd tools/contracts && npm install`. It needs Node 20+ and three packages: `ajv`, `ajv-formats` and `yaml`.
3. In the frontend repo, add playwright-bdd: `npm i -D @playwright/test playwright-bdd`. Use `examples/demo-repo/playwright.config.ts` as the starting config.
4. Add to `.gitignore`: `.features-gen/`, `test-results/`, `playwright-report/`, `artifacts/_runs/`, `.claude/state/`.
5. Optional: add `contracts.config.json` at the root to change folders, commands, the base branch, the mutation threshold or the parity policy. The defaults are in `tools/contracts/lib/io.mjs`.
6. Point your existing skills at the contracts:
   - `br-to-scenarios` must write `artifacts/stories/<ID>.yaml` matching `tools/contracts/schemas/story.v1.json`, and the PO's sign-off sets `status: signed` with a `signoff` block.
   - `impl-plan` must write `artifacts/work-packages/<ID>/<WP>.yaml` matching `work-package.v1.json`.
   - The demo repo has one of each.

Then, in Claude Code: **"deliver REIN-123"** (or `/deliver-story REIN-123`).

## Conventions

- **Artifacts:** `artifacts/stories/<ID>.yaml`, `artifacts/work-packages/<ID>/<WP>.yaml`, `artifacts/acceptance-suites/<ID>.yaml`, `artifacts/build-reports/<ID>/<WP>.yaml`, `artifacts/ac-reports/<ID>.yaml`.
- **Feature tags:**
  - `@story:<ID>` on the Feature;
  - on every Scenario: `@id:<ID>/<AC>/S<n>` (stable, never reused), `@ac:<AC>` and `@wp:<ID>/<WP>`;
  - plus `@parity:<ref>` and `@flag:<name>` where they apply.
- **Step text** is domain language. Locators go role and name first, then label, then test id; never CSS or XPath. Every `Then` contains an `expect`.
- **Prompts name files.** Subagent prompts must include the story or work-package file path; the stop hook finds the work from it. `deliver-story` does this for you.
- **Commit the lock.** Commit the locked suite before spawning builders. Builders are measured from that commit.

## The CLI

`node tools/contracts/bin/contracts.mjs help` lists every command. Exit codes: 0 pass, 1 gate failed, 2 usage or runtime error. Most useful by hand:

```
contracts lint-acs REIN-123          # are these ACs testable?
contracts gate-author REIN-123       # is the acceptance suite ready to hand to builders?
contracts gate-builder REIN-123/WP-FE-1
contracts report REIN-123            # full run, AC report with verdict
contracts verdict REIN-123
```

Every command that runs tests also accepts `--from-report <playwright.json>`, so you can check a CI run's report without re-running.

Run the kit's own tests with `cd tools/contracts && npm test` (15 tests). They cover the end-to-end flow on the demo repo plus the parser and gate rules.

## How enforcement works, and its limits

Three layers, from cheapest to strongest:

1. **Instructions** in the agent and skill files tell each role what not to do.
2. **The path guard** (PreToolUse) blocks writes outside a role's paths as they happen. For Bash it's best effort: it blocks commands that both look like a write and name a protected path.
3. **The stop gates** (SubagentStop) re-check everything from git and the test run before an agent may finish. They catch anything the first two missed, including Bash writes and committed changes.

Known limits:

- **Claude Code version.** The hooks rely on Claude Code passing `agent_type` (and, at SubagentStop, the subagent transcript path) to hooks. Check this on your version with `CONTRACTS_HOOK_DEBUG=1`, which logs what the path guard sees to `.claude/state/hooks.log`. If `agent_type` is missing, the path guard can't tell roles apart and allows the write, but the stop gates still catch it from git.
- **Frontmatter hooks.** Hooks declared in agent frontmatter have had bug reports, so the kit registers everything in `settings.json` instead.
- **One builder per working tree.** The gate checks every changed file in the tree. Run independent packages in parallel only in separate git worktrees.
- **Lint is heuristic.** The step lint is regex-based and catches the common ways a test gets weakened, not all of them. Mutation testing is the real backstop: set `mutationThreshold` and pass `--mutation <score>` to `report`.
- **No parity check yet.** Parity ACs produce a warning, or a blocking reason if `"parity": "require"`. Wire a visual or structural parity check in when you have one.
- **Stuck agents stop after three gate failures.** `CONTRACTS_GATE_MAX_ATTEMPTS` changes the limit; overruns are logged to `artifacts/_runs/gate-overruns.log`. The verdict will still be `not-ready`, so nothing slips through.

## Adapting

- **Reqnroll / .NET acceptance tests:** add a mapper next to `lib/results.mjs` that reads TRX into the same per-scenario shape. Nothing else changes.
- **Another tracker:** the artifacts are files. Mirror the AC report to Jira or Azure DevOps from CI, or from the orchestrator after `verdict`.
- **Another harness** (Copilot CLI, your own): the CLI is the gate. Call `gate-author`, `gate-builder` and `report-check` from whatever lifecycle hooks that harness offers.
