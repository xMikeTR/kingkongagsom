import { defineConfig } from '@playwright/test';
import { defineBddConfig } from 'playwright-bdd';

const testDir = defineBddConfig({
  features: 'tests/acceptance/**/*.feature',
  steps: 'tests/steps/**/*.ts',
});

export default defineConfig({
  testDir,
  use: { baseURL: process.env.BASE_URL ?? 'http://localhost:5173', trace: 'on', video: 'on', screenshot: 'on' },
  reporter: [['json'], ['html', { open: 'never' }]],
});
