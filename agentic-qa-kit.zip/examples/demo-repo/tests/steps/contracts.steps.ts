import { expect } from '@playwright/test';
import { createBdd } from 'playwright-bdd';

const { Given, When, Then } = createBdd();

Given('I am signed in as an underwriter', async ({ page }) => {
  await page.goto('/');
});

Given('contracts exist for underwriting years {string} and {string}', async ({ request }, y1: string, y2: string) => {
  await request.post('/test-data/contracts', { data: { years: [y1, y2] } });
});

Given('I am on the contracts page', async ({ page }) => {
  await page.goto('/contracts');
});

Given('I am on the contracts page filtered by underwriting year {string}', async ({ page }, year: string) => {
  await page.goto(`/contracts?uwYear=${year}`);
});

When('I filter by underwriting year {string}', async ({ page }, year: string) => {
  await page.getByLabel('Underwriting year').selectOption(year);
});

When('I clear the underwriting year filter', async ({ page }) => {
  await page.getByRole('button', { name: 'Clear filters' }).click();
});

Then('only contracts for underwriting year {string} are listed', async ({ page }, year: string) => {
  const years = page.getByRole('row').getByRole('cell', { name: /^\d{4}$/ });
  await expect(years.first()).toBeVisible();
  for (const text of await years.allTextContents()) expect(text).toBe(year);
});

Then('the underwriting year filter shows {string}', async ({ page }, year: string) => {
  await expect(page.getByLabel('Underwriting year')).toHaveValue(year);
});

Then('contracts for underwriting years {string} and {string} are listed', async ({ page }, y1: string, y2: string) => {
  await expect(page.getByRole('cell', { name: y1 }).first()).toBeVisible();
  await expect(page.getByRole('cell', { name: y2 }).first()).toBeVisible();
});
