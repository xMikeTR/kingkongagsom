@story:REIN-123
Feature: Filter contracts by underwriting year

  Background:
    Given I am signed in as an underwriter

  # Each scenario carries @id (stable), @ac and @wp. Do not edit after the lock.
  @id:REIN-123/AC-1/S1 @ac:AC-1 @wp:REIN-123/WP-FE-1
  Scenario: Underwriter filters to a single year
    Given contracts exist for underwriting years "2025" and "2026"
    And I am on the contracts page
    When I filter by underwriting year "2026"
    Then only contracts for underwriting year "2026" are listed
    And the underwriting year filter shows "2026"

  @id:REIN-123/AC-2/S1 @ac:AC-2 @wp:REIN-123/WP-FE-1
  Scenario: Underwriter clears the year filter
    Given contracts exist for underwriting years "2025" and "2026"
    And I am on the contracts page filtered by underwriting year "2026"
    When I clear the underwriting year filter
    Then contracts for underwriting years "2025" and "2026" are listed
