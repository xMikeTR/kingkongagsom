import { defineConfig, devices } from '@playwright/test';

const isCI = !!process.env.CI;
const EVIDENCE = process.env.EVIDENCE_DIR ?? 'evidence';

// Runs against the deployed slot, never a local build.
// Locally: lean (no video). In CI: video, traces, full evidence.
export default defineConfig({
  testDir: './app/src/ui/e2e/acceptance',
  fullyParallel: true,
  forbidOnly: true,          // a stray test.only fails the run
  retries: 0,                // passing on retry = flaky = not proven
  workers: isCI ? '50%' : 2,
  outputDir: `${EVIDENCE}/artifacts`,
  snapshotPathTemplate: '{testDir}/__screenshots__/{projectName}/{arg}{ext}',
  reporter: [
    ['list'],
    ['json', { outputFile: `${EVIDENCE}/results.json` }],
    ['html', { outputFolder: `${EVIDENCE}/html`, open: 'never' }],
  ],
  use: {
    baseURL: process.env.SLOT_URL ?? 'http://localhost:5173',
    video: isCI ? 'on' : 'off',
    trace: isCI ? 'on' : 'off',
    screenshot: 'on',
    timezoneId: 'Europe/London',  // dates and numbers render identically everywhere
    locale: 'en-GB',
  },
  expect: {
    toHaveScreenshot: { maxDiffPixelRatio: 0.002, animations: 'disabled', caret: 'hide' },
  },
  // Two widths: where React layouts usually break. Screenshots are per project.
  projects: [
    { name: 'desktop', use: { ...devices['Desktop Chrome'], viewport: { width: 1440, height: 900 } } },
    { name: 'laptop', use: { ...devices['Desktop Chrome'], viewport: { width: 1280, height: 720 } } },
  ],
});
