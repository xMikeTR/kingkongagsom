// Convention the gate relies on:
//   - One describe per ticket, tagged with the ticket key.
//   - One test per acceptance criterion, title starting "AC-<n>:" matching the Jira ticket.
//   - AC tests use mockApi() so screenshots are deterministic.
//   - At least one LIVE test hits the real API (Snowflake-backed) and checks the
//     frozen fixtures still have the real shape.
//   - Written from the ticket's ACs BEFORE the implementation.
import { test, expect, expectSameShape, settle } from './fixtures';

test.describe('PROJ-123 Bulk-approve submissions', { tag: '@PROJ-123' }, () => {
  test.beforeEach(async ({ page, mockApi }) => {
    await mockApi('/api/submissions', 'submissions.json');
    await page.goto('/submissions');
    await settle(page);
  });

  test('AC-1: approver can select multiple submissions', async ({ page }) => {
    const boxes = page.getByRole('checkbox', { name: /select submission/i });
    await boxes.nth(0).check();
    await boxes.nth(1).check();

    await expect(page.getByText('2 selected')).toBeVisible();
    await expect(page).toHaveScreenshot('PROJ-123-AC-1.png', { fullPage: true });
  });

  test('AC-2: bulk approve updates status of all selected', async ({ page, mockApi }) => {
    await mockApi('/api/submissions/approve', 'approve-ok.json');
    const boxes = page.getByRole('checkbox', { name: /select submission/i });
    await boxes.nth(0).check();
    await boxes.nth(1).check();

    const approve = page.waitForRequest((r) => r.url().includes('/api/submissions/approve') && r.method() === 'POST');
    await page.getByRole('button', { name: 'Approve selected' }).click();
    // The UI must send exactly the selected ids, not just look right.
    expect((await approve).postDataJSON()).toEqual({ ids: ['S-001', 'S-002'] });

    await expect(page.getByRole('row').filter({ hasText: 'Approved' })).toHaveCount(2);
    await expect(page).toHaveScreenshot('PROJ-123-AC-2.png', { fullPage: true });
  });

  test('AC-3: approve button disabled with nothing selected', async ({ page }) => {
    await expect(page.getByRole('button', { name: 'Approve selected' })).toBeDisabled();
  });

  test.describe('unhappy path', () => {
    // Failures are mocked deliberately here, so HTTP 5xx is expected, not a bug.
    // Uncaught exceptions still fail the test.
    test.use({ apiErrorsExpected: true });

    test('AC-4: API failure shows an error, not a blank table', async ({ page }) => {
      await page.unrouteAll();
      await page.route('**/api/submissions*', (r) => r.fulfill({ status: 503, body: '{}' }));
      await page.reload();
      await expect(page.getByRole('alert')).toContainText(/couldn.t load/i);
      await expect(page).toHaveScreenshot('PROJ-123-AC-4.png');
    });
  });
});

test.describe('PROJ-123 live wiring', { tag: ['@PROJ-123', '@live'] }, () => {
  test('LIVE: real API returns data the UI renders', async ({ page, apiJson }) => {
    const live = await apiJson('/api/submissions');
    await expectSameShape(live, 'submissions.json');

    await page.goto('/submissions');
    await settle(page);
    const rows = (live as any[]).length;
    await expect(page.getByRole('row')).toHaveCount(rows + 1); // + header
  });
});
