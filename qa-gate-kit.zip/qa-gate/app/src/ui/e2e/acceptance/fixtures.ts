// Shared test fixture for every acceptance spec. Import { test, expect } from here,
// never from '@playwright/test' directly (the guard can't see intent, but review can).
//
// What every test gets for free:
//   - fails on any console error or uncaught page exception
//   - fails on any API call returning 4xx/5xx or failing at network level
//   - axe accessibility scan at the end (serious + critical violations fail)
//   - mockApi(): serve frozen API responses so visuals are deterministic
//     (Snowflake data changes daily; screenshots must not)
//   - expectSameShape(): live tests prove the frozen fixtures still match the real API
import { test as base, expect, type Page } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const API = process.env.API_PATH_PREFIX ?? '/api/';
const FIXTURES = join(dirname(fileURLToPath(import.meta.url)), 'api-fixtures');

type Fixtures = {
  /** Set via test.use({ apiErrorsExpected: true }) only in tests that deliberately mock failures. */
  apiErrorsExpected: boolean;
  mockApi: (urlPart: string, fixtureFile: string, status?: number) => Promise<void>;
  apiJson: (urlPart: string) => Promise<unknown>;
};

export const test = base.extend<Fixtures>({
  apiErrorsExpected: [false, { option: true }],

  page: async ({ page, apiErrorsExpected }, use, testInfo) => {
    const problems: string[] = [];
    const isApiNoise = (text: string) => apiErrorsExpected && /Failed to load resource|status of [45]\d\d/.test(text);
    page.on('console', (m) => { if (m.type() === 'error' && !isApiNoise(m.text())) problems.push(`console.error: ${m.text()}`); });
    page.on('pageerror', (e) => problems.push(`uncaught: ${e.message}`));
    page.on('requestfailed', (r) => { if (r.url().includes(API)) problems.push(`network fail: ${r.url()} ${r.failure()?.errorText}`); });
    page.on('response', (r) => {
      if (!apiErrorsExpected && r.url().includes(API) && r.status() >= 400) problems.push(`HTTP ${r.status()}: ${r.url()}`);
    });

    await use(page);

    // Accessibility: only if the test got far enough to have a page.
    if (testInfo.status === testInfo.expectedStatus && page.url() !== 'about:blank') {
      const axe = await new AxeBuilder({ page }).analyze();
      const serious = axe.violations.filter((v) => v.impact === 'serious' || v.impact === 'critical');
      for (const v of serious) problems.push(`a11y ${v.impact}: ${v.id} (${v.nodes.length} node(s))`);
    }
    // Final visual state of every test, attached as evidence.
    if (page.url() !== 'about:blank') {
      await testInfo.attach('final-state', { body: await page.screenshot({ fullPage: true }), contentType: 'image/png' });
    }
    expect(problems, 'page must be free of console errors, failed API calls and serious a11y issues').toEqual([]);
  },

  mockApi: async ({ page }, use) => {
    await use(async (urlPart, fixtureFile, status = 200) => {
      const body = readFileSync(join(FIXTURES, fixtureFile), 'utf8');
      await page.route(`**${urlPart}*`, (route) =>
        route.fulfill({ status, contentType: 'application/json', body }));
    });
  },

  apiJson: async ({ request }, use) => {
    await use(async (urlPart) => {
      const res = await request.get(urlPart);
      expect(res.status(), `${urlPart} should succeed against the real API`).toBe(200);
      return res.json();
    });
  },
});

/** Structural type of a JSON value: keys and primitive types, arrays by first element. */
export function shapeOf(v: unknown): unknown {
  if (v === null) return 'null';
  if (Array.isArray(v)) return v.length ? [shapeOf(v[0])] : [];
  if (typeof v === 'object') {
    return Object.fromEntries(Object.keys(v as object).sort().map((k) => [k, shapeOf((v as any)[k])]));
  }
  return typeof v;
}

/** Live data must have the same shape as the frozen fixture, or the fixture is lying. */
export async function expectSameShape(live: unknown, fixtureFile: string) {
  const frozen = JSON.parse(readFileSync(join(FIXTURES, fixtureFile), 'utf8'));
  expect(shapeOf(live), `fixture ${fixtureFile} has drifted from the real API`).toEqual(shapeOf(frozen));
}

export async function settle(page: Page) {
  await page.waitForLoadState('networkidle');
  await page.evaluate(() => document.fonts.ready);
}

export { expect };
