// The Evidence type. Its constructor is private: the ONLY way to get one is
// Evidence.tryCreate, which succeeds only if every check passes.
// promote() requires an Evidence, so "Ready for QA without proof" cannot be expressed.
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { join, sep } from 'node:path';

export type Result<T> = { ok: true; value: T } | { ok: false; errors: string[] };

export type AcProof = { id: string; title: string; videos: string[]; screenshots: string[] };
export type MutationSummary = { report: string; killed: number; survived: number; noCoverage: number; score: number };

export type EvidenceInputs = {
  dir: string;                              // evidence folder
  ticketKey: string;
  commitSha: string;
  acceptanceCriteria: { id: string; text: string }[]; // from Jira, not from the repo
  mutationThreshold: number;                // e.g. 80
  requireVideo: boolean;                    // true in CI
};

type PwAttachment = { name: string; contentType: string; path?: string };
type PwTest = { status: 'expected' | 'unexpected' | 'flaky' | 'skipped'; results: { attachments: PwAttachment[] }[] };
type PwSpec = { title: string; tests: PwTest[] };
type PwSuite = { specs?: PwSpec[]; suites?: PwSuite[] };

function collect(suites: PwSuite[] = [], out: PwSpec[] = []): PwSpec[] {
  for (const s of suites) { out.push(...(s.specs ?? [])); collect(s.suites, out); }
  return out;
}

/** Playwright stores absolute paths; in the Promote stage the evidence artifact lives elsewhere. */
function resolveAttachment(dir: string, p: string): string | null {
  if (existsSync(p)) return p;
  const marker = `${sep}artifacts${sep}`;
  const i = p.replace(/[\\/]/g, sep).lastIndexOf(marker);
  if (i < 0) return null;
  const moved = join(dir, 'artifacts', p.slice(i + marker.length));
  return existsSync(moved) ? moved : null;
}

function readJson<T>(path: string): T | null {
  try { return JSON.parse(readFileSync(path, 'utf8')) as T; } catch { return null; }
}

function findFiles(dir: string, name: string, acc: string[] = []): string[] {
  if (!existsSync(dir)) return acc;
  for (const e of readdirSync(dir)) {
    const p = join(dir, e);
    if (statSync(p).isDirectory()) findFiles(p, name, acc);
    else if (e === name) acc.push(p);
  }
  return acc;
}

/** Score per the mutation-testing-report-schema used by StrykerJS and Stryker.NET. */
export function mutationScore(report: any): Omit<MutationSummary, 'report'> {
  let killed = 0, survived = 0, noCoverage = 0;
  for (const f of Object.values<any>(report?.files ?? {})) {
    for (const m of f.mutants ?? []) {
      if (m.status === 'Killed' || m.status === 'Timeout') killed++;
      else if (m.status === 'Survived') survived++;
      else if (m.status === 'NoCoverage') noCoverage++;
    }
  }
  const valid = killed + survived + noCoverage;
  return { killed, survived, noCoverage, score: valid === 0 ? 100 : (killed / valid) * 100 };
}

export class Evidence {
  private constructor(
    readonly ticketKey: string,
    readonly commitSha: string,
    readonly acs: readonly AcProof[],
    readonly mutation: readonly MutationSummary[],
    readonly reviewNotes: string,
  ) {}

  get files(): string[] {
    return this.acs.flatMap((a) => [...a.videos, ...a.screenshots]);
  }

  static tryCreate(i: EvidenceInputs): Result<Evidence> {
    const errors: string[] = [];

    // 1. Acceptance criteria must come from the ticket, and there must be some.
    if (i.acceptanceCriteria.length === 0) {
      errors.push('ticket has no AC-<n> lines in its description');
    }

    // 2. Playwright: every Jira AC has a test, every test passed first time, nothing skipped.
    const pw = readJson<{ suites: PwSuite[]; stats?: { flaky?: number; skipped?: number; unexpected?: number } }>(join(i.dir, 'results.json'));
    const proofs: AcProof[] = [];
    if (!pw) {
      errors.push('no Playwright results.json');
    } else {
      const specs = collect(pw.suites);
      if ((pw.stats?.flaky ?? 0) > 0) errors.push(`${pw.stats!.flaky} flaky test(s)`);
      if ((pw.stats?.skipped ?? 0) > 0) errors.push(`${pw.stats!.skipped} skipped test(s)`);
      if ((pw.stats?.unexpected ?? 0) > 0) errors.push(`${pw.stats!.unexpected} failing test(s)`);

      for (const ac of i.acceptanceCriteria) {
        const matching = specs.filter((s) => new RegExp(`^${ac.id}\\b`).test(s.title));
        if (matching.length === 0) { errors.push(`${ac.id} has no test`); continue; }
        for (const spec of matching) {
          const bad = spec.tests.filter((t) => t.status !== 'expected');
          if (bad.length) { errors.push(`${spec.title}: ${bad.map((t) => t.status).join(',')}`); continue; }
          const atts = spec.tests
            .flatMap((t) => t.results.at(-1)?.attachments ?? [])
            .flatMap((a) => { const p = a.path && resolveAttachment(i.dir, a.path); return p ? [{ ...a, path: p }] : []; });
          const videos = atts.filter((a) => a.contentType.startsWith('video/')).map((a) => a.path);
          const screenshots = atts.filter((a) => a.contentType.startsWith('image/')).map((a) => a.path);
          if (i.requireVideo && videos.length === 0) errors.push(`${spec.title}: no video recorded`);
          proofs.push({ id: ac.id, title: spec.title, videos, screenshots });
        }
      }
    }

    // 3. Anti-gaming guard must be clean.
    const guard = readJson<{ ok: boolean; violations: { rule: string; file: string; detail: string }[] }>(join(i.dir, 'guard.json'));
    if (!guard) errors.push('no guard.json');
    else if (!guard.ok) errors.push(...guard.violations.map((v) => `guard ${v.rule}: ${v.file}: ${v.detail}`));

    // 4. Mutation testing on changed code: tests must actually kill mutants.
    const reports = findFiles(join(i.dir, 'mutation'), 'mutation.json')
      .concat(findFiles(join(i.dir, 'mutation'), 'mutation-report.json'));
    const mutation: MutationSummary[] = [];
    if (reports.length === 0) errors.push('no mutation report');
    for (const r of reports) {
      const s = { report: r, ...mutationScore(readJson(r)) };
      mutation.push(s);
      if (s.score < i.mutationThreshold) {
        errors.push(`mutation score ${s.score.toFixed(1)}% < ${i.mutationThreshold}% (${s.survived} survived, ${s.noCoverage} uncovered) in ${r}`);
      }
    }

    // 5. Independent reviewer must pass, and must have reviewed THIS commit.
    const review = readJson<{ verdict: string; commit?: string; notes?: string }>(join(i.dir, 'review.json'));
    if (!review) errors.push('no reviewer verdict');
    else {
      if (review.verdict !== 'pass') errors.push(`reviewer verdict "${review.verdict}": ${review.notes ?? ''}`);
      if (review.commit && review.commit !== i.commitSha) errors.push('reviewer verdict is for a different commit');
    }

    if (errors.length) return { ok: false, errors };
    return { ok: true, value: new Evidence(i.ticketKey, i.commitSha, proofs, mutation, review?.notes ?? '') };
  }
}
