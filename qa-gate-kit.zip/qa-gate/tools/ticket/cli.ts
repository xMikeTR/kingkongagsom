#!/usr/bin/env -S npx tsx
// ticket — QA gate CLI. Jira is reached only through the Atlassian MCP (no API token),
// so this CLI never talks to Jira. It manages the AC snapshot, checks evidence, and
// proves (against Azure DevOps) that a ticket may move to Ready for QA.
//
//   ticket snapshot <KEY> [--update]   capture ACs from the Jira description (stdin) into <KEY>.acs.json
//   ticket acs      <KEY>              print the captured ACs
//   ticket verify   <KEY>              does local/CI evidence satisfy Evidence? (CI runs this)
//   ticket ci-check <KEY>              is there a succeeded, approved ADO run for this exact commit?
//                                      (the Jira hook runs this before allowing the QA transition)
//   ticket promote  <KEY>              ci-check, then print the evidence comment for the agent
//                                      to post via MCP before transitioning
import { execFileSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { Evidence } from './evidence.ts';
import { parseAcceptanceCriteria, readSnapshot, snapshotPath, writeSnapshot, type AcSnapshot } from './acs.ts';
import { findApprovedRun } from './ado.ts';
import { PROTECTED } from './guard.ts';

const env = process.env;
const DIR = env.EVIDENCE_DIR ?? 'evidence';
const THRESHOLD = Number(env.MUTATION_THRESHOLD ?? 80);
const BASE = env.BASE_REF ?? 'origin/main';
const TO = env.TO_STATUS ?? 'Ready for QA';

function die(msg: string): never {
  console.error(`✗ ${msg}`);
  process.exit(1);
}

const git = (...a: string[]) => execFileSync('git', a, { encoding: 'utf8' }).trim();

function keyArg(arg?: string): string {
  if (arg && /^[A-Z][A-Z0-9]+-\d+$/.test(arg)) return arg;
  if (env.TICKET_KEY) return env.TICKET_KEY;
  return git('rev-parse', '--abbrev-ref', 'HEAD').match(/[A-Z][A-Z0-9]+-\d+/)?.[0] ?? die('no ticket key given and none in branch name');
}

/** The committed snapshot, read from git, so uncommitted edits can't influence it. */
function committedSnapshot(key: string, commit: string): AcSnapshot {
  try {
    return JSON.parse(git('show', `${commit}:${snapshotPath(key)}`)) as AcSnapshot;
  } catch {
    return die(`no committed AC snapshot ${snapshotPath(key)} at ${commit.slice(0, 8)}`);
  }
}

type Checked = { evidence: Evidence; runUrl: string; manualSignoff: boolean; acs: AcSnapshot };

function ciCheck(key: string): Checked {
  const head = git('rev-parse', 'HEAD');
  let upstream = '';
  try { upstream = git('rev-parse', '@{u}'); } catch { die('branch has no upstream. Push it first.'); }
  if (upstream !== head) die('local HEAD is not what was pushed. Push (or pull) so CI verified this exact commit.');
  if (!git('rev-parse', '--abbrev-ref', 'HEAD').includes(key)) die(`current branch is not the ${key} branch`);

  // The gate itself must be untouched in this branch, or CI may have run a modified gate.
  const base = git('merge-base', head, BASE);
  const changed = git('diff', '--name-only', base, head).split('\n').filter(Boolean);
  const tampered = changed.filter((f) => PROTECTED.some((p) => p.test(f)));
  if (tampered.length) die(`gate files changed on this branch, so CI's verdict can't be trusted: ${tampered.join(', ')}`);

  const run = findApprovedRun(key, head);
  const acs = committedSnapshot(key, head);
  const result = Evidence.tryCreate({
    dir: run.evidenceDir,
    ticketKey: key,
    commitSha: head,
    acceptanceCriteria: acs.acs,
    mutationThreshold: THRESHOLD,
    requireVideo: true,
  });
  if (!result.ok) die(`CI run ${run.runId} evidence does not hold up:\n  - ${result.errors.join('\n  - ')}`);
  return { evidence: result.value, runUrl: run.url, manualSignoff: run.promotion.manualSignoff !== false, acs };
}

function evidenceComment(c: Checked): string {
  const e = c.evidence;
  return [
    `*Verified and ready for QA*`,
    `Commit: ${e.commitSha}`,
    `Pipeline run (videos, screenshots, traces, HTML + mutation reports under Artifacts > evidence): ${c.runUrl}`,
    '',
    '*Acceptance criteria* (each recorded on video, desktop + laptop widths)',
    ...c.acs.acs.map((a) => `(/) ${a.id}: ${a.text}`),
    '',
    '*Also checked on every test:* no console errors, no failed API calls, no serious accessibility issues, visual regression against approved baselines, frozen API data shape matches live API.',
    '*Mutation testing:* ' + e.mutation.map((m) => `${m.score.toFixed(1)}% (${m.killed} killed, ${m.survived} survived)`).join('; '),
    `*Independent review:* pass${e.reviewNotes ? ` — ${e.reviewNotes}` : ''}`,
    c.manualSignoff
      ? '*Visual sign-off:* approved in pipeline by developer'
      : '*Visual sign-off:* automated (visual regression against approved baselines)',
  ].join('\n');
}

async function main() {
  const [cmd, arg, flag] = process.argv.slice(2);

  switch (cmd) {
    case 'snapshot': {
      const key = keyArg(arg);
      const description = readFileSync(0, 'utf8');
      if (parseAcceptanceCriteria(description).length === 0) {
        die(`${key} has no AC-<n> lines. Draft them (npm run draft-acs -- ${key}), Mike pastes them into Jira, then snapshot again.`);
      }
      const snap = writeSnapshot(key, description, flag === '--update');
      console.log(`✓ captured ${snap.acs.length} ACs into ${snapshotPath(key)}. Show Mike, then commit it on its own.`);
      for (const a of snap.acs) console.log(`  ${a.id}: ${a.text}`);
      return;
    }

    case 'acs': {
      console.log(JSON.stringify(readSnapshot(keyArg(arg)).acs, null, 2));
      return;
    }

    case 'verify': {
      const key = keyArg(arg);
      const snap = readSnapshot(key);
      const result = Evidence.tryCreate({
        dir: DIR,
        ticketKey: key,
        commitSha: env.COMMIT_SHA ?? git('rev-parse', 'HEAD'),
        acceptanceCriteria: snap.acs,
        mutationThreshold: THRESHOLD,
        requireVideo: !!env.CI,
      });
      if (!result.ok) {
        console.error(`✗ ${key}: not provable yet`);
        for (const err of result.errors) console.error(`  - ${err}`);
        process.exit(1);
      }
      console.log(`✓ ${key}: evidence complete (${result.value.acs.length} AC proofs).`);
      return;
    }

    case 'ci-check': {
      const key = keyArg(arg);
      const c = ciCheck(key);
      console.log(`✓ ${key}: CI run verified and approved (${c.runUrl}). Transition to ${TO} is allowed.`);
      return;
    }

    case 'promote': {
      const key = keyArg(arg);
      const c = ciCheck(key);
      console.log(`✓ ${key}: verified. Now, using the Atlassian MCP, in this order:`);
      console.log(`  1. Add this comment to ${key}, verbatim:`);
      console.log('----- BEGIN COMMENT -----');
      console.log(evidenceComment(c));
      console.log('----- END COMMENT -----');
      console.log(`  2. Transition ${key} to "${TO}". The Jira hook re-checks CI before allowing it.`);
      console.log(`  (If ${key} is already in "${TO}", skip step 2: the comment is the backfilled evidence.)`);
      return;
    }

    default:
      console.log('usage: ticket snapshot <KEY> [--update] | acs <KEY> | verify <KEY> | ci-check <KEY> | promote <KEY>');
      process.exit(cmd ? 1 : 0);
  }
}

main().catch((e) => die(e instanceof Error ? e.message : String(e)));
