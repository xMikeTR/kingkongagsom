// Azure DevOps, via the az CLI (az login + azure-devops extension, Mike's own auth).
// This is the unforgeable part: an agent can write files, but it can't make an
// Azure DevOps run succeed or produce pipeline artifacts.
import { execFileSync } from 'node:child_process';
import { mkdtempSync, existsSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

export type Promotion = { ticketKey: string; sourceCommit: string; buildId: string; approved: boolean; manualSignoff?: boolean };
export type VerifiedRun = { runId: number; url: string; promotion: Promotion; evidenceDir: string };

function az(args: string[]): string {
  return execFileSync('az', args, { encoding: 'utf8', maxBuffer: 64 * 1024 * 1024, stdio: ['ignore', 'pipe', 'pipe'] });
}

function download(runId: number, artifact: string): string | null {
  const dir = mkdtempSync(join(tmpdir(), `qa-gate-${runId}-${artifact}-`));
  try {
    az(['pipelines', 'runs', 'artifact', 'download', '--run-id', String(runId), '--artifact-name', artifact, '--path', dir]);
    return dir;
  } catch {
    return null; // run has no such artifact
  }
}

/**
 * Finds the most recent SUCCEEDED run of the QA gate pipeline whose approval stage
 * recorded this ticket at this exact source commit. A run only succeeds after the
 * qa-gate approval (or the auto environment, after the trial), so success = approved.
 */
export function findApprovedRun(ticketKey: string, sourceCommit: string): VerifiedRun {
  const pipelineId = process.env.QA_GATE_PIPELINE_ID;
  if (!pipelineId) throw new Error('QA_GATE_PIPELINE_ID is not set');

  const runs = JSON.parse(az([
    'pipelines', 'runs', 'list', '--pipeline-ids', pipelineId,
    '--result', 'succeeded', '--status', 'completed', '--top', String(process.env.QA_GATE_RUN_LOOKBACK ?? 30), '-o', 'json',
  ])) as any[];

  for (const run of runs) {
    const pdir = download(run.id, 'promotion');
    if (!pdir) continue;
    const pfile = join(pdir, 'promotion.json');
    if (!existsSync(pfile)) continue;
    const promotion = JSON.parse(readFileSync(pfile, 'utf8')) as Promotion;
    if (promotion.ticketKey !== ticketKey || promotion.sourceCommit !== sourceCommit || !promotion.approved) continue;

    const evidenceDir = download(run.id, 'evidence');
    if (!evidenceDir) throw new Error(`run ${run.id} has a promotion record but no evidence artifact`);
    return { runId: run.id, url: run._links?.web?.href ?? `run ${run.id}`, promotion, evidenceDir };
  }
  throw new Error(`no succeeded, approved QA gate run found for ${ticketKey} at ${sourceCommit.slice(0, 8)} (checked last ${runs.length} runs)`);
}
