// Anti-gaming guard. Inspects the PR diff for ways an agent (or a tired human)
// could make the gate go green without the work being right.
// Writes evidence/guard.json: { ok, violations[] }. Exit 1 on any violation.
//
// Env: BASE_REF (default origin/main), TICKET_KEY,
//      ALLOW_BASELINE_UPDATE=true   (set by a human at queue time only)
//      ALLOW_GATE_CHANGES=true      (set by a human at queue time only)
import { execFileSync } from 'node:child_process';
import { mkdirSync, writeFileSync } from 'node:fs';

const BASE = process.env.BASE_REF ?? 'origin/main';

// Files that define the gate itself. Changing them in a feature PR = moving the goalposts.
export const PROTECTED = [
  /(^|\/)playwright(\.[\w-]+)?\.config\.[cm]?[jt]s$/,
  /(^|\/)stryker\.conf\.(json|js|mjs)$/,
  /(^|\/)vitest\.config\.[cm]?[jt]s$/,
  /(^|\/)stryker-config\.json$/,
  /^tools\/ticket\//,
  /^scripts\/(review-agent|draft-acs)\.sh$/,
  /^pipeline\//,
  /^\.claude\//,
];

const TEST_FILE = /(\.spec|\.test)\.[cm]?[jt]sx?$|Tests?\.cs$|(^|\/)(tests?|e2e)\//i;
const BASELINE = /__screenshots__\/|-snapshots\//;
const API_FIXTURE = /api-fixtures\//;
const AC_SNAPSHOT = /\.acs\.json$/;

// Added lines that disable or weaken tests.
const DISABLERS: [RegExp, string][] = [
  [/\b(test|it|describe)\.(only|skip|fixme)\s*\(/, 'focused/skipped test'],
  [/\btest\.fail\s*\(/, 'test marked as expected-to-fail'],
  [/\bxit\s*\(|\bxdescribe\s*\(/, 'disabled test'],
  [/\[(Fact|Theory)\s*\(\s*Skip\s*=/, 'skipped xUnit test'],
  [/\[Ignore\b/, 'ignored test'],
  [/\bAssert\.(True|Pass)\s*\(\s*true\s*\)/, 'tautological assertion'],
  [/expect\s*\(\s*true\s*\)\s*\.\s*toBe\s*\(\s*true\s*\)/, 'tautological assertion'],
  [/maxDiffPixel(Ratio)?\s*:/, 'visual tolerance changed in a test'],
  [/\/\/\s*@ts-(ignore|nocheck)|#pragma\s+warning\s+disable/, 'suppression added'],
];

const ASSERTION = /\bexpect\s*\(|\bAssert\.|\.Should\(\)|toHaveScreenshot/;
const ASSERTION_G = new RegExp(ASSERTION.source, 'g');
const countAsserts = (line: string) => line.match(ASSERTION_G)?.length ?? 0;

function git(...args: string[]): string {
  return execFileSync('git', args, { encoding: 'utf8', maxBuffer: 64 * 1024 * 1024 });
}

type Violation = { rule: string; file: string; detail: string };

export function runGuard(): { ok: boolean; violations: Violation[] } {
  const violations: Violation[] = [];
  const allowBaseline = process.env.ALLOW_BASELINE_UPDATE === 'true';
  const allowGate = process.env.ALLOW_GATE_CHANGES === 'true';

  const status = git('diff', '--name-status', `${BASE}...HEAD`).trim().split('\n').filter(Boolean);
  for (const line of status) {
    const [code, ...paths] = line.split('\t');
    const file = paths.at(-1)!;

    if (!allowGate && PROTECTED.some((p) => p.test(file))) {
      violations.push({ rule: 'protected-path', file, detail: 'gate configuration changed in a feature PR' });
    }
    if (BASELINE.test(file) && !allowBaseline) {
      violations.push({ rule: 'baseline-change', file, detail: `visual baseline ${code === 'A' ? 'added' : 'changed'} without human approval` });
    }
    // Editing an existing frozen API response can quietly make a broken UI pass.
    if (API_FIXTURE.test(file) && code.startsWith('M') && !allowBaseline) {
      violations.push({ rule: 'fixture-changed', file, detail: 'existing API fixture modified without human approval' });
    }
    // AC snapshots are captured from Jira once. Changing them = changing the requirements.
    if (AC_SNAPSHOT.test(file) && !code.startsWith('A') && !allowBaseline) {
      violations.push({ rule: 'acs-changed', file, detail: 'acceptance criteria snapshot modified or deleted without human approval' });
    }
    if (code.startsWith('D') && TEST_FILE.test(file)) {
      violations.push({ rule: 'test-deleted', file, detail: 'existing test file deleted' });
    }
  }

  // Line-level checks on test files.
  const diff = git('diff', '-U0', `${BASE}...HEAD`, '--', '.');
  let current = '';
  const removedAsserts = new Map<string, number>();
  const addedAsserts = new Map<string, number>();
  let isNewFile = false;
  const newFiles = new Set<string>();

  for (const l of diff.split('\n')) {
    if (l.startsWith('diff --git')) { isNewFile = false; continue; }
    if (l.startsWith('new file mode')) { isNewFile = true; continue; }
    if (l.startsWith('+++ ')) {
      current = l.replace(/^\+\+\+ (b\/)?/, '');
      if (isNewFile) newFiles.add(current);
      continue;
    }
    if (l.startsWith('--- ') || !TEST_FILE.test(current)) continue;

    if (l.startsWith('+')) {
      for (const [re, why] of DISABLERS) {
        if (re.test(l)) violations.push({ rule: 'test-weakened', file: current, detail: `${why}: ${l.slice(1).trim()}` });
      }
      addedAsserts.set(current, (addedAsserts.get(current) ?? 0) + countAsserts(l));
    } else if (l.startsWith('-')) {
      removedAsserts.set(current, (removedAsserts.get(current) ?? 0) + countAsserts(l));
    }
  }

  // Existing tests may be refactored, but must not end up with fewer assertions.
  for (const [file, removed] of removedAsserts) {
    if (newFiles.has(file)) continue;
    const added = addedAsserts.get(file) ?? 0;
    if (removed > added) {
      violations.push({ rule: 'assertions-removed', file, detail: `${removed} assertion(s) removed, ${added} added` });
    }
  }

  return { ok: violations.length === 0, violations };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const result = runGuard();
  mkdirSync('evidence', { recursive: true });
  writeFileSync('evidence/guard.json', JSON.stringify(result, null, 2));
  for (const v of result.violations) console.error(`GUARD [${v.rule}] ${v.file}: ${v.detail}`);
  console.log(result.ok ? 'GUARD: clean' : `GUARD: ${result.violations.length} violation(s)`);
  process.exit(result.ok ? 0 : 1);
}
