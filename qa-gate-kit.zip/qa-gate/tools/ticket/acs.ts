// Acceptance criteria snapshot. Jira is reachable only through MCP (no API token),
// so CI can't read tickets. The ACs are captured once, from Jira, into
// <acceptanceDir>/<KEY>.acs.json, shown to Mike, and are immutable afterwards
// (the guard blocks edits without human approval).
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { createHash } from 'node:crypto';

export type Ac = { id: string; text: string };
export type AcSnapshot = { ticketKey: string; capturedAt: string; descriptionSha256: string; acs: Ac[] };

export const ACCEPTANCE_DIR = process.env.ACCEPTANCE_DIR ?? 'app/src/ui/e2e/acceptance';

export function snapshotPath(key: string): string {
  return join(ACCEPTANCE_DIR, `${key}.acs.json`);
}

/** Acceptance criteria are lines in the ticket description starting "AC-<n>". */
export function parseAcceptanceCriteria(description: string): Ac[] {
  const out: Ac[] = [];
  for (const line of description.split(/\r?\n/)) {
    const m = line.match(/^\W*(AC-\d+)\s*[:.)-]?\s*(.*)$/);
    if (m && !out.some((a) => a.id === m[1])) out.push({ id: m[1], text: m[2].trim() });
  }
  return out;
}

export function writeSnapshot(key: string, description: string, overwrite: boolean): AcSnapshot {
  const path = snapshotPath(key);
  if (existsSync(path) && !overwrite) {
    throw new Error(`${path} already exists. ACs are immutable once captured; re-capture only with --update after Mike approves.`);
  }
  const acs = parseAcceptanceCriteria(description);
  if (acs.length === 0) throw new Error(`no AC-<n> lines found in the ${key} description`);
  const snap: AcSnapshot = {
    ticketKey: key,
    capturedAt: new Date().toISOString(),
    descriptionSha256: createHash('sha256').update(description).digest('hex'),
    acs,
  };
  writeFileSync(path, JSON.stringify(snap, null, 2) + '\n');
  return snap;
}

export function readSnapshot(key: string, dir = ACCEPTANCE_DIR): AcSnapshot {
  const path = join(dir, `${key}.acs.json`);
  if (!existsSync(path)) throw new Error(`no AC snapshot at ${path}. Capture it first: ticket snapshot ${key}`);
  const snap = JSON.parse(readFileSync(path, 'utf8')) as AcSnapshot;
  if (snap.ticketKey !== key) throw new Error(`${path} is for ${snap.ticketKey}, not ${key}`);
  return snap;
}
