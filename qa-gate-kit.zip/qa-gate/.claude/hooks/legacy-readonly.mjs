#!/usr/bin/env node
// PreToolUse hook: the legacy repo is READ-ONLY for every agent.
// Blocks Edit/Write/MultiEdit/NotebookEdit on any file under it, and any Bash command
// that touches it with anything other than a known read-only command.
// Exit code 2 = blocked; stderr is shown to the agent so it knows why.
//
// Config: LEGACY_REPO_PATH (absolute path to the legacy clone), set in your shell profile
// or in .claude/settings.local.json "env". Several paths can be separated with ':'.
import { readFileSync, realpathSync } from 'node:fs';
import { resolve, sep } from 'node:path';

const roots = (process.env.LEGACY_REPO_PATH ?? '')
  .split(':').filter(Boolean)
  .map((p) => { try { return realpathSync(p); } catch { return resolve(p); } });

if (roots.length === 0) process.exit(0); // not configured: nothing to protect

const input = JSON.parse(readFileSync(0, 'utf8'));
const tool = input.tool_name;
const args = input.tool_input ?? {};
const cwd = input.cwd ?? process.cwd();

function block(reason) {
  process.stderr.write(`BLOCKED: the legacy repo is read-only. ${reason}\n`);
  process.exit(2);
}

function inLegacy(p) {
  if (!p) return false;
  let abs = resolve(cwd, p);
  try { abs = realpathSync(abs); } catch { /* new file: use resolved path */ }
  return roots.some((r) => abs === r || abs.startsWith(r + sep));
}

// 1. File-writing tools.
if (['Edit', 'Write', 'MultiEdit', 'NotebookEdit'].includes(tool)) {
  if (inLegacy(args.file_path ?? args.notebook_path)) block(`${tool} on ${args.file_path ?? args.notebook_path}`);
  process.exit(0);
}

// 2. Bash.
if (tool === 'Bash') {
  const cmd = String(args.command ?? '');
  const touchesLegacy = inLegacy(cwd) || roots.some((r) => cmd.includes(r)) ||
    // relative paths that resolve into the legacy repo, e.g. "cd ../legacy"
    cmd.split(/\s+/).some((tok) => /^[.~\/]/.test(tok) && inLegacy(tok.replace(/^~/, process.env.HOME ?? '~')));
  if (!touchesLegacy) process.exit(0);

  const READ_ONLY = /^(cat|head|tail|less|more|wc|ls|tree|file|stat|grep|egrep|rg|ag|find|fd|diff|cd|pwd|echo|sort|uniq|cut|jq|awk)$/;
  const GIT_READ = /^(log|show|diff|blame|status|grep|ls-files|ls-tree|rev-parse|branch|tag|describe|shortlog|cat-file)$/;

  // Anything that writes, wherever it appears.
  if (/(^|[^<>&0-9])>{1,2}(?!&)/.test(cmd)) block('output redirection is not allowed when the legacy repo is involved');
  if (/\b(sed|perl)\s+(-\w*i|--in-place)|\bfind\b[^|;&]*\s-(delete|exec|execdir|ok)\b|\bawk\b[^|;&]*-i\s*inplace|\btee\b/.test(cmd)) {
    block('in-place edits, find -delete/-exec and tee are not allowed');
  }

  for (const seg of cmd.split(/&&|\|\||;|\||\n/).map((s) => s.trim()).filter(Boolean)) {
    const words = seg.replace(/^(sudo|env\s+\S+=\S+|\S+=\S+)\s+/g, '').split(/\s+/);
    const verb = words[0];
    if (verb === 'git') {
      const sub = words.slice(1).find((w) => !w.startsWith('-') && !inLegacy(w) && !/^-C$/.test(w));
      if (!sub || !GIT_READ.test(sub)) block(`"git ${sub ?? ''}" is not a read-only git command`);
      if (sub === 'branch' || sub === 'tag') {
        if (words.slice(2).some((w) => /^-(d|D|m|M|c|C|f|-delete|-move|-force)$/.test(w) || (!w.startsWith('-') && w !== sub && !inLegacy(w)))) {
          block(`"git ${sub}" may only list, not create or delete`);
        }
      }
      continue;
    }
    if (!READ_ONLY.test(verb)) block(`"${verb}" is not on the read-only command list`);
  }
}

process.exit(0);
