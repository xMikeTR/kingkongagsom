#!/usr/bin/env node
// PreToolUse hook on Atlassian/Jira MCP tools. This is the gate's smart constructor:
//   - Transition to "In Progress" (start):  allowed.
//   - Transition to "Ready for QA":          allowed ONLY if `ticket ci-check <KEY>` proves,
//                                            against Azure DevOps, that a succeeded and
//                                            approved QA gate run exists for this exact commit.
//   - Any other transition:                  blocked (that's Mike's call, not the agent's).
//   - Editing/creating/deleting issues:      blocked (ACs live in Jira; Mike edits them).
//   - Reads and comments:                    allowed.
//
// Config (env, e.g. .claude/settings.local.json "env"):
//   JIRA_START_TRANSITION_IDS  comma-separated transition ids that lead to "In Progress"
//   JIRA_QA_TRANSITION_IDS     comma-separated transition ids that lead to "Ready for QA"
//   QA_GATE_CHECK_CMD          override for tests (default: npx tsx tools/ticket/cli.ts ci-check)
import { readFileSync } from 'node:fs';
import { execSync } from 'node:child_process';

const input = JSON.parse(readFileSync(0, 'utf8'));
const name = String(input.tool_name ?? '');
const args = input.tool_input ?? {};

if (!/jira/i.test(name)) process.exit(0);

function block(reason) {
  process.stderr.write(`BLOCKED by QA gate: ${reason}\n`);
  process.exit(2);
}

const ids = (v) => (process.env[v] ?? '').split(',').map((s) => s.trim()).filter(Boolean);
const START = ids('JIRA_START_TRANSITION_IDS');
const QA = ids('JIRA_QA_TRANSITION_IDS');

// Find values in the tool input regardless of the MCP server's exact argument names.
function find(obj, test) {
  if (obj && typeof obj === 'object') {
    for (const [k, v] of Object.entries(obj)) {
      if (test(k, v)) return v;
      const deep = find(v, test);
      if (deep !== undefined) return deep;
    }
  }
  return undefined;
}

const tool = name.split('__').pop() ?? name;

if (/transition/i.test(tool) && !/^get/i.test(tool)) {
  const key = find(args, (k, v) => /issue/i.test(k) && typeof v === 'string');
  const transition = find(args, (k, v) => /^(id|transitionId)$/i.test(k) && (typeof v === 'string' || typeof v === 'number'));
  if (!key || transition === undefined) block('could not read the issue key or transition id from the tool call');
  const id = String(transition);

  if (START.includes(id)) process.exit(0);
  if (!QA.includes(id)) block(`transition ${id} is not "start" or "Ready for QA". Other status changes are Mike's to make in Jira.`);
  if (!/^[A-Z][A-Z0-9]+-\d+$/.test(String(key))) block(`"${key}" is not a ticket key; use the key (e.g. PROJ-123) so CI can be checked`);

  const cmd = process.env.QA_GATE_CHECK_CMD ?? 'npx tsx tools/ticket/cli.ts ci-check';
  try {
    execSync(`${cmd} ${key}`, { cwd: process.env.CLAUDE_PROJECT_DIR ?? process.cwd(), stdio: ['ignore', 'pipe', 'pipe'], encoding: 'utf8', timeout: 180_000 });
    process.exit(0);
  } catch (e) {
    const detail = `${e.stdout ?? ''}${e.stderr ?? ''}`.trim();
    block(`no proof for ${key} to move to Ready for QA.\n${detail}`);
  }
}

if (/(edit|update|create|delete|assign|link|worklog)/i.test(tool) && !/comment/i.test(tool)) {
  block(`${tool} changes the ticket itself. Acceptance criteria and fields are Mike's to edit in Jira.`);
}

process.exit(0);
