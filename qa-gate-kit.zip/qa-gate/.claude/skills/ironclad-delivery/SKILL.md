---
name: ironclad-delivery
description: Use for any Jira ticket Mike is implementing. Test-first workflow where a ticket only reaches Ready for QA after CI proves every acceptance criterion and Mike approves the run.
---

# Ironclad delivery

A ticket reaches **Ready for QA** only when CI has proven every acceptance criterion and Mike has approved the run. Jira is reached only through the Atlassian MCP. A hook allows the move to Ready for QA only after it has checked Azure DevOps for a succeeded, approved run of this exact commit. Don't try to get around it; if it blocks you, the proof isn't there yet.

## Hard rules
- **Jira, via MCP only.**
  - You may read tickets, add comments, and transition a ticket to *In Progress*.
  - The *Ready for QA* transition happens only at the end of the workflow below, and the hook verifies it.
  - Never make any other transition, and never edit ticket fields or descriptions. Those are Mike's.
- Never edit, delete, loosen or skip an existing test or assertion. Never add `.only`, `.skip`, `.fixme`, `test.fail`, `[Fact(Skip=...)]` or `[Ignore]`.
- Never update visual baselines (`--update-snapshots`), and never edit existing files in `api-fixtures/` or any `<KEY>.acs.json`. If one genuinely needs to change, stop and tell Mike why.
- Never touch gate files: Playwright/Stryker/vitest config, `tools/ticket/`, `pipeline/`, `scripts/review-agent.sh`, `scripts/draft-acs.sh`, `.claude/`.
- Never hard-code values that only make the frozen fixtures pass.
- If you can't make something pass honestly, stop and report. A red pipeline is fine; a gamed green one is not.

## Workflow
1. **Start.** Read the ticket via MCP and transition it to *In Progress*.
2. **Capture the ACs.** Pipe the ticket's description, exactly as MCP returned it, into `npm run ticket -- snapshot <KEY>`.
   - Show Mike the printed ACs. After he confirms, commit `<KEY>.acs.json` on its own.
   - No `AC-n` lines means the snapshot is refused; see below.
   - Never alter the description text before piping it.
3. **Explore the UI.** Use `playwright-cli` against the slot or local dev server to see the current behaviour. This is exploration only; it proves nothing.
4. **Write acceptance tests first** in `app/src/ui/e2e/acceptance/<KEY>.spec.ts`:
   - Import `{ test, expect, expectSameShape, settle }` from `./fixtures`, never from `@playwright/test`.
   - One `describe` tagged `@<KEY>`. One test per AC, titled `AC-<n>: ...` exactly matching the snapshot.
   - Use `mockApi()` with a new fixture file in `api-fixtures/` for deterministic visuals.
   - Assert what the user sees AND what the UI sends to the API (`waitForRequest` + `postDataJSON`).
   - Cover loading, empty and error states for any API-backed view. Use `test.use({ apiErrorsExpected: true })` only in the error-state test.
   - End each visual AC with `toHaveScreenshot('<KEY>-AC-<n>.png', { fullPage: true })`. New screenshots need baselines: ask Mike to run `--update-snapshots`, review them and commit.
   - Add one `@live` test that calls the real API via `apiJson()` and runs `expectSameShape()` against your fixture.
   - Run them. They must FAIL before you implement. Commit the tests on their own.
5. **Write component tests** (vitest + Testing Library) for the React logic you'll change. Mutation testing kills mutants with these, not with Playwright.
6. **Implement** until all tests pass.
7. **Mutation check locally.** Run `npx stryker run --mutate <changed files>` in the React folder. Kill survivors by adding tests that assert real behaviour, never by excluding code.
8. **Local checks.** Run `npm run guard` and fix everything it lists.
9. **Hand off.** Push and open the PR. Tell Mike the pipeline will pause for his approval.
10. **Promote**, once Mike says the run is approved:
    - Run `npm run ticket -- promote <KEY>`. It verifies the approved run and prints the evidence comment.
    - Post that comment **verbatim** via MCP.
    - Then transition to *Ready for QA* via MCP. The hook re-checks before allowing it.
    - If the ticket is already in *Ready for QA* (backfill), post the comment and skip the transition.

## When the ticket has no AC-n lines
Draft ACs, but never decide them:
- **Ticket has a description:** run `npm run draft-acs -- <KEY>`. This rewrites the description into AC lines, adds nothing, and lists open questions for the PO.
- **Ticket is "parity with the old system":** run `npm run draft-acs -- <KEY> --parity <legacy-repo-path> <legacy-url> "<screen hint>"`.
  - Parity is about **functionality only**: fields, actions, flows, validations, empty/error states, permissions. Data values are irrelevant.
  - Every parity AC cites its legacy code location.
  - The legacy **repo** is read-only. Read, grep and `git log/show/blame` only. A hook blocks anything else.
  - The legacy **website** is read-only. Never submit, save, approve, delete or upload. If a click might change data, don't click; describe the behaviour from the code instead.
  - If legacy behaviour looks like a bug, list it under QUESTIONS FOR PO. Copying a bug is the PO's call.

Show Mike the draft. He edits it and pastes it into Jira himself. Then re-read the ticket via MCP and snapshot it. Never write ACs to Jira yourself.

For parity ACs, write tests against the **new app only**, with mocked API data. Values just need to be plausible, since behaviour is what's tested. Don't edit `legacy-reference/` screenshots; they're Mike-approved references.

## When QA bounces a ticket
The obscure case becomes a new AC in Jira (Mike adds it). Mike re-snapshots with approval, a new test is written, and the pipeline runs again. Never patch around it.
