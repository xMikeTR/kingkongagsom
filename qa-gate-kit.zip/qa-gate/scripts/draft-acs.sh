#!/usr/bin/env bash
# Draft acceptance criteria for a ticket. PRINTS ONLY: never writes to Jira.
# Mike reviews, edits, and pastes the result into the ticket description himself.
#
#   npm run draft-acs -- PROJ-123
#       Rewrites the ticket's own description into numbered AC-n lines. Adds nothing.
#
#   npm run draft-acs -- PROJ-123 --parity <legacy-repo-path> <legacy-url> [screen hint]
#       Functional parity with the legacy system: reads the legacy code (authoritative
#       rules) and explores the legacy website READ-ONLY to confirm behaviour.
#       Saves reference screenshots to app/src/ui/e2e/acceptance/legacy-reference/<KEY>/.
#
# Needs: claude CLI with the Atlassian MCP connected (read-only use here),
#        playwright-cli for --parity. JIRA_MCP_PREFIX defaults to mcp__atlassian.
set -euo pipefail

KEY="${1:?usage: draft-acs <KEY> [--parity <legacy-repo> <legacy-url> [screen hint]]}"
MODE="${2:-}"
P="${JIRA_MCP_PREFIX:-mcp__atlassian}"
# Read-only Jira tools for the drafting agent. The jira-gate hook blocks any write anyway.
JIRA_READ="${P}__getJiraIssue,${P}__getAccessibleAtlassianResources"
TICKET="Read Jira ticket $KEY with the Atlassian MCP (${P}__getJiraIssue): its summary and full description."

if [ "$MODE" != "--parity" ]; then
  PROMPT=$(cat <<EOF
Rewrite this Jira ticket into numbered acceptance criteria.

Rules:
- Use ONLY what the ticket says. Do not invent requirements, defaults or edge cases.
- One observable behaviour per line, written as what a user does and what they see.
- Format each line exactly: AC-<n>: <behaviour>
- After the list, add a section "QUESTIONS FOR PO:" listing anything ambiguous or missing
  (e.g. error states, empty states, permissions) instead of guessing it.

TICKET:
$TICKET
EOF
)
  printf '%s' "$PROMPT" | claude -p --allowedTools "$JIRA_READ" \
    --disallowedTools "Edit,Write,MultiEdit,NotebookEdit,Bash"
  exit 0
fi

LEGACY_REPO="${3:?--parity needs <legacy-repo-path>}"
LEGACY_URL="${4:?--parity needs <legacy-url>}"
HINT="${5:-}"
REF_DIR="${ACCEPTANCE_DIR:-app/src/ui/e2e/acceptance}/legacy-reference/$KEY"
mkdir -p "$REF_DIR"

PROMPT=$(cat <<EOF
Draft FUNCTIONAL PARITY acceptance criteria for ticket $KEY: the new React app must do
what the legacy system does. Data values and numbers are irrelevant. Only functionality matters.

Ticket:
$TICKET
${HINT:+Screen/area hint: $HINT}

Sources:
1. Legacy code (authoritative for rules), at: $LEGACY_REPO
   Find the screen(s) this ticket covers. Extract: fields and filters, actions/buttons,
   what each action leads to, validation rules and their messages, empty/loading/error
   states, permission/role checks, and any non-obvious branches or defaults.
2. Legacy website (confirms real behaviour), at: $LEGACY_URL, explored with playwright-cli.

STRICTLY READ-ONLY on the legacy website. This may be production with real data:
- Only navigate, open menus/tabs/filters, sort, paginate, and take snapshots/screenshots.
- NEVER submit a form, save, approve, decline, delete, upload, or click anything whose
  label or purpose changes data. If unsure whether a click changes data, do NOT click it.
  Describe that behaviour from the code instead.
- Take one screenshot per flow with: playwright-cli screenshot --file $REF_DIR/<AC-id>.png

Output format:
AC-<n>: <what the user does> -> <what happens>  [legacy: <file>:<line>]
- One behaviour per line. Every AC must cite the legacy code location.
- Include validation, empty, error and permission behaviours, not just the happy path.
Then:
"WEBSITE vs CODE DIFFERENCES:" anything the site does that the code didn't suggest, or vice versa.
"QUESTIONS FOR PO:" anything where parity is unclear or legacy behaviour looks like a bug
  (parity with a bug is a decision for the PO, not for you).
EOF
)

# Legacy repo is read-only: only read tools are allowed, write tools are explicitly
# denied, and the project's legacy-readonly hook blocks anything that slips through.
export LEGACY_REPO_PATH="$(cd "$LEGACY_REPO" && pwd)${LEGACY_REPO_PATH:+:$LEGACY_REPO_PATH}"
printf '%s' "$PROMPT" | claude -p \
  --add-dir "$LEGACY_REPO" \
  --allowedTools "Read,Grep,Glob,Bash(playwright-cli *),$JIRA_READ" \
  --disallowedTools "Edit,Write,MultiEdit,NotebookEdit,Bash(git *),Bash(rm *),Bash(mv *),Bash(cp *)"

echo
echo "Reference screenshots: $REF_DIR"
echo "Review, edit, then paste the AC lines into the $KEY description in Jira."
