#!/usr/bin/env bash
# Independent reviewer. Fresh context: it sees ONLY the diff, the ACs from Jira,
# and the read-only repo. Never the implementer's conversation or reasoning.
# Writes evidence/review.json: { verdict, commit, notes, findings[] }
#
# Needs: claude CLI on the agent, ANTHROPIC_API_KEY (or your gateway env vars),
#        TICKET_KEY, COMMIT_SHA, BASE_REF. ACs come from the committed snapshot.
set -euo pipefail

BASE_REF="${BASE_REF:-origin/main}"
OUT="${EVIDENCE_DIR:-evidence}/review.json"
mkdir -p "$(dirname "$OUT")"

ACS=$(npx tsx tools/ticket/cli.ts acs "$TICKET_KEY")
DIFF=$(git diff "$BASE_REF"...HEAD -- . ':(exclude)**/__screenshots__/**' ':(exclude)package-lock.json')

PROMPT=$(cat <<EOF
You are a strict, independent code reviewer for ticket $TICKET_KEY. You did not write this code.
Assume it may have been written by an AI agent optimising to make tests pass.

Acceptance criteria (captured from Jira, authoritative):
$ACS

Review the diff below and the repository (read-only). For EACH acceptance criterion decide:
1. Is it actually implemented in the React UI and/or API, not just faked in tests or fixtures?
2. Does its Playwright test genuinely exercise it (real user interaction, meaningful assertions,
   checks what the API is sent, not just what renders)?
3. Would a plausible bug in this area still pass the tests?

Also fail the review for: hard-coded values that only satisfy the frozen API fixtures, tests that
assert on implementation details instead of behaviour, missing loading/empty/error states for
data from the API, and any change that weakens existing tests.

Respond with ONLY a JSON object, no prose, no code fences:
{"verdict":"pass"|"fail","notes":"<one sentence>","findings":[{"ac":"AC-n","severity":"blocker"|"minor","issue":"..."}]}
Verdict is "fail" if there is any blocker.

DIFF:
$DIFF
EOF
)

# Prompt and output go through stdin: big diffs exceed the per-argument size limit.
printf '%s' "$PROMPT" | claude -p --output-format json --allowedTools "Read,Grep,Glob" \
| node -e '
  const raw = JSON.parse(require("fs").readFileSync(0, "utf8"));
  const text = String(raw.result ?? "").replace(/^```(json)?|```$/gm, "").trim();
  let r;
  try { r = JSON.parse(text); } catch { r = { verdict: "fail", notes: "reviewer returned unparseable output", findings: [] }; }
  if (r.verdict !== "pass" && r.verdict !== "fail") r.verdict = "fail";
  if ((r.findings ?? []).some(f => f.severity === "blocker")) r.verdict = "fail";
  r.commit = process.argv[1];
  console.log(JSON.stringify(r, null, 2));
' "$COMMIT_SHA" > "$OUT"

cat "$OUT"
node -e 'process.exit(require(process.argv[1]).verdict === "pass" ? 0 : 1)' "$(realpath "$OUT")"
